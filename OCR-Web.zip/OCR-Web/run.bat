@echo off
title OCR-Web

cd /d "%~dp0"

rem --- Chon moi truong Python (thu theo thu tu): venv hoac .venv trong thu muc du an, roi D:\VietOCR\venv
if exist "venv\Scripts\activate.bat" (
    call "venv\Scripts\activate.bat"
) else if exist ".venv\Scripts\activate.bat" (
    call ".venv\Scripts\activate.bat"
) else if exist "D:\VietOCR\venv\Scripts\activate.bat" (
    call "D:\VietOCR\venv\Scripts\activate.bat"
) else (
    echo [Luu y] Khong tim thay moi truong ao "venv", se dung Python cai san trong may.
)

where python >nul 2>&1
if errorlevel 1 (
    echo Khong tim thay Python. Hay cai Python 3.9+ roi thu lai.
    pause
    exit /b 1
)

rem --- (Tuy chon) Cong va thiet bi chay: OCR_PORT mac dinh 5000; OCR_DEVICE=cpu de ep dung CPU (mac dinh tu dung GPU neu co)
rem set OCR_PORT=5000
rem set OCR_DEVICE=cpu

rem --- (Tuy chon) Bat chuc nang AI kiem tra/sua loi bang Google Gemini ---
rem Lay key mien phi tai https://aistudio.google.com/apikey roi bo "rem" o dong duoi va dan key vao
rem set GEMINI_API_KEY=AIzaSy_xxxxxxxx
rem
rem Khong can dat ten model: ung dung tu do tim model Gemini dung duoc voi key cua ban va tu doi
rem sang model khac khi gap loi 404/qua tai/het han muc. Chi dat neu muon ep dung model cu the
rem (co the dat nhieu model, cach nhau dau phay, thu theo thu tu):
rem set GEMINI_MODEL=ten-model-1,ten-model-2
rem
rem (Tuy chon) Du phong: neu Gemini loi thi tu dong thu Claude
rem set ANTHROPIC_API_KEY=sk-ant-xxxxxxxx
rem
rem Kiem tra ket noi AI: mo http://127.0.0.1:5000/api/ai-check
rem (Tuy chon) Ghi lai van ban gui AI + phan hoi tho vao logs\ai_debug.jsonl de kiem tra: set OCR_AI_DEBUG=1

if not defined OCR_PORT set OCR_PORT=5000

echo Dang khoi dong OCR-Web (lan dau co the mat vai phut de tai model)...
echo.

rem Mo trinh duyet khi may chu THUC SU san sang (cho toi da 10 phut), thay vi mo sau 3 giay co dinh
start "" /b powershell -NoProfile -WindowStyle Hidden -Command "for($i=0;$i -lt 600;$i++){try{Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://127.0.0.1:%OCR_PORT%/api/health | Out-Null; Start-Process http://127.0.0.1:%OCR_PORT%; break}catch{Start-Sleep 1}}"

python app.py

pause
