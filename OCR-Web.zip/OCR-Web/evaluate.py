"""
Đánh giá ACCURACY THẬT của OCR trên một bộ ảnh kiểm thử có Ground Truth.

    python evaluate.py                              # chạy OCR (PaddleOCR + VietOCR) trên eval_data/ rồi tính CER/WER/Accuracy
    python evaluate.py --data duong/dan/bo_test     # dùng thư mục dữ liệu khác
    python evaluate.py --ocr-outputs thu_muc_txt    # KHÔNG chạy model: so sánh các file <tên>.txt có sẵn với Ground Truth
    python evaluate.py --only-gt                    # bỏ qua ảnh chưa có Ground Truth (chạy nhanh hơn)
    python evaluate.py --draft-gt                   # xuất bản NHÁP Ground Truth từ kết quả OCR để bạn sửa tay (xem eval_data/README.md)
    python evaluate.py --ignore-case --ignore-punct # nới lỏng cách so sánh (mặc định nghiêm ngặt: tính cả HOA/thường, dấu câu, dấu thanh)

Cấu trúc dữ liệu (chi tiết: eval_data/README.md):
    eval_data/images/<loai_anh>/<ten>.png        ảnh kiểm thử (thư mục con = nhóm/loại ảnh, có thể bỏ trống)
    eval_data/ground_truth/<loai_anh>/<ten>.txt  văn bản ĐÚNG của ảnh (UTF-8) do con người xác nhận
    eval_data/manifest.csv                       (tùy chọn) file,category,note - ghi đè/bổ sung loại ảnh

Ảnh chưa có Ground Truth vẫn được OCR để xem Quality Score / Confidence nhưng ghi rõ "Chưa đánh giá Accuracy",
KHÔNG bao giờ tự suy ra con số Accuracy.

Kết quả: eval_reports/<thời gian>/results.csv, results.json, summary.md, ocr_output/<ten>.txt
"""

import argparse
import csv
import datetime
import json
import os
import sys
import time

import accuracy

HERE = os.path.dirname(os.path.abspath(__file__))
IMAGE_EXT = (".png", ".jpg", ".jpeg", ".webp")
UNCATEGORIZED = "chưa phân loại"
NO_GT = "Chưa đánh giá Accuracy"


def _read_text(path):
    with open(path, encoding="utf-8-sig") as f:   # utf-8-sig: chịu được file lưu từ Notepad có BOM
        return f.read()


def _load_manifest(data_dir):
    out, path = {}, os.path.join(data_dir, "manifest.csv")
    if os.path.isfile(path):
        with open(path, encoding="utf-8-sig", newline="") as f:
            for row in csv.DictReader(f):
                if row.get("file"):
                    out[row["file"].replace("\\", "/").strip()] = row
    return out


def find_samples(data_dir):
    """Liệt kê ảnh kiểm thử: [{rel, path, category, note, gt_path (hoặc None)}], sắp theo tên."""
    img_root = os.path.join(data_dir, "images")
    if not os.path.isdir(img_root):
        img_root = data_dir
    manifest = _load_manifest(data_dir)
    samples = []
    for root, dirs, files in os.walk(img_root):
        dirs[:] = sorted(d for d in dirs if d not in ("ground_truth", "ground_truth_draft"))
        for name in sorted(files):
            if not name.lower().endswith(IMAGE_EXT):
                continue
            path = os.path.join(root, name)
            rel = os.path.relpath(path, img_root).replace(os.sep, "/")
            stem_rel = os.path.splitext(rel)[0]
            m = manifest.get(rel, {})
            category = (m.get("category") or "").strip() or (rel.split("/")[0] if "/" in rel else UNCATEGORIZED)
            candidates = [
                os.path.join(data_dir, "ground_truth", stem_rel + ".txt"),                       # phản chiếu thư mục con của images/
                os.path.join(data_dir, "ground_truth", os.path.basename(stem_rel) + ".txt"),     # phẳng
                os.path.splitext(path)[0] + ".txt",                                              # cạnh file ảnh
            ]
            gt_path = next((c for c in candidates if os.path.isfile(c)), None)
            samples.append({"rel": rel, "path": path, "category": category, "note": (m.get("note") or "").strip(),
                            "gt_path": gt_path})
    return samples


def default_ocr(enhance="auto"):
    """Hàm OCR thật: PaddleOCR + VietOCR qua ocr_engine.run_ocr (cùng đường chạy với website)."""
    from PIL import Image, ImageOps
    import ocr_engine
    import preprocess

    def run(path):
        with Image.open(path) as im:
            im.load()
            image = preprocess.to_rgb(ImageOps.exif_transpose(im))
        try:
            return ocr_engine.run_ocr(image, check_resolution=True, auto_orient=True, enhance=enhance)
        except ocr_engine.NoTextFound as e:
            return {"text": "", "confidence": None, "quality": getattr(e, "quality", None)}
    return run


def _quality_only(path):
    from PIL import Image, ImageOps
    import preprocess
    import quality
    with Image.open(path) as im:
        im.load()
        return quality.assess(preprocess.to_rgb(ImageOps.exif_transpose(im)))


def evaluate_dataset(data_dir, ocr_fn=None, ocr_outputs_dir=None, ignore_case=False, ignore_punct=False,
                     only_gt=False, limit=None, log=print):
    """
    Trả về (rows, summary). ocr_fn(path)->dict(text, confidence, quality) hoặc ocr_outputs_dir để đọc OCR có sẵn.
    Tách riêng khỏi main() để kiểm thử được mà không cần model.
    """
    samples = find_samples(data_dir)
    if only_gt:
        samples = [s for s in samples if s["gt_path"]]
    if limit:
        samples = samples[:limit]
    rows = []
    for k, s in enumerate(samples, 1):
        gt = _read_text(s["gt_path"]) if s["gt_path"] else None
        row = {"file": s["rel"], "category": s["category"], "note": s["note"], "has_ground_truth": False,
               "quality_score": None, "quality_level": None, "ocr_confidence": None, "cer": None, "wer": None,
               "char_accuracy": None, "word_accuracy": None, "status": "", "elapsed_ms": None,
               "ocr_text": "", "ground_truth": gt or ""}
        log(f"[{k}/{len(samples)}] {s['rel']}")
        t0 = time.perf_counter()
        try:
            if ocr_outputs_dir:
                cand = os.path.join(ocr_outputs_dir, os.path.splitext(s["rel"])[0] + ".txt")
                flat = os.path.join(ocr_outputs_dir, os.path.splitext(os.path.basename(s["rel"]))[0] + ".txt")
                src = cand if os.path.isfile(cand) else flat if os.path.isfile(flat) else None
                if src is None:
                    row["status"] = "Thiếu file OCR output"
                    rows.append(row)
                    continue
                res = {"text": _read_text(src), "confidence": None, "quality": _quality_only(s["path"])}
            else:
                res = ocr_fn(s["path"])
        except Exception as e:  # một ảnh lỗi không được làm hỏng cả đợt đánh giá
            row["status"] = f"Lỗi khi OCR: {type(e).__name__}"
            rows.append(row)
            continue
        row["elapsed_ms"] = int((time.perf_counter() - t0) * 1000)
        row["ocr_text"] = res.get("text") or ""
        row["ocr_confidence"] = res.get("confidence")
        q = res.get("quality")
        if q:
            row["quality_score"], row["quality_level"] = q["score"], q["level"]
        ev = accuracy.evaluate(row["ocr_text"], gt, ignore_case, ignore_punct)
        if ev["evaluated"]:
            row.update(has_ground_truth=True, cer=ev["cer"], wer=ev["wer"], char_accuracy=ev["char_accuracy"],
                       word_accuracy=ev["word_accuracy"], status="Đã đánh giá")
            row["_ev"] = ev
        else:
            row["status"] = NO_GT if gt is None else NO_GT + " (file Ground Truth rỗng)"
        rows.append(row)
    return rows, summarize(rows)


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return round(sum(xs) / len(xs), 2) if xs else None


def _group(rows, key):
    out = {}
    for r in rows:
        out.setdefault(r[key] or "—", []).append(r)
    return out


def summarize(rows):
    evaluated = [r for r in rows if r["has_ground_truth"]]
    evs = [r["_ev"] for r in evaluated]

    def block(rs):
        agg = accuracy.aggregate([r["_ev"] for r in rs if r.get("_ev")])
        return {"images": len(rs), "evaluated": agg.get("samples", 0), "accuracy": agg,
                "avg_quality_score": _mean([r["quality_score"] for r in rs]),
                "avg_ocr_confidence": _mean([r["ocr_confidence"] for r in rs])}
    return {
        "total_images": len(rows), "evaluated": len(evaluated), "not_evaluated": len(rows) - len(evaluated),
        "overall": block(rows), "accuracy": accuracy.aggregate(evs),
        "by_category": {k: block(v) for k, v in sorted(_group(rows, "category").items())},
        "by_quality_level": {k: block(v) for k, v in sorted(_group(rows, "quality_level").items())},
    }


def _fmt(x, pct=True):
    return "—" if x is None else (f"{x:.1f}%" if pct else f"{x:.1f}")


def summary_markdown(summary, rows, options):
    a = summary["accuracy"]
    L = ["# Báo cáo đánh giá OCR", "",
         f"- Tổng số ảnh: **{summary['total_images']}** · đã đánh giá Accuracy: **{summary['evaluated']}** · "
         f"chưa có Ground Truth: **{summary['not_evaluated']}**",
         f"- Cách so sánh: {'không phân biệt HOA/thường' if options['ignore_case'] else 'phân biệt HOA/thường'}, "
         f"{'bỏ qua dấu câu' if options['ignore_punct'] else 'tính cả dấu câu'}, tính cả dấu thanh/dấu mũ tiếng Việt.", ""]
    if a.get("evaluated"):
        L += ["## Accuracy tổng hợp (chỉ các ảnh có Ground Truth)", "",
              "| Chỉ số | Gộp theo ký tự/từ (micro) | Trung bình từng ảnh (macro) |", "|---|---|---|",
              f"| Character Accuracy | {_fmt(a['char_accuracy_micro'])} | {_fmt(a['char_accuracy_macro'])} |",
              f"| CER | {_fmt(a['cer_micro'])} | {_fmt(a['cer_macro'])} |",
              f"| WER | {_fmt(a['wer_micro'])} | {_fmt(a['wer_macro'])} |", ""]
    else:
        L += ["## Accuracy", "", f"**{NO_GT}** — chưa có ảnh nào kèm Ground Truth.", ""]

    def table(title, groups):
        out = [f"## {title}", "", "| Nhóm | Số ảnh | Có GT | Quality Score TB | OCR Confidence TB | Char Accuracy (micro) | CER | WER |",
               "|---|---|---|---|---|---|---|---|"]
        for k, b in groups.items():
            ag = b["accuracy"]
            ok = ag.get("evaluated")
            out.append(f"| {k} | {b['images']} | {b['evaluated']} | {_fmt(b['avg_quality_score'], False)} | {_fmt(b['avg_ocr_confidence'])} | "
                       f"{_fmt(ag['char_accuracy_micro']) if ok else 'Chưa đánh giá'} | {_fmt(ag['cer_micro']) if ok else '—'} | "
                       f"{_fmt(ag['wer_micro']) if ok else '—'} |")
        return out + [""]
    L += table("Theo loại ảnh", summary["by_category"])
    L += table("Theo mức Quality Score (xanh/vàng/đỏ)", summary["by_quality_level"])
    L += ["> Quality Score và OCR Confidence **không phải** Accuracy. Chỉ cột Accuracy/CER/WER được tính từ Ground Truth.", ""]
    missing = [r["file"] for r in rows if not r["has_ground_truth"]]
    if missing:
        L += ["## Ảnh chưa đánh giá Accuracy", ""] + [f"- {m}" for m in missing] + [""]
    worst = sorted([r for r in rows if r["has_ground_truth"]], key=lambda r: -r["cer"])[:10]
    if worst:
        L += ["## 10 ảnh có CER cao nhất (nên xem lại)", "", "| Ảnh | Loại | CER | WER | Quality | Confidence |", "|---|---|---|---|---|---|"]
        L += [f"| {r['file']} | {r['category']} | {_fmt(r['cer'])} | {_fmt(r['wer'])} | {_fmt(r['quality_score'], False)} | {_fmt(r['ocr_confidence'])} |"
              for r in worst]
    return "\n".join(L) + "\n"


FIELDS = ["file", "category", "has_ground_truth", "quality_score", "quality_level", "ocr_confidence", "cer", "wer",
          "char_accuracy", "word_accuracy", "status", "elapsed_ms", "note", "ocr_text", "ground_truth"]


def write_reports(rows, summary, out_dir, options):
    os.makedirs(os.path.join(out_dir, "ocr_output"), exist_ok=True)
    with open(os.path.join(out_dir, "results.csv"), "w", encoding="utf-8-sig", newline="") as f:  # utf-8-sig: Excel mở đúng tiếng Việt
        w = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    clean_rows = [{k: v for k, v in r.items() if not k.startswith("_")} for r in rows]
    with open(os.path.join(out_dir, "results.json"), "w", encoding="utf-8") as f:
        json.dump({"options": options, "summary": summary, "samples": clean_rows}, f, ensure_ascii=False, indent=2)
    for r in rows:
        if r["ocr_text"]:
            p = os.path.join(out_dir, "ocr_output", os.path.splitext(r["file"])[0] + ".txt")
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "w", encoding="utf-8") as f:
                f.write(r["ocr_text"])
    md = summary_markdown(summary, rows, options)
    with open(os.path.join(out_dir, "summary.md"), "w", encoding="utf-8") as f:
        f.write(md)
    return md


def write_draft_gt(rows, data_dir):
    """Bản NHÁP Ground Truth cho ảnh chưa có GT. Không ghi đè gì có sẵn; không được dùng để chấm điểm cho tới khi bạn sửa & chuyển sang ground_truth/."""
    n = 0
    for r in rows:
        if r["has_ground_truth"] or not r["ocr_text"]:
            continue
        p = os.path.join(data_dir, "ground_truth_draft", os.path.splitext(r["file"])[0] + ".txt")
        if os.path.exists(p):
            continue
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(r["ocr_text"])
        n += 1
    return n


def main(argv=None):
    ap = argparse.ArgumentParser(description="Đánh giá Accuracy (CER/WER) của OCR trên bộ ảnh có Ground Truth.")
    ap.add_argument("--data", default=os.path.join(HERE, "eval_data"), help="thư mục bộ dữ liệu (mặc định: eval_data)")
    ap.add_argument("--out", default=os.path.join(HERE, "eval_reports"), help="thư mục lưu báo cáo (mặc định: eval_reports)")
    ap.add_argument("--ocr-outputs", help="thư mục chứa <tên>.txt là kết quả OCR có sẵn (không chạy model)")
    ap.add_argument("--enhance", default="auto", choices=("auto", "off", "strong"), help="chế độ xử lý ảnh khi chạy OCR")
    ap.add_argument("--ignore-case", action="store_true", help="không phân biệt HOA/thường")
    ap.add_argument("--ignore-punct", action="store_true", help="bỏ qua dấu câu")
    ap.add_argument("--only-gt", action="store_true", help="chỉ xử lý ảnh đã có Ground Truth")
    ap.add_argument("--limit", type=int, help="chỉ chạy N ảnh đầu tiên (thử nhanh)")
    ap.add_argument("--draft-gt", action="store_true", help="xuất bản nháp Ground Truth từ OCR cho ảnh chưa có GT")
    args = ap.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    if not os.path.isdir(args.data):
        raise SystemExit(f"Không thấy thư mục dữ liệu: {args.data}\nXem eval_data/README.md để biết cách thêm ảnh và Ground Truth.")
    if not find_samples(args.data):
        raise SystemExit(f"Chưa có ảnh nào trong {args.data} (PNG/JPG/WEBP). Xem eval_data/README.md.")

    ocr_fn = None
    if not args.ocr_outputs:
        print("Đang tải model OCR (PaddleOCR + VietOCR)...")
        import ocr_engine
        ocr_engine.load_models()
        ocr_fn = default_ocr(args.enhance)
    options = {"ignore_case": args.ignore_case, "ignore_punct": args.ignore_punct, "enhance": args.enhance,
               "ocr_source": args.ocr_outputs or "ocr_engine (PaddleOCR + VietOCR)"}
    rows, summary = evaluate_dataset(args.data, ocr_fn, args.ocr_outputs, args.ignore_case, args.ignore_punct, args.only_gt, args.limit)
    out_dir = os.path.join(args.out, datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
    md = write_reports(rows, summary, out_dir, options)
    print("\n" + md)
    if args.draft_gt:
        n = write_draft_gt(rows, args.data)
        print(f"Đã tạo {n} bản nháp Ground Truth trong {os.path.join(args.data, 'ground_truth_draft')} — hãy đối chiếu ảnh, SỬA cho đúng rồi chuyển sang ground_truth/.")
    print(f"Báo cáo chi tiết: {out_dir}")


if __name__ == "__main__":
    main()
