# Bộ dữ liệu kiểm thử Accuracy

Thư mục này **cố ý để trống**: Accuracy chỉ có ý nghĩa khi đo trên ảnh thật + văn bản đúng (Ground Truth) do bạn xác nhận.
Chưa có Ground Truth thì hệ thống ghi **"Chưa đánh giá Accuracy"**, không bao giờ tự suy ra con số.

## Cách thêm một mẫu (2 bước)

1. Bỏ ảnh vào `images/<loai_anh>/`, ví dụ `images/mo_nhe/hoa_don_01.jpg`
   (thư mục con = loại ảnh, dùng để thống kê theo nhóm; bỏ thẳng vào `images/` cũng được).
2. Tạo file văn bản **cùng tên, đuôi `.txt`**, lưu **UTF-8**, ghi đúng nội dung chữ trong ảnh, cùng thứ tự đọc:
   `ground_truth/mo_nhe/hoa_don_01.txt` (hoặc `ground_truth/hoa_don_01.txt`, hoặc đặt cạnh ảnh).

Mỗi dòng của ảnh nên là một dòng trong file. Không cần ghi "=== Trang N ===". Ảnh nhiều dòng/nhiều vùng chữ: gõ theo thứ tự đọc từ trên xuống.

## Cách có Ground Truth nhanh hơn (không bị thiên vị)

`python evaluate.py --draft-gt` xuất kết quả OCR của ảnh chưa có GT vào `ground_truth_draft/`.
**Bạn phải đối chiếu từng chữ với ảnh gốc, sửa cho đúng**, rồi mới chuyển sang `ground_truth/`.
Nếu dùng nguyên bản nháp chưa sửa làm Ground Truth thì Accuracy sẽ đẹp một cách giả tạo (OCR so với chính nó) — bản nháp nằm riêng nên không bị chấm điểm nhầm.

## Phủ đủ các loại ảnh

Nên có ít nhất vài ảnh cho mỗi loại (tên thư mục gợi ý):

| Thư mục | Loại |
|---|---|
| `anh_ro_net` | ảnh rõ, chất lượng tốt |
| `mo_nhe`, `mo_nang` | hơi mờ / rất mờ |
| `thieu_sang`, `qua_sang` | thiếu sáng / quá sáng |
| `nhieu` | có nhiễu |
| `nen_khong_deu`, `co_bong` | nền không đều / có bóng |
| `nghieng` | bị nghiêng |
| `do_phan_giai_thap` | độ phân giải thấp |
| `van_ban_in`, `chu_viet_tay` | văn bản in / chữ viết tay (hệ thống chủ yếu hỗ trợ chữ in) |
| `tieng_viet_day_du_dau` | tiếng Việt đủ dấu |
| `nhieu_dong`, `nhieu_vung_chu` | nhiều dòng / nhiều vùng chữ |
| `tai_lieu_thuc_te` | ảnh tài liệu thực tế |

Chỉ có một ảnh sạch? Dùng `python tools/degrade.py anh_sach.png --gt anh_sach.txt` để tạo các biến thể
mờ/tối/sáng/nhiễu/bóng/nghiêng/độ phân giải thấp từ chính ảnh đó (dùng lại cùng Ground Truth; được ghi chú là "tổng hợp" trong `manifest.csv`).
Ảnh mô phỏng giúp thấy xu hướng, nhưng **không thay được ảnh chụp thật** ngoài đời.

## Chạy đánh giá

```
python evaluate.py                      # OCR toàn bộ rồi tính CER / WER / Accuracy
python evaluate.py --only-gt            # chỉ ảnh đã có Ground Truth
python evaluate.py --ocr-outputs thu_muc_txt   # so sánh file .txt OCR có sẵn, không chạy model
```
Báo cáo nằm ở `eval_reports/<thời gian>/` (`summary.md`, `results.csv`, `results.json`, `ocr_output/`).

`manifest.csv` (tùy chọn): cột `file,category,note` — dùng khi muốn đặt loại ảnh khác với tên thư mục.
