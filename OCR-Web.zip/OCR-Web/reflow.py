"""
Nối các DÒNG HIỂN THỊ trong ảnh thành ĐOẠN VĂN (tùy chọn - mặc định tắt, kết quả giữ nguyên từng dòng như ảnh).

Vấn đề: OCR đọc theo từng dòng chữ trong ảnh, nên một câu dài nhiều dòng bị tách bằng ký tự xuống dòng cứng.
Khi ô kết quả hẹp hơn dòng gốc, trình duyệt lại tự bẻ dòng thêm lần nữa -> câu bị đứt vụn, khó đọc, khó chép.

Cách làm (thận trọng, ưu tiên KHÔNG nối nhầm): hai dòng liên tiếp A, B chỉ được nối khi trông như cùng một đoạn:
  - B nằm ngay dưới A (không cùng hàng, khoảng cách dòng bình thường);
  - A chạy gần hết bề ngang cột chữ (dòng ngắn = kết thúc đoạn; dòng hơi ngắn + kết thúc câu = kết thúc đoạn);
  - B không thụt đầu dòng, không bắt đầu bằng gạch đầu dòng / số thứ tự.
Bảng, biểu mẫu, danh sách, tiêu đề (Chương/Điều/Mục/Phần), các khoản 1. 2. 3. vì vậy luôn tách thành dòng/đoạn riêng.

Chỉ thay đổi khoảng trắng giữa các dòng (xuống dòng -> dấu cách) nên không ảnh hưởng CER/WER (accuracy.py gộp mọi khoảng trắng).
"""

import re

MIN_WIDTH_IN_LINE_HEIGHTS = 20   # cột chữ hẹp hơn mức này (đơn vị: chiều cao dòng) -> coi là bảng/biểu mẫu, không nối
MAX_GAP = 0.9                    # khoảng hở giữa hai dòng tối đa (x chiều cao dòng) để còn cùng đoạn
SHORT = 0.12                     # dòng A hụt so với lề phải quá tỉ lệ này (của bề rộng cột) và kết thúc câu -> hết đoạn
VERY_SHORT = 0.35                # hụt quá tỉ lệ này -> hết đoạn dù không có dấu câu
INDENT = 1.0                     # B thụt vào quá mức này (x chiều cao dòng) so với lề trái đoạn -> đoạn mới
JUMP_BACK = 4.0                  # B lùi về bên trái quá mức này so với A (x chiều cao dòng): nhảy cột/khối khác, không phải cùng đoạn

_BULLET = re.compile(
    r"^\s*(?:[-–—•·*▪●○+]\s"
    r"|\(?\d{1,3}[.)](?:\s|(?=[^\d\s.,]))"          # 1. / 2) / 3.Đơn (OCR hay làm dính số với chữ sau nó)
    r"|\(?[a-zA-Z][.)]\s|[IVXivx]{1,5}[.)]\s)")
_HEADING = re.compile(r"^\s*(?:Điều|ĐIỀU|Chương|CHƯƠNG|Mục|MỤC|Phần|PHẦN|Phụ lục|PHỤ LỤC)\s+[0-9IVXLC]+\b")
_CLOSERS = "”’\"')]»"


def ends_sentence(text):
    t = text.rstrip().rstrip(_CLOSERS)
    return t.endswith((".", "!", "?", "…", ":", ";"))


def is_heading(text):
    """Dòng tiêu đề kiểu văn bản pháp quy: 'Chương VI', 'Điều 30. ...', 'Mục 2', 'Phần I'."""
    return bool(_HEADING.match(text))


def starts_item(text):
    """Dòng bắt đầu một mục (gạch đầu dòng, 1. 2) a) ..., hoặc tiêu đề Chương/Điều/Mục) -> luôn là đoạn mới."""
    return bool(_BULLET.match(text)) or is_heading(text)


def _pct(sorted_vals, q):
    return sorted_vals[min(len(sorted_vals) - 1, max(0, int(round(q * (len(sorted_vals) - 1)))))]


def _merge_conf(items):
    num = den = 0.0
    for it in items:
        c = it.get("conf")
        if c is not None:
            n = max(1, len(it["text"]))
            num += c * n
            den += n
    return round(num / den, 1) if den else None


def _build(items, groups):
    return [{"text": " ".join(items[i]["text"].strip() for i in g), "conf": _merge_conf([items[i] for i in g]), "lines": list(g)}
            for g in groups]


def paragraphs_from_geometry(items):
    """
    items: [{"text", "conf", "box": [x0, y0, x1, y1]}] theo thứ tự đọc.
    Trả về [{"text", "conf", "lines": [chỉ số dòng]}].
    """
    n = len(items)
    if n == 0:
        return []
    alone = [[i] for i in range(n)]
    if n == 1:
        return _build(items, alone)
    hs = sorted(max(1.0, it["box"][3] - it["box"][1]) for it in items)
    med_h = _pct(hs, 0.5)
    right = _pct(sorted(it["box"][2] for it in items), 0.9)
    left = _pct(sorted(it["box"][0] for it in items), 0.1)
    width = right - left
    if width < MIN_WIDTH_IN_LINE_HEIGHTS * med_h:
        return _build(items, alone)

    groups, cur, para_left = [], [0], items[0]["box"][0]
    for i in range(1, n):
        a, b = items[i - 1], items[i]
        ab, bb = a["box"], b["box"]
        ha, hb = max(1.0, ab[3] - ab[1]), max(1.0, bb[3] - bb[1])
        overlap = min(ab[3], bb[3]) - max(ab[1], bb[1])
        shortfall = right - ab[2]
        brk = (
            overlap > 0.4 * min(ha, hb)                                   # cùng hàng (cột/ô bảng khác)
            or bb[1] - ab[3] > MAX_GAP * med_h                            # cách xa: sang đoạn mới
            or bb[0] >= ab[2]                                             # B không nằm dưới A
            or ab[0] - bb[0] > JUMP_BACK * med_h                          # B nhảy sang cột/khối khác bên trái
            or shortfall > VERY_SHORT * width                             # A là dòng ngắn (tiêu đề, cuối đoạn, mục danh sách)
            or (shortfall > SHORT * width and ends_sentence(a["text"]))   # A hết câu và chưa tới lề phải
            or bb[0] - para_left > INDENT * med_h                         # B thụt đầu dòng
            or starts_item(b["text"])                                     # B là mục danh sách / tiêu đề
            or is_heading(a["text"])                                      # A là tiêu đề: dòng sau luôn là đoạn mới
        )
        if brk:
            groups.append(cur)
            cur, para_left = [i], bb[0]
        else:
            cur.append(i)
            para_left = min(para_left, bb[0])
    groups.append(cur)
    return _build(items, groups)


def join_paragraphs(paragraphs):
    """
    Ghép văn bản cuối. Có đoạn nào được nối nhiều dòng -> cách nhau một DÒNG TRỐNG (đọc như văn bản thật).
    Không có gì được nối (bảng/biểu mẫu/dòng ngắn) -> giữ nguyên mỗi dòng một hàng như trước.
    """
    merged = any(len(p["lines"]) > 1 for p in paragraphs)
    return ("\n\n" if merged else "\n").join(p["text"] for p in paragraphs)
