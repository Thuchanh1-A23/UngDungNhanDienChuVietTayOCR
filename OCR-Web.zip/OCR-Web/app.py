"""
Flask backend cho website OCR tiếng Việt (văn bản in / đánh máy).
Cách chạy: python app.py  ->  http://127.0.0.1:5000

Thư viện cần có: xem requirements.txt  (pip install -r requirements.txt)
Biến môi trường (tùy chọn): OCR_HOST, OCR_PORT, OCR_DEVICE (cpu | cuda), GEMINI_API_KEY, ANTHROPIC_API_KEY.
"""

import hashlib
import io
import logging
import os
import threading
from collections import OrderedDict

from flask import Flask, jsonify, render_template, request, send_file
from PIL import Image, UnidentifiedImageError

import accuracy
import ai_review
import input_advisor
import ocr_engine
import pdf_export
import pdf_text
import preprocess
import quality

IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}
IMAGE_FORMATS = {"PNG", "JPEG", "WEBP"}
MAX_IMAGE_BYTES = 10 * 1024 * 1024   # ảnh: tối đa 10 MB
MAX_GT_PDF_BYTES = 20 * 1024 * 1024  # PDF dùng làm Ground Truth: tối đa 20 MB
MAX_GT_PDF_PAGES = 100               # ... và tối đa 100 trang
MAX_IMAGE_PIXELS = preprocess.MAX_PIXELS  # chặn ảnh có quá nhiều điểm ảnh (tránh tốn RAM)
BUSY_WAIT = 90                       # giây tối đa một yêu cầu chờ đến lượt xử lý (model chỉ chạy được 1 ảnh/lần)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_GT_PDF_BYTES + 1024 * 1024  # dư 1 MB cho phần đầu multipart (ảnh vẫn bị giới hạn 10 MB ở _read_upload)
log = logging.getLogger("ocr")

MAX_EXPORT_CHARS = 2_000_000         # xuất PDF: giới hạn độ dài văn bản (tránh treo máy chủ)
MAX_ACCURACY_CHARS = 400_000         # so sánh với Ground Truth: giới hạn độ dài mỗi văn bản
AI_DOWN = "AI kiểm tra hiện không khả dụng. Kết quả OCR vẫn được giữ nguyên."

# pdfium KHÔNG an toàn khi nhiều luồng dùng cùng lúc -> mọi thao tác với PDF đi qua khóa này
_pdfium_lock = threading.RLock()

CSP = ("default-src 'self'; img-src 'self' data: blob:; style-src 'self'; script-src 'self'; "
       "connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")


@app.after_request
def security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "no-referrer")
    resp.headers.setdefault("Content-Security-Policy", CSP)
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"  # kết quả OCR có thể chứa thông tin riêng tư
    return resp

# Model chạy trên CPU: mỗi lúc chỉ xử lý 1 ảnh để tránh quá tải RAM/CPU
_busy = threading.Lock()

# Bộ nhớ đệm kết quả: OCR lại cùng một file/trang sẽ có kết quả ngay
_cache = OrderedDict()
_CACHE_MAX = 24
_cache_lock = threading.Lock()

def fail(message, status=400, **extra):
    return jsonify(success=False, message=message, **extra), status


@app.route("/")
def index():
    return render_template("index.html")


@app.errorhandler(413)
def too_large(_):
    return fail("File quá lớn (ảnh tối đa 10 MB, PDF Ground Truth tối đa 20 MB).", 413)


@app.errorhandler(500)
def server_error(_):
    return fail("Máy chủ gặp lỗi. Vui lòng thử lại sau.", 500)


@app.errorhandler(404)
def not_found(_):
    if request.path.startswith("/api/"):
        return fail("Không tìm thấy chức năng này.", 404)
    return "Không tìm thấy trang.", 404


@app.errorhandler(405)
def bad_method(_):
    return fail("Phương thức không được hỗ trợ.", 405)


# ---------------------------------------------------------------- Đọc file tải lên
class BadUpload(Exception):
    """Lỗi người dùng: message có thể hiển thị thẳng lên giao diện."""

    def __init__(self, message, status=400):
        super().__init__(message)
        self.message, self.status = message, status


def _ext(filename):
    return filename.rsplit(".", 1)[-1].lower() if "." in filename else ""


def _read_upload():
    """Đọc file ảnh tải lên, trả về bytes."""
    file = request.files.get("image") or request.files.get("file")
    if file is None or not file.filename:
        raise BadUpload("Vui lòng chọn một ảnh trước khi nhận diện.")
    if _ext(file.filename) not in IMAGE_EXTENSIONS:
        raise BadUpload("Chỉ hỗ trợ file ảnh PNG, JPG, JPEG hoặc WEBP.")
    data = file.read()
    if not data:
        raise BadUpload("File rỗng hoặc không đọc được.")
    if len(data) > MAX_IMAGE_BYTES:
        raise BadUpload("Ảnh quá lớn, vui lòng chọn ảnh dưới 10 MB.", 413)
    return data


def _read_gt_pdf():
    """Đọc file PDF dùng làm Ground Truth (PDF không phải đầu vào OCR)."""
    file = request.files.get("file")
    if file is None or not file.filename:
        raise BadUpload("Vui lòng chọn một file PDF.")
    if _ext(file.filename) != "pdf":
        raise BadUpload("Chỉ nhận PDF có sẵn chữ (vd: xuất từ Word) làm Ground Truth. Ảnh phải qua OCR mới có chữ, "
                        "nên so OCR với chính OCR sẽ cho Accuracy giả. Với ảnh hãy tự gõ lại văn bản đúng.", 400)
    data = file.read()
    if not data:
        raise BadUpload("File rỗng hoặc không đọc được.")
    if len(data) > MAX_GT_PDF_BYTES:
        raise BadUpload("File PDF quá lớn, vui lòng chọn file nhỏ hơn 20 MB.", 413)
    if not data.lstrip()[:5].startswith(b"%PDF"):  # kiểm tra nội dung thật, không tin đuôi file
        raise BadUpload("File PDF không hợp lệ hoặc bị hỏng.")
    return data


def _pdf_call(data, fn):
    """Mở PDF (trong khóa pdfium), gọi fn(pdf, số_trang), luôn đóng file."""
    import pypdfium2 as pdfium
    with _pdfium_lock:
        try:
            pdf = pdfium.PdfDocument(data)
            n = len(pdf)
        except Exception:
            raise BadUpload("Không đọc được file PDF (file hỏng hoặc có đặt mật khẩu).")
        try:
            if n < 1:
                raise BadUpload("File PDF không có trang nào hợp lệ.")
            if n > MAX_GT_PDF_PAGES:
                raise BadUpload(f"File PDF có {n} trang, vượt giới hạn {MAX_GT_PDF_PAGES} trang.")
            return fn(pdf, n)
        finally:
            pdf.close()


def _open_image(data):
    """Mở ảnh từ bytes, kiểm tra nội dung thật sự là PNG/JPEG/WEBP."""
    try:
        with Image.open(io.BytesIO(data)) as probe:
            if probe.format not in IMAGE_FORMATS:
                raise BadUpload("Chỉ hỗ trợ file ảnh PNG, JPG, JPEG hoặc WEBP.")
            if probe.width * probe.height > MAX_IMAGE_PIXELS:
                raise BadUpload(f"Ảnh có kích thước quá lớn ({probe.width}×{probe.height}px). Hãy thu nhỏ ảnh rồi thử lại.", 413)
            probe.verify()
        image = Image.open(io.BytesIO(data))
        image.load()
        return image
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError):
        raise BadUpload("Ảnh không hợp lệ hoặc bị hỏng.")


def _ocr_options():
    """Đọc các tuỳ chọn từ form: xoay thủ công, tự xoay đúng chiều, chế độ xử lý ảnh, ảnh xem trước, nối đoạn."""
    try:
        rotation = int(request.form.get("rotation", "0")) % 360
    except ValueError:
        rotation = -1
    if rotation not in (0, 90, 180, 270):
        raise BadUpload("Góc xoay không hợp lệ.")
    auto = request.form.get("auto_orient", "1") != "0"
    enhance = request.form.get("enhance", "auto")
    if enhance not in preprocess.ENHANCE_MODES:
        enhance = "auto"
    reflow = request.form.get("reflow", "0") == "1"   # mặc định GIỮ NGUYÊN từng dòng như trong ảnh
    return rotation, auto, enhance, request.form.get("want_preview") == "1", reflow


def _cache_get(key):
    with _cache_lock:
        hit = _cache.get(key)
        if hit is not None:
            _cache.move_to_end(key)
        return hit


def _cache_put(key, result):
    with _cache_lock:
        _cache[key] = result
        while len(_cache) > _CACHE_MAX:
            _cache.popitem(last=False)


@app.post("/api/ocr")
def api_ocr():
    """OCR một ảnh."""
    try:
        rotation, auto, enhance, preview, reflow = _ocr_options()
        data = _read_upload()
        digest = hashlib.sha1(data).hexdigest()

        # Kiểm tra bộ nhớ đệm TRƯỚC khi giải mã (tiết kiệm thời gian)
        key = (digest, rotation, auto, enhance, preview, reflow)
        hit = _cache_get(key)
        if hit is not None:
            return jsonify(success=True, **dict(hit, cached=True, elapsed_ms=5))
        image = _open_image(data)
    except BadUpload as e:
        return fail(e.message, e.status)

    # Model chạy trên CPU, mỗi lúc chỉ xử lý 1 ảnh: yêu cầu đến sau xếp hàng chờ thay vì bị từ chối
    if not _busy.acquire(timeout=BUSY_WAIT):
        return fail("Hệ thống đang bận xử lý file khác. Vui lòng thử lại sau ít giây.", 429)
    try:
        result = ocr_engine.run_ocr(image, check_resolution=True, rotation=rotation,
                                    auto_orient=auto, enhance=enhance, want_preview=preview, reflow=reflow)
    except ocr_engine.NoTextFound as e:
        q = getattr(e, "quality", None)
        return jsonify(success=False, message="Không phát hiện được vùng chữ nào trong ảnh.",
                       quality=q, advice=input_advisor.build(q, enhance, auto, True)), 422
    except Exception:
        log.exception("Lỗi khi chạy OCR")  # chi tiết lỗi chỉ ghi ở server, không gửi ra giao diện
        return fail("Quá trình nhận diện gặp lỗi. Vui lòng thử lại hoặc dùng ảnh khác.", 500)
    finally:
        _busy.release()

    _cache_put(key, result)
    return jsonify(success=True, **result)


@app.get("/api/config")
def api_config():
    return jsonify(ai_available=ai_review.available(), ai_model=ai_review.model_name(), ai_provider=ai_review.provider_label(),
                   max_image_mb=MAX_IMAGE_BYTES // 2**20)


@app.get("/api/health")
def api_health():
    return jsonify(ok=True, models_loaded=ocr_engine.models_loaded())


@app.post("/api/quality")
def api_quality():
    """Quality Score của ảnh đầu vào (xanh/vàng/đỏ) + cảnh báo/đề xuất xử lý, tính cục bộ ngay khi người dùng chọn file. Không dùng AI ngoài, không gửi ảnh đi đâu."""
    try:
        data = _read_upload()
        from PIL import ImageOps
        image = preprocess.to_rgb(ImageOps.exif_transpose(_open_image(data)))
        q = quality.assess(image)
        return jsonify(success=True, quality=q, advice=input_advisor.build(q))
    except BadUpload as e:
        return fail(e.message, e.status)
    except Exception:
        log.exception("Lỗi khi đánh giá chất lượng ảnh")
        return fail("Không đánh giá được chất lượng ảnh.", 422)


@app.get("/api/ai-check")
def api_ai_check():
    """Chẩn đoán kết nối AI: mở http://127.0.0.1:5000/api/ai-check để biết key/model/mạng có ổn không."""
    return jsonify(ai_review.check())


@app.post("/api/ai-review")
def api_ai_review():
    """AI (Gemini/Claude) đề xuất sửa lỗi OCR. Tùy chọn: cần GEMINI_API_KEY."""
    if not ai_review.available():
        return fail(AI_DOWN, 503, code="ai_unavailable", detail="Chưa cấu hình AI. Hãy đặt biến môi trường GEMINI_API_KEY (xem run.bat) rồi chạy lại.")
    payload = request.get_json(silent=True) or {}
    lines = payload.get("lines")
    if not isinstance(lines, list) or not lines:
        return fail("Không có nội dung để kiểm tra.")
    try:
        return jsonify(success=True, **ai_review.review(lines))
    except ai_review.AIError as e:
        log.warning("AI review thất bại: %s", e)
        return fail(AI_DOWN, 502, code="ai_unavailable", detail=str(e))   # OCR đã xong và không bị ảnh hưởng
    except Exception:
        log.exception("Lỗi AI review")
        return fail(AI_DOWN, 500, code="ai_unavailable", detail="Không thể kiểm tra bằng AI. Vui lòng thử lại.")


@app.post("/api/accuracy")
def api_accuracy():
    """
    Accuracy THẬT: so sánh kết quả OCR với Ground Truth do người dùng cung cấp -> CER, WER, Character Accuracy.
    Không có Ground Truth thì trả về evaluated=false ("Chưa đánh giá Accuracy"), tuyệt đối không bịa số.
    """
    p = request.get_json(silent=True) or {}
    hyp, ref = p.get("hypothesis"), p.get("reference")
    if not isinstance(hyp, str):
        return fail("Thiếu kết quả OCR để so sánh.")
    if ref is not None and not isinstance(ref, str):
        return fail("Ground Truth không hợp lệ.")
    if len(hyp) > MAX_ACCURACY_CHARS or len(ref or "") > MAX_ACCURACY_CHARS:
        return fail("Văn bản quá dài để so sánh.", 413)
    return jsonify(success=True, **accuracy.evaluate(hyp, ref, bool(p.get("ignore_case")), bool(p.get("ignore_punct"))))


@app.post("/api/ground-truth-from-pdf")
def api_ground_truth_from_pdf():
    """
    Lấy Ground Truth từ lớp chữ có sẵn của một PDF "số" (vd: xuất từ Word) - chữ đúng 100%, không qua OCR.
    TỪ CHỐI ảnh và PDF scan: muốn lấy chữ từ đó phải OCR, mà OCR chính là thứ cần đo -> Accuracy sẽ là con số giả.
    Chỉ nhận khi MỌI trang đều có lớp chữ đáng tin. Mỗi dòng trong PDF là một dòng trong văn bản trả về.
    """
    try:
        data = _read_gt_pdf()

        def work(pdf, n):
            pages, bad = [], []
            for i in range(n):
                lines = pdf_text.extract_page_lines(pdf, i)
                if lines is None:
                    bad.append(i + 1)
                else:
                    pages.append(lines)
            return n, pages, bad

        n, pages, bad = _pdf_call(data, work)
        if bad:
            shown = ", ".join(map(str, bad[:10])) + ("…" if len(bad) > 10 else "")
            return fail(f"PDF này không có lớp chữ đáng tin ở trang {shown} (có thể là bản scan/ảnh, trang trống hoặc font lỗi). "
                        "Không dùng được làm Ground Truth vì sẽ phải OCR để lấy chữ.", 422, code="gt_not_digital", pages=bad)
        parts = [(f"=== Trang {k} ===\n" if n > 1 else "") + "\n".join(lines) for k, lines in enumerate(pages, 1)]
        text = "\n\n".join(parts)
        if len(text) > MAX_ACCURACY_CHARS:
            return fail("Văn bản trong PDF quá dài để làm Ground Truth.", 413)
        return jsonify(success=True, text=text, pages=n, chars=len(text))
    except BadUpload as e:
        return fail(e.message, e.status)
    except Exception:
        log.exception("Lỗi khi lấy Ground Truth từ PDF")
        return fail("Không đọc được file PDF. Vui lòng thử file khác.", 422)


# ---------------------------------------------------------------- Xuất PDF
build_pdf = pdf_export.build_pdf


@app.post("/api/export-pdf")
def api_export_pdf():
    payload = request.get_json(silent=True) or {}
    text = payload.get("text")
    if not isinstance(text, str) or not text.strip():
        return fail("Không có nội dung để xuất PDF.")
    if len(text) > MAX_EXPORT_CHARS:
        return fail("Nội dung quá dài để xuất PDF.", 413)
    try:
        buf = build_pdf(text)
        resp = send_file(buf, mimetype="application/pdf", as_attachment=True, download_name="ket_qua_ocr.pdf")
        resp.headers["Cache-Control"] = "no-store"
        return resp
    except Exception:
        log.exception("Lỗi khi tạo PDF")
        return fail("Không thể tạo file PDF. Vui lòng thử lại.", 500)


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    host = os.environ.get("OCR_HOST", "127.0.0.1")  # đặt 0.0.0.0 nếu muốn máy khác trong mạng LAN truy cập
    port = int(os.environ.get("OCR_PORT", "5000"))
    print("Đang tải model OCR (chỉ một lần khi khởi động, có thể mất vài phút)...")
    try:
        ocr_engine.load_models()
    except RuntimeError as e:
        raise SystemExit(f"\nLỖI: {e}")
    print(f"Sẵn sàng: http://{'127.0.0.1' if host in ('0.0.0.0', '') else host}:{port}")
    app.run(host=host, port=port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
