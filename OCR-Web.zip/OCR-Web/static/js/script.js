(() => {
  const $ = (id) => document.getElementById(id);
  const MAX_IMAGE = 10 * 1024 * 1024; // khớp giới hạn ở backend
  const MAX_GT_PDF = 20 * 1024 * 1024; // PDF chỉ dùng để lấy Ground Truth
  const EXT_RE = /\.(png|jpe?g|webp)$/i;
  const BAD_TYPE_MSG = "Chỉ hỗ trợ file ảnh PNG, JPG, JPEG hoặc WEBP.";

  const dropzone = $("dropzone"), input = $("fileInput"), preview = $("preview"), previewImg = $("previewImg");
  const ocrBtn = $("ocrBtn"), btnText = $("ocrBtnText"), progress = $("progress"), progressBar = progress.firstElementChild;
  const alertBox = $("alert"), statusBox = $("status");
  const results = $("results"), resultText = $("resultText"), badge = $("editedBadge");

  const imgTools = $("imgTools"), autoBox = $("autoOrient"), enhanceSel = $("enhanceMode");
  const cancelBtn = $("cancelBtn"), reflowBox = $("reflowText");
  const rotBtns = [$("rotLeft"), $("rotRight"), $("rotReset")];
  const LV = { green: "Tốt", yellow: "Cần chú ý", red: "Kém" };
  const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const levelOf = (pct) => (pct >= 90 ? "green" : pct >= 75 ? "yellow" : "red");
  const imgQuality = $("imgQuality"), aiPanel = $("aiPanel");
  let lineInfo = [];      // thông tin từng dòng OCR gốc: {text, conf, level, bad}
  let paraInfo = [];      // các đoạn văn (nhiều dòng đã nối): {text, conf} - để AI Review biết độ tin cậy của đoạn
  let aiAvailable = false, aiBusy = false, aiProvider = "AI";
  const AI_BATCH = 80;    // số dòng gửi AI mỗi yêu cầu

  let file = null;        // file đang chọn
  let previewUrl = null;  // URL ảnh xem trước
  let objectUrl = null;   // object URL (chỉ dùng cho ảnh)
  let baseUrl = null;     // ảnh xem trước gốc (chưa xoay)
  let rotation = 0;       // góc xoay thủ công theo chiều kim đồng hồ: 0 / 90 / 180 / 270
  let busy = false;       // đang OCR
  let loading = false;    // (giữ cờ cho các kiểm tra chặn thao tác)
  let token = 0;          // đổi file giữa chừng thì bỏ qua kết quả cũ
  let abortCtl = null;    // dùng để dừng yêu cầu OCR đang chạy
  let cancelled = false;  // người dùng bấm "Dừng"
  let firstImgClass = ""; // viền màu chất lượng của trang 1

  // Kết quả OCR: tách riêng bản gốc và bản đang chỉnh sửa
  let lastPart = null;    // kết quả OCR gần nhất (ảnh sau xử lý, ghi chú...)
  let original = "";      // KẾT QUẢ OCR GỐC - không bao giờ bị sửa bởi thao tác chỉnh sửa
  let edited = "";        // nội dung hiện tại trong ô chỉnh sửa (dùng cho sao chép / xuất file)

  // ---------- Thông báo / trạng thái ----------
  const showAlert = (msg, type = "error") => {
    alertBox.textContent = msg;
    alertBox.className = `alert ${type}`;
    alertBox.hidden = false;
  };
  const clearAlert = () => { alertBox.hidden = true; };
  const setStatus = (text, kind = "idle") => {
    statusBox.textContent = text;
    statusBox.className = `status ${kind}`;
  };
  let toastTimer;
  const toast = (msg) => {
    const t = $("toast");
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, 2200);
  };
  // Đồng hồ: hiện số giây đã chờ ở thanh trạng thái để người dùng biết máy vẫn đang chạy
  let timerId = null, t0 = 0, baseStatus = "";
  const tick = () => { const sec = Math.floor((Date.now() - t0) / 1000); setStatus(sec >= 3 ? `${baseStatus} (${sec} giây)` : baseStatus, "working"); };
  const working = (text) => { baseStatus = text; tick(); };
  const startTimer = () => { t0 = Date.now(); clearInterval(timerId); timerId = setInterval(tick, 1000); };
  const stopTimer = () => { clearInterval(timerId); timerId = null; };

  const setProgress = (pct) => { // pct = null -> chạy vô định; số -> thanh tiến trình theo trang
    progress.hidden = pct === false;
    progress.classList.toggle("determinate", typeof pct === "number");
    progressBar.style.width = typeof pct === "number" ? `${pct}%` : "";
  };

  const ICON = { green: "🟢", yellow: "🟡", red: "🔴" };
  let lastQ = null, lastAdvice = null, lastLabel = "";

  // Quality Score = chất lượng ẢNH ĐẦU VÀO (không phải OCR Confidence, càng không phải Accuracy)
  function showQuality(q, label, advice) {
    lastQ = q; lastAdvice = advice || null; lastLabel = label || "";
    previewImg.className = q ? `lv-${q.level}` : "";
    if (!q) { imgQuality.hidden = true; return; }
    imgQuality.className = `qbox ${q.level}`;
    imgQuality.replaceChildren();
    const head = el("b", null, `${ICON[q.level]} Quality Score${label ? ` (${label})` : ""}: ${q.score}%`);
    imgQuality.append(head, document.createTextNode(` — ${advice ? advice.title : `Chất lượng ảnh ${LV[q.level].toLowerCase()}`}`));
    imgQuality.append(el("p", "qsum", advice ? advice.summary : (q.issues.length ? "Ảnh có vấn đề có thể ảnh hưởng kết quả OCR." : "Ảnh có chất lượng tốt, phù hợp để nhận diện.")));
    if (q.issues.length) {
      const ul = el("ul");
      q.issues.forEach((i) => ul.append(el("li", null, `${i.label}: ${i.message}`)));
      imgQuality.append(ul);
    }
    if (advice && advice.suggestions.length) {
      const p = el("p", "qsug"); p.append(el("b", null, "Đề xuất: "), document.createTextNode(advice.suggestions.join(" ")));
      imgQuality.append(p);
    }
    const mode = enhanceSel.value;
    let plan = "";
    if (mode === "off") plan = "Đang tắt xử lý ảnh — ảnh được giữ nguyên trước khi nhận diện.";
    else if (mode === "strong") plan = "Chế độ mạnh: cân bằng ánh sáng, tăng tương phản và chuyển thành bản scan đen trắng trước khi nhận diện.";
    else if (advice) plan = advice.plan.length ? `Hệ thống sẽ tự: ${advice.plan.map((x) => x.text.toLowerCase()).join(", ")}.` : advice.plan_note;
    if (plan) { const p = el("p", "qplan"); p.append(el("b", null, "Xử lý trước khi nhận diện: "), document.createTextNode(plan)); imgQuality.append(p); }
    if (advice && mode === "auto" && advice.recommend_strong) imgQuality.append(el("p", "qplan", "Nếu kết quả chưa tốt, hãy thử chế độ “Tăng cường mạnh”."));
    if (advice && advice.recapture) imgQuality.append(el("p", "qplan", "Có vấn đề xử lý phần mềm không khắc phục hết được: nên chụp/quét lại nếu có thể."));
    imgQuality.append(el("p", "qfoot", "Quality Score chỉ đánh giá ảnh đầu vào, không phải độ chính xác của kết quả OCR. Ảnh gốc luôn được giữ nguyên."));
    imgQuality.hidden = false;
  }
  enhanceSel.addEventListener("change", () => { if (lastQ) showQuality(lastQ, lastLabel, lastAdvice); });

  const baseName = () => (file ? file.name.replace(/\.[^.]+$/, "") : "ket_qua").replace(/[\\/:*?"<>|]+/g, "_") || "ket_qua";
  const suffix = () => (edited !== original ? "edited" : "ocr");

  // ---------- Chọn / xóa file ----------
  async function setFile(f) {
    if (!f || busy || loading) return;
    clearAlert();
    if (/\.pdf$/i.test(f.name) || f.type === "application/pdf") return showAlert("Hệ thống chỉ nhận file ảnh PNG, JPG, JPEG hoặc WEBP (không nhận PDF).");
    if (!EXT_RE.test(f.name)) return showAlert(BAD_TYPE_MSG);
    if (f.type && !/^image\/(png|jpeg|webp)$/.test(f.type)) return showAlert(BAD_TYPE_MSG);
    if (f.size === 0) return showAlert("File rỗng hoặc không đọc được.");
    if (f.size > MAX_IMAGE) return showAlert("Ảnh quá lớn, vui lòng chọn ảnh dưới 10 MB.");

    resetFile();
    const my = ++token;
    file = f;
    $("fileName").textContent = f.name;
    dropzone.hidden = true;
    preview.hidden = false;

    objectUrl = previewUrl = baseUrl = URL.createObjectURL(f);
    previewImg.src = previewUrl; previewImg.hidden = false;
    imgTools.hidden = false; updateRotUi();
    $("fileMeta").textContent = "Ảnh · sẵn sàng nhận diện";
    setStatus("Đã tải file. Nhấn “Nhận diện chữ” để bắt đầu.", "idle");
    ocrBtn.disabled = false;
    try { // kiểm tra chất lượng ảnh (không chặn việc OCR nếu lỗi)
      const body = new FormData(); body.append("file", f);
      const r = await fetch("/api/quality", { method: "POST", body });
      const j = await r.json();
      if (my === token && j.success) showQuality(j.quality, "", j.advice);
    } catch { /* bỏ qua */ }
  }

  // Đưa giao diện về trạng thái chưa có file (giữ nguyên thông báo lỗi nếu keepAlert)
  function resetFile(keepAlert = false) {
    token++;
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    file = previewUrl = objectUrl = baseUrl = null;
    rotation = 0;
    firstImgClass = "";
    imgTools.hidden = true;
    $("processedBox").hidden = true;
    original = edited = "";
    resultText.value = "";
    lastPart = null;
    accResult = null; accStale = false; $("gtText").value = "";
    loading = false;
    previewImg.hidden = true;
    showQuality(null);
    lineInfo = []; paraInfo = [];
    aiPanel.hidden = true;
    dropzone.hidden = false;
    preview.hidden = true;
    results.hidden = true;
    ocrBtn.disabled = true;
    setProgress(false);
    setStatus("Chưa có file", "idle");
    if (!keepAlert) clearAlert();
  }

  dropzone.addEventListener("click", () => input.click());
  dropzone.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.click(); }
  });
  input.addEventListener("change", () => { setFile(input.files[0]); input.value = ""; });
  $("removeBtn").addEventListener("click", () => { if (!busy) resetFile(); });

  // Kéo thả (chặn trình duyệt tự mở file khi thả ra ngoài vùng upload)
  ["dragover", "drop"].forEach((ev) => window.addEventListener(ev, (e) => e.preventDefault()));
  ["dragenter", "dragover"].forEach((ev) => dropzone.addEventListener(ev, () => dropzone.classList.add("dragover")));
  ["dragleave", "drop"].forEach((ev) => dropzone.addEventListener(ev, () => dropzone.classList.remove("dragover")));
  dropzone.addEventListener("drop", (e) => setFile(e.dataTransfer.files[0]));

  // Dán ảnh từ clipboard (ví dụ ảnh chụp màn hình) bằng Ctrl+V; dán chữ bình thường vào ô kết quả không bị ảnh hưởng
  window.addEventListener("paste", (e) => {
    const item = [...(e.clipboardData ? e.clipboardData.items : [])].find((it) => it.kind === "file" && it.type.startsWith("image/"));
    if (!item) return;
    e.preventDefault();
    const blob = item.getAsFile();
    const ext = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp" }[blob && blob.type];
    if (!ext) return showAlert(BAD_TYPE_MSG);
    setFile(new File([blob], `anh-dan-${Date.now()}.${ext}`, { type: blob.type }));
  });

  // ---------- Xoay ảnh ----------
  function updateRotUi() {
    $("rotInfo").textContent = rotation ? `Đã xoay ${rotation}° theo chiều kim đồng hồ` : "";
    $("rotReset").hidden = !rotation;
  }

  // Vẽ ảnh xoay vào canvas (tối đa 1600px) và trả về data URL để xem trước
  function rotatedUrl(src, deg) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const k = Math.min(1, 1600 / Math.max(img.naturalWidth, img.naturalHeight));
        const w = Math.round(img.naturalWidth * k), h = Math.round(img.naturalHeight * k);
        const swap = deg % 180 !== 0;
        const c = document.createElement("canvas");
        c.width = swap ? h : w; c.height = swap ? w : h;
        const ctx = c.getContext("2d");
        ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height); // ảnh PNG trong suốt -> nền trắng
        ctx.translate(c.width / 2, c.height / 2);
        ctx.rotate((deg * Math.PI) / 180);
        ctx.drawImage(img, -w / 2, -h / 2, w, h);
        resolve(c.toDataURL("image/jpeg", 0.88));
      };
      img.onerror = reject;
      img.src = src;
    });
  }

  async function rotateBy(delta) {
    if (!file || busy || loading || !baseUrl) return;
    const my = token, next = (((rotation + delta) % 360) + 360) % 360;
    try {
      const url = next === 0 ? baseUrl : await rotatedUrl(baseUrl, next);
      if (my !== token) return;
      rotation = next;
      previewUrl = url;
      previewImg.src = url;
      updateRotUi();
      if (!results.hidden) setStatus("Ảnh đã xoay. Nhấn “Nhận diện chữ” để nhận diện lại.", "idle");
    } catch {
      showAlert("Không thể xoay ảnh xem trước. Vui lòng thử lại.");
    }
  }
  reflowBox.addEventListener("change", () => { if (!results.hidden) setStatus("Đã đổi cách ngắt dòng. Nhấn “Nhận diện chữ” để áp dụng.", "idle"); });
  $("rotLeft").addEventListener("click", () => rotateBy(-90));
  $("rotRight").addEventListener("click", () => rotateBy(90));
  $("rotReset").addEventListener("click", () => rotateBy(-rotation));

  // ---------- Gọi OCR ----------
  function setBusy(state) {
    busy = state;
    rotBtns.concat([autoBox, enhanceSel, reflowBox]).forEach((e) => { e.disabled = state; });
    cancelBtn.hidden = !state;
    cancelBtn.disabled = false;
    ocrBtn.disabled = state || !file;
    ocrBtn.classList.toggle("loading", state);
    btnText.textContent = state ? "Đang nhận diện..." : "🔍 Nhận diện chữ";
    $("removeBtn").disabled = state;
  }

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // OCR một ảnh. Trả về {ok, ...kết quả} hoặc {ok:false, message}
  async function ocrImage() {
    for (let attempt = 0; attempt < 6; attempt++) {
      if (cancelled) return { aborted: true };
      const body = new FormData();
      body.append("file", file);
      body.append("rotation", rotation);
      body.append("auto_orient", autoBox.checked ? "1" : "0");
      body.append("enhance", enhanceSel.value);
      body.append("reflow", reflowBox.checked ? "1" : "0");
      body.append("want_preview", "1");
      let res, json;
      try {
        res = await fetch("/api/ocr", { method: "POST", body, signal: abortCtl && abortCtl.signal });
      } catch (e) {
        if (e && e.name === "AbortError") return { aborted: true };
        return { ok: false, message: "Không thể kết nối tới máy chủ." };
      }
      try { json = await res.json(); } catch { json = null; }
      if (!json) return { ok: false, message: `Máy chủ trả về phản hồi không hợp lệ (mã ${res.status}).` };
      if (res.status === 429) { await sleep(1500); continue; } // máy chủ đang bận -> thử lại
      if (json.success) return { ok: true, ...json };
      if (res.status === 422) return { ok: false, empty: true, message: json.message, quality: json.quality, advice: json.advice };
      return { ok: false, message: json.message };
    }
    return { ok: false, message: "Hệ thống đang bận. Vui lòng thử lại sau ít giây." };
  }

  async function runOcr() {
    if (!file) return showAlert("Vui lòng chọn một ảnh trước khi nhận diện.");
    if (busy || loading) return; // chặn bấm nhiều lần
    const my = token;
    cancelled = false;
    abortCtl = new AbortController();
    setBusy(true);
    clearAlert();
    results.hidden = true;
    aiPanel.hidden = true;
    accResult = null; accStale = false;
    startTimer();
    try {
      working("Đang nhận diện văn bản...");
      setProgress(null);
      const r = await ocrImage();
      if (my !== token) return;
      if (r.aborted) { setStatus("Đã dừng.", "warn"); return; }
      if (!r.ok) {
        if (r.quality) showQuality(r.quality, "", r.advice);
        setStatus("Không thể xử lý file. Vui lòng thử lại.", "error");
        return showAlert(r.message, r.empty ? "warn" : "error");
      }
      const part = { text: r.text, lines: r.lines || [], processed: r.processed_preview || null, quality: r.quality, advice: r.input_advice || null,
        notes: r.notes || [], ms: r.elapsed_ms || 0, cached: !!r.cached, level: r.level, confidence: r.confidence, bad: r.bad_words || 0, paras: r.paragraphs || [] };
      original = part.text;
      edited = original;
      lineInfo = part.lines.slice();
      paraInfo = part.paras;
      render(part);
      setStatus("Nhận diện hoàn tất", "done");
    } catch {
      setStatus("Không thể xử lý file. Vui lòng thử lại.", "error");
      showAlert("Không thể xử lý file. Vui lòng thử lại.");
    } finally {
      stopTimer();
      abortCtl = null;
      if (my === token) { setBusy(false); setProgress(false); } else { setBusy(false); }
    }
  }
  ocrBtn.addEventListener("click", runOcr);
  cancelBtn.addEventListener("click", () => {
    cancelled = true;
    cancelBtn.disabled = true;
    if (abortCtl) abortCtl.abort(); // trang đang xử lý dở sẽ bị bỏ, các trang đã xong được giữ lại
    baseStatus = "Đang dừng..."; tick();
  });
  window.addEventListener("beforeunload", (e) => { if (busy) { e.preventDefault(); e.returnValue = ""; } });

  // ---------- Hiển thị & chỉnh sửa kết quả ----------
  function updateBadge() {
    badge.hidden = edited === original;
    if (accResult && accResult.target === "edited") { // Accuracy đo trên bản chỉnh sửa: nội dung đổi thì kết quả đã cũ
      const stale = resultText.value !== accResult.hyp;
      if (stale !== accStale) { accStale = stale; renderAcc(); }
    }
  }

  function render(part) {
    resultText.value = edited;
    $("resultImg").src = previewUrl;
    firstImgClass = part.quality ? `lv-${part.quality.level}` : "";
    $("resultImg").className = firstImgClass;
    lastPart = part;
    showProcessed();
    updateBadge();
    renderSummary([part]);
    renderLines();
    results.hidden = false;
    results.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  // Ảnh sau xử lý + danh sách việc hệ thống đã làm (ảnh gốc ở khung trên luôn giữ nguyên)
  function showProcessed() {
    const part = lastPart, notes = $("processedNotes"), pp = part && part.processed;
    $("processedBox").hidden = !pp;
    notes.replaceChildren();
    if (!pp) return;
    $("processedImg").src = pp;
    (part.notes && part.notes.length ? part.notes : ["Ảnh đủ tốt nên được giữ nguyên, không cần xử lý thêm."]).forEach((t) => notes.append(el("li", null, t)));
  }

  const worst = (lv) => (lv.includes("red") ? "red" : lv.includes("yellow") ? "yellow" : "green");

  function tile(cls, name, val, pct, cap) {
    const t = el("div", `tile ${cls}`);
    t.append(el("div", "tname", name), el("div", "tval", val));
    if (pct != null) {
      const bar = el("div", "bar"), fill = el("i", cls);
      fill.style.width = `${Math.max(0, Math.min(100, pct))}%`;
      bar.append(fill); t.append(bar);
    }
    t.append(el("p", "tcap", cap));
    return t;
  }

  // Quality Score = ảnh đầu vào · OCR Confidence = độ tự tin của model · Accuracy = đúng bao nhiêu so với Ground Truth
  function renderSummary(parts) {
    const box = $("summary");
    box.replaceChildren();
    let num = 0, den = 0;
    const count = { green: 0, yellow: 0, red: 0 };
    lineInfo.forEach((l) => {
      count[l.level]++;
      if (l.conf != null) { const n = Math.max(1, l.text.length); num += l.conf * n; den += n; }
    });
    const overall = den ? Math.round((num / den) * 10) / 10 : null;
    const lvl = overall == null ? "yellow" : levelOf(overall);

    const qs = parts.filter((x) => x.quality);
    let qTile;
    if (qs.length) {
      const score = Math.round(qs.reduce((a, x) => a + x.quality.score, 0) / qs.length), ql = worst(qs.map((x) => x.quality.level));
      const bad = qs.filter((x) => x.quality.level !== "green").length;
      const cap = qs.length === 1
        ? (qs[0].advice ? qs[0].advice.summary : LV[ql])
        : "";
      qTile = tile(ql, `${ICON[ql]} Quality Score · chất lượng ảnh đầu vào`, `${score}%`, score, cap);
    } else {
      qTile = tile("none", "Quality Score · chất lượng ảnh đầu vào", "—", null, "Chưa có điểm chất lượng cho ảnh này.");
    }
    const cTile = tile(overall == null ? "none" : lvl, `${overall == null ? "" : ICON[lvl] + " "}OCR Confidence · độ tự tin của model`, overall == null ? "—" : `${overall}%`, overall,
      {
        
      }[lvl]);
    const aTile = tile("none", "Accuracy · so với Ground Truth", "Chưa đánh giá", null, "");
    const tiles = el("div", "tiles");
    tiles.append(qTile, cTile, aTile);
    accTileEl = aTile;

    const chips = el("div", "chips");
    chips.append(el("span", "chip green", `● ${count.green} dòng tốt`), el("span", "chip yellow", `● ${count.yellow} dòng cần xem`), el("span", "chip red", `● ${count.red} dòng nghi sai`));
    const bad = parts.reduce((a, x) => a + x.bad, 0);
    if (bad) chips.append(el("span", "chip", `Từ nghi sai chính tả/dấu: ${bad}`));
    const ms = parts.reduce((a, x) => a + x.ms, 0);
    chips.append(el("span", "chip", `⏱ ${(ms / 1000).toFixed(1)} giây${parts.every((x) => x.cached) ? " (từ bộ nhớ đệm)" : ""}`));
    [...new Set(parts.flatMap((x) => x.notes))].forEach((n) => chips.append(el("span", "chip", `🛠 ${n}`)));

    box.append(tiles, chips, el("p", "muted tilenote", "Quality Score cho biết ảnh dễ hay khó đọc; OCR Confidence cho biết model tự tin đến đâu; Accuracy là độ đúng thật so với văn bản chuẩn"));

    const pq = $("pageQuality");
    pq.replaceChildren();
    parts.forEach((x) => { if (x.quality) pq.append(el("span", `chip ${x.quality.level}`, `Ảnh: Quality ${x.quality.score}%`)); });
    renderAcc();
  }

  // ---------- Accuracy (chỉ khi có Ground Truth) ----------
  let accResult = null, accStale = false, accTileEl = null, accBusy = false;

  function renderAcc() {
    const st = $("accStatus"), det = $("accDetail");
    det.replaceChildren();
    let t;
    if (!accResult || !accResult.evaluated) {
      st.className = "accstatus none";
      st.textContent = "Accuracy: Chưa đánh giá";
      det.hidden = true;
      t = tile("none", "Accuracy · so với Ground Truth", "Chưa đánh giá", null, "Cần nhập Ground Truth ở mục Accuracy bên dưới");
    } else {
      const r = accResult, lv = levelOf(r.char_accuracy);
      st.className = `accstatus ${accStale ? "stale" : lv}`;
      st.textContent = `Accuracy: ${r.char_accuracy}% · CER: ${r.cer}% · WER: ${r.wer}%` + (accStale ? " — nội dung đã thay đổi, hãy tính lại" : "");
      det.append(
        el("span", "chip", `Word Accuracy: ${r.word_accuracy}%`),
        el("span", "chip", `So với: ${r.target === "edited" ? "nội dung đang chỉnh sửa" : "kết quả OCR gốc"}`),
        el("span", "chip", `Ground Truth: ${r.ref_chars} ký tự · ${r.ref_words} từ`),
        el("span", "chip", `Sai lệch: ${r.char_distance} ký tự · ${r.word_distance} từ`),
      );
      if (r.options.ignore_case || r.options.ignore_punct) det.append(el("span", "chip", `Nới lỏng: ${[r.options.ignore_case && "bỏ qua HOA/thường", r.options.ignore_punct && "bỏ qua dấu câu"].filter(Boolean).join(", ")}`));
      det.hidden = false;
      t = tile(accStale ? "none" : lv, "Accuracy · so với Ground Truth", `${r.char_accuracy}%`, r.char_accuracy, `CER ${r.cer}% · WER ${r.wer}%${accStale ? " (đã cũ)" : ""}`);
    }
    if (accTileEl && accTileEl.isConnected) accTileEl.replaceWith(t);
    accTileEl = t;
  }

  $("gtBtn").addEventListener("click", async () => {
    if (accBusy) return;
    const gt = $("gtText").value;
    if (!gt.trim()) { accResult = null; accStale = false; renderAcc(); return toast("Chưa có Ground Truth — chưa thể đánh giá Accuracy"); }
    if (!original) return toast("Chưa có kết quả OCR để so sánh");
    const target = $("gtTarget").value, hyp = target === "edited" ? resultText.value : original;
    const btn = $("gtBtn"), label = btn.textContent;
    accBusy = true; btn.disabled = true; btn.textContent = "Đang tính...";
    try {
      const res = await fetch("/api/accuracy", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ hypothesis: hyp, reference: gt, ignore_case: $("gtCase").checked, ignore_punct: $("gtPunct").checked }) });
      const json = await res.json().catch(() => null);
      if (!json || !json.success) throw new Error(json && json.message ? json.message : "Không tính được Accuracy. Vui lòng thử lại.");
      accResult = json.evaluated ? { ...json, target, hyp } : null;
      accStale = false;
      renderAcc();
      if (!json.evaluated) toast("Chưa có Ground Truth — chưa thể đánh giá Accuracy");
    } catch (e) {
      showAlert(e.message || "Không tính được Accuracy. Vui lòng thử lại.");
    } finally {
      accBusy = false; btn.disabled = false; btn.textContent = label;
    }
  });
  $("gtClear").addEventListener("click", () => { $("gtText").value = ""; accResult = null; accStale = false; renderAcc(); });
  $("gtPdf").addEventListener("change", async (e) => {
    const f = e.target.files[0];
    e.target.value = "";
    if (!f) return;
    if (!/\.pdf$/i.test(f.name)) return showAlert("Chỉ nhận file PDF có sẵn chữ làm Ground Truth. Ảnh phải qua OCR mới có chữ nên không dùng được.");
    if (f.size > MAX_GT_PDF) return showAlert("File PDF quá lớn, vui lòng chọn file nhỏ hơn 20 MB.");
    const lbl = e.target.parentElement, label = lbl.firstChild.textContent;
    lbl.firstChild.textContent = "Đang đọc PDF...";
    try {
      const body = new FormData(); body.append("file", f);
      const res = await fetch("/api/ground-truth-from-pdf", { method: "POST", body });
      const json = await res.json().catch(() => null);
      if (!json || !json.success) return showAlert(json ? json.message : "Không thể kết nối tới máy chủ.");
      $("gtText").value = json.text;
      accResult = null; accStale = false; renderAcc();
      clearAlert();
      showAlert(`Đã lấy Ground Truth từ lớp chữ của PDF (${json.pages} trang, ${json.chars} ký tự). Hãy xem lại rồi bấm “Tính CER / WER”.`, "success");
    } catch {
      showAlert("Không thể kết nối tới máy chủ. Vui lòng thử lại.");
    } finally {
      lbl.firstChild.textContent = label;
    }
  });
  $("gtFile").addEventListener("change", async (e) => {
    const f = e.target.files[0];
    e.target.value = "";
    if (!f) return;
    if (f.size > 2 * 1024 * 1024) return showAlert("File Ground Truth quá lớn (tối đa 2 MB).");
    try { $("gtText").value = (await f.text()).replace(/^\uFEFF/, ""); toast("Đã mở Ground Truth — bấm “Tính CER / WER”"); }
    catch { showAlert("Không đọc được file Ground Truth."); }
  });

  function renderLines() {
    const list = $("lineList"), only = $("onlyBad").checked;
    list.replaceChildren();
    const seen = new Map(); // đếm số lần một nội dung đã xuất hiện: để bấm vào dòng trùng vẫn chọn đúng dòng
    lineInfo.forEach((l) => {
      const nth = seen.get(l.text) || 0;
      seen.set(l.text, nth + 1);
      if (only && l.level === "green") return;
      const row = el("div", `lrow ${l.level}`);
      row.title = "Bấm để chọn dòng này trong ô chỉnh sửa";
      row.tabIndex = 0;
      row.append(el("span", "pct", l.conf == null ? "—" : `${Math.round(l.conf)}%`));
      const t = el("span", "t", l.text);
      if (l.bad.length) t.append(el("div", "w", `⚠ Từ nghi sai: ${l.bad.join(", ")}`));
      row.append(t);
      const go = () => selectInEditor(l.text, nth);
      row.addEventListener("click", go);
      row.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } });
      list.append(row);
    });
    if (!list.children.length) list.append(el("div", "lpage", "Không có dòng nào cần kiểm tra 🎉"));
  }
  $("onlyBad").addEventListener("change", renderLines);

  function selectInEditor(text, nth = 0) {
    const v = resultText.value;
    let i = -1;
    for (let k = 0, from = 0; k <= nth; k++) { i = v.indexOf(text, from); if (i < 0) break; from = i + Math.max(1, text.length); }
    if (i < 0) i = v.indexOf(text); // dòng trùng đã bị sửa/xóa bớt -> chọn lần xuất hiện đầu tiên
    if (i < 0) return toast("Dòng này đã được chỉnh sửa");
    resultText.focus();
    resultText.setSelectionRange(i, i + text.length);
    const before = v.slice(0, i).split("\n").length - 1, total = v.split("\n").length;
    resultText.scrollTop = Math.max(0, (before / total) * resultText.scrollHeight - resultText.clientHeight / 2);
  }

  // Mọi thao tác gõ / dán / xóa đều chỉ cập nhật bản "edited", KHÔNG đụng tới "original"
  resultText.addEventListener("input", () => { edited = resultText.value; updateBadge(); });

  function setEdited(v) { edited = v; resultText.value = v; updateBadge(); }

  // ---------- Sao chép ----------
  async function copyText() {
    const text = resultText.value;
    if (!text) return showAlert("Không có nội dung để sao chép.", "warn");
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      try { // dự phòng cho trình duyệt không cho dùng Clipboard API
        resultText.focus(); resultText.select();
        if (!document.execCommand("copy")) throw new Error();
        resultText.setSelectionRange(text.length, text.length);
      } catch {
        return showAlert("Trình duyệt không cho phép sao chép. Hãy chọn văn bản rồi nhấn Ctrl+C.");
      }
    }
    clearAlert();
    toast("Đã sao chép văn bản");
  }
  $("copyBtn").addEventListener("click", copyText);

  // ---------- Xóa / Khôi phục ----------
  $("clearBtn").addEventListener("click", () => {
    if (!resultText.value) return toast("Nội dung đang trống");
    if (!confirm("Bạn có chắc muốn xóa nội dung hiện tại?\n(Kết quả OCR ban đầu vẫn được giữ, có thể khôi phục.)")) return;
    setEdited("");
    resultText.focus();
    toast("Đã xóa nội dung");
  });

  $("restoreBtn").addEventListener("click", () => {
    if (!original) return showAlert("Chưa có kết quả OCR để khôi phục.", "warn");
    if (edited === original) return toast("Nội dung đang là kết quả OCR ban đầu");
    if (edited && !confirm("Khôi phục sẽ thay thế nội dung bạn đã chỉnh sửa bằng kết quả OCR ban đầu. Tiếp tục?")) return;
    setEdited(original);
    toast("Đã khôi phục kết quả OCR");
  });

  // ---------- Tải file ----------
  function download(blob, name) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.rel = "noopener";
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000); // để trình duyệt kịp ghi file (thu hồi quá sớm làm tải về bị hỏng/không chạy)
  }

  $("txtBtn").addEventListener("click", () => {
    if (!resultText.value.trim()) return showAlert("Không có nội dung để xuất TXT.", "warn");
    try {
      download(new Blob([resultText.value], { type: "text/plain;charset=utf-8" }), `${baseName()}_${suffix()}.txt`);
      clearAlert();
    } catch {
      showAlert("Không thể tải file TXT. Vui lòng thử lại.");
    }
  });

  let exporting = false;
  $("pdfBtn").addEventListener("click", async () => {
    if (exporting) return;
    if (!resultText.value.trim()) return showAlert("Không có nội dung để xuất PDF.", "warn");
    exporting = true;
    const btn = $("pdfBtn"), label = btn.textContent;
    btn.disabled = true; btn.textContent = "Đang tạo PDF...";
    try {
      const res = await fetch("/api/export-pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: resultText.value }),
      });
      if (!res.ok) {
        const json = await res.json().catch(() => null);
        throw new Error(json && json.message ? json.message : `Máy chủ không tạo được PDF (mã ${res.status}).`);
      }
      const buf = await res.arrayBuffer();
      const head = new TextDecoder("latin1").decode(new Uint8Array(buf, 0, Math.min(5, buf.byteLength)));
      if (!head.startsWith("%PDF")) throw new Error("File PDF nhận về không hợp lệ. Hãy khởi động lại ứng dụng rồi thử lại.");
      download(new Blob([buf], { type: "application/pdf" }), `${baseName()}_${suffix()}.pdf`);
      clearAlert();
    } catch (e) {
      showAlert(e && e.message && !/Failed to fetch|NetworkError/i.test(e.message) ? e.message : "Không thể tạo file PDF (không kết nối được máy chủ). Hãy kiểm tra ứng dụng còn đang chạy rồi thử lại.");
    } finally {
      exporting = false; btn.disabled = false; btn.textContent = label;
    }
  });

  // ---------- AI Review (tùy chọn): chỉ ĐỀ XUẤT, người dùng xác nhận mới thay đổi ----------
  // Luồng: kết quả OCR -> Confidence -> AI kiểm tra -> phát hiện nghi vấn -> đề xuất -> bạn bấm xác nhận -> kết quả cuối.
  // "Kết quả OCR gốc" (original) không bao giờ bị ghi đè; mọi thay đổi chỉ vào bản đang chỉnh sửa (edited) và khôi phục được.
  fetch("/api/config").then((r) => r.json()).then((j) => { aiAvailable = !!j.ai_available; aiProvider = j.ai_provider || "AI"; }).catch(() => {});
  const AI_DOWN = "AI kiểm tra hiện không khả dụng. Kết quả OCR vẫn được giữ nguyên.";

  // Các dòng cần kiểm tra theo kiểm tra CỤC BỘ (độ tin cậy thấp / từ không thể là tiếng Việt) - dùng được cả khi không có AI.
  // Lưu ý: confidence thấp chỉ là dấu hiệu cần xem lại, không có nghĩa chắc chắn sai.
  function localFlags() {
    return lineInfo.filter((l) => l.level !== "green" && l.text.trim());
  }

  function flagSection(title, items) {
    const wrap = el("div");
    wrap.append(el("div", "sect", title));
    const ul = el("ul", "flaglist");
    items.slice(0, 30).forEach((l) => {
      const li = el("li", null, `${l.conf == null ? "" : `[${Math.round(l.conf)}%] `}${l.text}${l.bad && l.bad.length ? ` — từ nghi sai: ${l.bad.join(", ")}` : ""}`);
      if (l.msg) li.append(el("div", "why", l.msg));
      li.title = "Bấm để chọn dòng này trong ô chỉnh sửa";
      li.addEventListener("click", () => selectInEditor(l.text, 0));
      ul.append(li);
    });
    if (items.length > 30) ul.append(el("li", null, `… và ${items.length - 30} dòng khác (xem mục OCR Confidence từng dòng)`));
    wrap.append(ul);
    return wrap;
  }

  function renderAiDown(detail) {
    aiPanel.replaceChildren();
    aiPanel.hidden = false;
    aiPanel.append(el("p", "down", `⚠ ${AI_DOWN}`));
    if (detail) aiPanel.append(el("p", "ainote", detail));
    const flags = localFlags();
    if (flags.length) aiPanel.append(flagSection(`Cần kiểm tra (kiểm tra cục bộ, không dùng AI) — ${flags.length} dòng`, flags));
    const close = el("button", "btn-secondary", "Đóng");
    close.type = "button";
    close.addEventListener("click", () => { aiPanel.hidden = true; });
    const acts = el("div", "acts"); acts.append(close);
    aiPanel.append(acts);
  }

  // Áp dụng MỘT đề xuất vào bản đang chỉnh sửa. Tìm đúng dòng theo nội dung (vì bạn có thể đã sửa/xóa dòng khác từ lúc AI kiểm tra).
  function applyChange(c) {
    const arr = resultText.value.split("\n");
    let idx = arr[c.i] === c.before ? c.i : -1;
    if (idx < 0) {
      const hits = arr.map((t, k) => (t === c.before ? k : -1)).filter((k) => k >= 0);
      if (hits.length) idx = hits.reduce((best, k) => (Math.abs(k - c.i) < Math.abs(best - c.i) ? k : best));
    }
    if (idx < 0) return false; // dòng đã bị bạn chỉnh sửa -> không ghi đè
    arr[idx] = c.after;
    setEdited(arr.join("\n"));
    return true;
  }

  $("aiBtn").addEventListener("click", async () => {
    if (aiBusy) return;
    const snap = resultText.value;
    if (!snap.trim()) return showAlert("Không có nội dung để kiểm tra.", "warn");
    if (!aiAvailable) return renderAiDown("Chưa cấu hình AI (đặt biến môi trường GEMINI_API_KEY rồi chạy lại ứng dụng).");
    if (!confirm(`Chỉ NỘI DUNG VĂN BẢN (không gồm ảnh) sẽ được gửi tới dịch vụ ${aiProvider} để kiểm tra. Kết quả OCR của bạn sẽ không bị tự động thay đổi. Tiếp tục?`)) return;

    const conf = new Map([...lineInfo, ...paraInfo].map((l) => [l.text, l.conf]));
    const lines = snap.split("\n").map((t, i) => ({ i, text: t, conf: conf.has(t) ? conf.get(t) : null })).filter((l) => l.text.trim());
    const btn = $("aiBtn"), label = btn.textContent;
    aiBusy = true; btn.disabled = true;
    clearAlert();
    // Gửi theo từng lô nhỏ: mỗi yêu cầu ngắn, lô nào lỗi thì vẫn giữ kết quả các lô trước
    const merged = { changes: [], warnings: [], rejected: [], model: "", failed: 0 };
    let done = 0, err = null;
    try {
      for (let k = 0; k < lines.length; k += AI_BATCH) {
        btn.textContent = `🤖 AI đang kiểm tra ${Math.min(k + AI_BATCH, lines.length)}/${lines.length} dòng...`;
        let json = null;
        try {
          const res = await fetch("/api/ai-review", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ lines: lines.slice(k, k + AI_BATCH) }) });
          json = await res.json().catch(() => null);
        } catch { json = null; }
        if (!json || !json.success) { err = json ? (json.detail || json.message) : "Không thể kết nối tới máy chủ."; break; }
        merged.changes.push(...json.changes);
        merged.warnings.push(...json.warnings);
        merged.rejected.push(...(json.rejected || []));
        merged.model = json.model || merged.model;
        merged.failed += json.failed || 0;
        done = Math.min(k + AI_BATCH, lines.length);
      }
      if (!done) return renderAiDown(err); // OCR không bị ảnh hưởng, chỉ AI không dùng được
      merged.notice = err ? `AI mới kiểm tra được ${done}/${lines.length} dòng đầu. Lỗi: ${err}`
        : merged.failed ? "Một số đoạn văn bản chưa kiểm tra được do dịch vụ AI quá tải. Có thể bấm kiểm tra lại." : "";
      merged.sent = lines.slice(0, done);
      renderAi(merged);
    } catch {
      renderAiDown("");
    } finally {
      aiBusy = false; btn.disabled = false; btn.textContent = label;
    }
  });

  function renderAi(json) {
    aiPanel.replaceChildren();
    aiPanel.hidden = false;
    const { changes, warnings } = json;
    const head = el("div", "aihead");
    head.append(el("b", null, changes.length ? `🟡 Phát hiện ${changes.length} vị trí có khả năng sai.` : "🟢 AI không thấy lỗi OCR rõ ràng cần sửa."));
    if (json.model) head.append(el("span", "why", `(${json.model})`));
    aiPanel.append(head, el("p", "ainote", "AI chỉ đề xuất — chưa có gì bị thay đổi. Kết quả OCR gốc luôn được giữ và có thể khôi phục. AI không chắc chắn thì giữ nguyên và ghi “cần kiểm tra”."));
    if (json.notice) aiPanel.append(el("p", "why warnline", `⚠ ${json.notice}`));

    const cards = [];
    changes.forEach((c) => {
      const card = el("div", "chg");
      card.append(el("div", "meta", `Dòng ${c.i + 1}${c.conf == null ? "" : ` · OCR Confidence dòng này: ${Math.round(c.conf)}%`}`));
      card.append(el("div", "ctx", `OCR gốc: ${c.before}`));
      if (c.edits && c.edits.length) {
        c.edits.forEach((e) => {
          const d = el("div", "edit");
          d.append(el("del", null, e.from || "∅"), document.createTextNode("  →  "), el("ins", null, e.to || "(xóa)"));
          card.append(d);
        });
      } else { // chỉ đổi khoảng trắng/dấu câu giữa các từ
        const d = el("div", "edit"); d.append(el("del", null, c.before), document.createTextNode("  →  "), el("ins", null, c.after));
        card.append(d);
      }
      if (c.reason) card.append(el("div", "why", `Lý do: ${c.reason}`));
      if (c.risky) card.append(el("div", "flag risk", `⚠ Cần kiểm tra kỹ (${(c.risk_reasons || ["số liệu"]).join("; ")}) — hãy đối chiếu ảnh gốc, không nằm trong “áp dụng tất cả”.`));
      if (c.weak) card.append(el("div", "flag weak", "Bằng chứng yếu: dòng này có độ tin cậy cao và không có từ nghi sai. Nếu ảnh gốc đã đúng thì hãy giữ nguyên."));
      else if (c.evidence && c.evidence.length) card.append(el("div", "why", `Căn cứ: ${c.evidence.join("; ")}`));

      const row = el("div", "row");
      const apply = el("button", "btn-secondary", "Áp dụng chỉnh sửa"), keep = el("button", "btn-secondary", "Giữ nguyên");
      apply.type = keep.type = "button";
      const settle = (text, kept) => { row.replaceWith(el("div", `state${kept ? " kept" : ""}`, text)); card.classList.add("done"); };
      apply.addEventListener("click", () => {
        if (c.risky && !confirm("Thay đổi này liên quan số liệu/mã/tên riêng/ký hiệu. Bạn đã đối chiếu với ảnh gốc và chắc chắn muốn áp dụng?")) return;
        if (!applyChange(c)) return toast("Dòng này đã được bạn chỉnh sửa nên không áp dụng");
        c.state = "applied"; settle("✔ Đã áp dụng (có thể khôi phục kết quả OCR)", false); refreshAll();
      });
      keep.addEventListener("click", () => { c.state = "kept"; settle("Đã giữ nguyên", true); refreshAll(); });
      row.append(apply, keep);
      card.append(row);
      cards.push({ c, card });
      aiPanel.append(card);
    });

    if (warnings.length) {
      aiPanel.append(flagSection(`Cần kiểm tra — AI nghi ngờ nhưng không tự sửa (${warnings.length})`,
        warnings.map((w) => ({ text: w.text, conf: w.conf, bad: [], msg: w.msg }))));
    }

    const acts = el("div", "acts");
    const all = el("button", "btn-secondary", "Áp dụng tất cả đề xuất an toàn"), close = el("button", "btn-secondary", "Đóng");
    all.type = close.type = "button";
    const safe = () => cards.filter(({ c }) => !c.state && !c.risky && !c.weak);
    function refreshAll() {
      const n = safe().length, skipped = cards.filter(({ c }) => !c.state && (c.risky || c.weak)).length;
      all.textContent = `Áp dụng tất cả đề xuất an toàn (${n})`;
      all.disabled = n === 0;
      all.title = skipped ? `${skipped} đề xuất cần kiểm tra kỹ/bằng chứng yếu sẽ không được áp dụng hàng loạt` : "";
    }
    all.addEventListener("click", () => {
      let ok = 0;
      safe().forEach(({ c, card }) => {
        if (!applyChange(c)) return;
        c.state = "applied"; ok++;
        const row = card.querySelector(".row");
        if (row) row.replaceWith(el("div", "state", "✔ Đã áp dụng (có thể khôi phục kết quả OCR)"));
        card.classList.add("done");
      });
      refreshAll();
      toast(ok ? `Đã áp dụng ${ok} đề xuất (có thể khôi phục kết quả OCR)` : "Không có đề xuất nào áp dụng được");
    });
    close.addEventListener("click", () => { aiPanel.hidden = true; });
    if (cards.length) acts.append(all);
    acts.append(close);
    aiPanel.append(acts);
    refreshAll();

    // Kiểm tra AI input/output: xem chính xác dữ liệu đã gửi đi (chỉ văn bản) và những gì hệ thống đã loại
    const io = el("details", "io");
    io.append(el("summary", null, "Xem dữ liệu đã gửi cho AI và phản hồi đã lọc"));
    io.append(el("div", "why", `Đã gửi ${json.sent.length} dòng văn bản (không gồm ảnh). Dạng: số dòng | độ tin cậy | nội dung.`));
    const preSent = el("pre", null, json.sent.slice(0, 200).map((l) => `${l.i}|${l.conf == null ? "?" : Math.round(l.conf) + "%"}|${l.text}`).join("\n") + (json.sent.length > 200 ? `\n… (${json.sent.length - 200} dòng nữa)` : ""));
    io.append(preSent);
    io.append(el("div", "why", `AI trả về ${changes.length} đề xuất hợp lệ, ${warnings.length} cảnh báo; hệ thống loại ${json.rejected.length} đề xuất không an toàn.`));
    if (json.rejected.length) io.append(el("pre", null, json.rejected.map((r) => `Dòng ${r.i + 1}: ${r.before ? `“${r.before}” → ` : ""}“${r.after}”\n  Bị loại: ${r.why}`).join("\n")));
    aiPanel.append(io);
  }
})();
