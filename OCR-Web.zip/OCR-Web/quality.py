"""
Đánh giá chất lượng ảnh ĐẦU VÀO (Quality Score): độ nét, độ sáng, độ tương phản, độ phân giải,
nhiễu, nền không đều, bóng đổ, độ nghiêng.
Xanh = tốt, vàng = cần chú ý, đỏ = kém. Các ngưỡng là kinh nghiệm thực tế, mang tính cảnh báo.

LƯU Ý: Quality Score chỉ nói ảnh "dễ hay khó đọc". Nó KHÔNG phải OCR Confidence (độ chắc chắn của model)
và càng KHÔNG phải Accuracy (độ chính xác thật, chỉ tính được khi có Ground Truth - xem accuracy.py).
(Phần tối ưu ảnh nằm trong preprocess.py.)
"""

import math

import cv2
import numpy as np

GREEN, YELLOW, RED = "green", "yellow", "red"
_RANK = {GREEN: 0, YELLOW: 1, RED: 2}

NOISE_RED = 12.0          # ước lượng độ lệch chuẩn nhiễu; > mức này preprocess cũng bỏ qua làm nét (vàng: DENOISE_SIGMA)
UNEVEN_RED = 0.45         # độ chênh sáng nền (vàng: preprocess.FLATTEN_UNEVEN)
SKEW_WARN, SKEW_BAD = 3.0, 20.0   # độ nghiêng (độ); > SKEW_BAD vượt khả năng tự chỉnh của ocr_engine


def _grade(value, red_below, yellow_below):
    return RED if value < red_below else YELLOW if value < yellow_below else GREEN


# Trang chữ dày thường có ~60% điểm ảnh nằm gần nét chữ. Nhân với hệ số này để số đo độ nét của trang dày
# trùng với cách đo cũ -> các ngưỡng (35 / 90) và các bước làm nét trong preprocess vẫn đúng như đã chỉnh.
_DENSE_INK_FRACTION = 0.6


def measure(gray):
    """
    Đo độ nét, độ sáng, độ tương phản của ảnh xám (đã chuẩn hóa về tối đa 1000px).
    Để trang ÍT CHỮ (nhiều nền trắng) không bị đánh giá oan:
      - độ nét chỉ đo ở vùng quanh nét chữ (vùng nền phẳng có độ nét ~0 sẽ kéo thấp giá trị);
      - độ tương phản là khoảng sáng-tối thực tế (phân vị 0,2% - 99,8%) thay vì độ lệch chuẩn toàn ảnh.
    """
    h, w = gray.shape[:2]
    if max(w, h) > 1000:  # chuẩn hóa kích thước để độ nét so sánh được giữa các ảnh
        k = 1000 / max(w, h)
        gray = cv2.resize(gray, (max(1, int(w * k)), max(1, int(h * k))), interpolation=cv2.INTER_AREA)

    g = gray.astype(np.float32)
    lap = cv2.Laplacian(g, cv2.CV_32F)
    mean_l = cv2.blur(g, (25, 25))
    local_std = np.sqrt(np.maximum(cv2.blur(g * g, (25, 25)) - mean_l * mean_l, 0))
    ink_zone = local_std > 12
    sharp = float(lap[ink_zone].var()) * _DENSE_INK_FRACTION if ink_zone.mean() > 0.005 else float(lap.var())

    lo, hi = np.percentile(gray, (0.2, 99.8))
    return {
        "sharpness": sharp,
        "brightness": float(gray.mean()),
        "contrast": float(gray.std()),
        "range": float(hi - lo),
        "darkest": float(lo),
    }


def estimate_skew_deg(gray):
    """
    Ước lượng độ nghiêng của dòng chữ (độ, dương = nghiêng xuống phải) bằng "projection profile":
    xoay thử các góc, góc nào làm các dòng chữ tách rời rõ nhất (phương sai tổng mực theo hàng lớn nhất) là góc thật.
    Trả về None nếu ảnh không đủ chữ để kết luận (trang trống, ảnh không phải văn bản...).
    """
    h, w = gray.shape[:2]
    k = 500.0 / max(h, w) if max(h, w) > 500 else 1.0
    small = cv2.resize(gray, (max(1, int(w * k)), max(1, int(h * k))), interpolation=cv2.INTER_AREA) if k < 1 else gray
    ink = cv2.threshold(cv2.GaussianBlur(small, (3, 3), 0), 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    frac = float(np.count_nonzero(ink)) / ink.size
    if not 0.004 <= frac <= 0.45:
        return None
    ink = cv2.dilate(ink, np.ones((1, 5), np.uint8))   # nối các chữ cùng dòng lại với nhau
    ph, pw = ink.shape
    big = int(math.hypot(ph, pw)) + 2                   # khung đủ rộng để xoay không mất mực
    canvas = np.zeros((big, big), np.uint8)
    y0, x0 = (big - ph) // 2, (big - pw) // 2
    canvas[y0:y0 + ph, x0:x0 + pw] = ink

    def score(angle):
        m = cv2.getRotationMatrix2D((big / 2, big / 2), angle, 1.0)
        rot = cv2.warpAffine(canvas, m, (big, big), flags=cv2.INTER_NEAREST)
        return float(np.var(rot.sum(axis=1, dtype=np.float64)))

    coarse = {a: score(a) for a in range(-25, 26, 1)}
    best = max(coarse, key=coarse.get)
    fine = {best + d / 4.0: None for d in range(-3, 4)}
    for a in fine:
        fine[a] = score(a)
    best_a = max(fine, key=fine.get)
    base = score(0.0)
    if base <= 0 or fine[best_a] / base < 1.25:   # không rõ ràng hơn hướng thẳng -> không kết luận
        return 0.0 if abs(best_a) < SKEW_WARN else None
    return float(-best_a)                           # đổi dấu: dương = dòng chữ đi xuống về bên phải


def measure_extra(gray):
    """Nhiễu, độ chênh sáng nền, bóng đổ, độ nghiêng. Chạy trên ảnh xám (tự thu nhỏ về tối đa ~900px)."""
    import preprocess  # nạp muộn: preprocess cũng import quality

    def fit(g, side):
        h, w = g.shape[:2]
        if max(w, h) <= side:
            return g
        k = side / max(w, h)
        return cv2.resize(g, (max(1, int(w * k)), max(1, int(h * k))), interpolation=cv2.INTER_AREA)

    # Nhiễu đo ở cùng thang với bước khử nhiễu thật (preprocess._enhance chạy trên ảnh tối đa MAX_SIDE px),
    # nếu thu nhỏ hơn thì nhiễu bị trung bình hóa và ước lượng thấp đi -> đề xuất sẽ không khớp việc hệ thống làm.
    out = {"noise": float(preprocess.estimate_noise(fit(gray, preprocess.MAX_SIDE))), "unevenness": 0.0, "shadow": False, "skew": None}
    gray = fit(gray, 900)
    if float(np.median(gray)) >= 110:   # nền tối (chữ sáng): các phép đo nền giả định chữ tối trên nền sáng nên bỏ qua
        out["unevenness"] = float(preprocess.illumination_unevenness(gray))
        if out["unevenness"] > preprocess.FLATTEN_UNEVEN:
            # Bóng đổ = vùng tối có RANH GIỚI rõ; sáng không đều thường là dải chuyển mượt (đèn một phía)
            bg = preprocess._estimate_background(gray).astype(np.float32)
            gm = cv2.magnitude(cv2.Sobel(bg, cv2.CV_32F, 1, 0, ksize=3), cv2.Sobel(bg, cv2.CV_32F, 0, 1, ksize=3))
            out["shadow"] = bool(np.percentile(gm, 99) > 6.0 * max(0.05, float(gm.mean())))
    out["skew"] = estimate_skew_deg(gray)
    return out


def _finish(issues, metrics):
    level = max((i["level"] for i in issues), key=_RANK.get, default=GREEN)
    score = max(0, 100 - 35 * sum(i["level"] == RED for i in issues) - 15 * sum(i["level"] == YELLOW for i in issues))
    return {"level": level, "score": score, "issues": issues, "metrics": metrics}


def add_issue(q, level, code, label, message, suggestion=""):
    """Thêm một vấn đề phát hiện SAU khi đo (vd: engine thấy chữ quá nhỏ / không có vùng chữ) và tính lại điểm, mức."""
    issues = list(q["issues"]) + [{"level": level, "label": label, "message": message, "code": code, "suggestion": suggestion}]
    return _finish(issues, q["metrics"])


def assess(image, check_resolution=True):
    """
    Trả về dict: level, score (0-100), issues [{level, label, message, code, suggestion}], metrics.
    score là QUALITY SCORE của ảnh đầu vào - không liên quan tới độ chính xác OCR.
    """
    import preprocess
    w, h = image.size
    gray = np.array(image.convert("L"))
    m = measure(gray)
    x = measure_extra(gray)
    sharp, mean, rng = m["sharpness"], m["brightness"], m["range"]
    issues = []

    def add(level, code, label, message, suggestion=""):
        issues.append({"level": level, "label": label, "message": message, "code": code, "suggestion": suggestion})

    lv = _grade(sharp, 35, 90)
    if lv != GREEN:
        add(lv, "blur", "Độ nét", "Ảnh bị mờ hoặc rung. Hãy chụp lại gần hơn, giữ chắc tay hoặc dùng ảnh gốc rõ hơn.",
            "Có thể làm nét ảnh trước khi nhận diện; nếu quá mờ thì nên chụp lại.")
    if mean < 100:
        lv = RED if mean < 60 else YELLOW
        add(lv, "dark", "Độ sáng", "Ảnh quá tối, chữ có thể bị mất. Hãy chụp nơi đủ sáng.",
            "Có thể tăng tương phản cục bộ; tốt nhất là chụp lại nơi đủ sáng.")
    elif mean > 248 and m["darkest"] > 150:  # nền trắng VÀ không có điểm tối nào -> mới coi là trống/cháy sáng
        add(YELLOW, "bright", "Độ sáng", "Ảnh quá sáng hoặc gần như trống, chữ nhạt có thể bị mất.",
            "Giảm độ sáng/đèn flash khi chụp để chữ không bị cháy.")
    lv = _grade(rng, 45, 90)
    if lv != GREEN:
        add(lv, "contrast", "Độ tương phản", "Chữ và nền khó phân biệt (chữ nhạt hoặc nền nhiễu).",
            "Có thể tăng tương phản trước khi nhận diện.")
    if x["noise"] > preprocess.DENOISE_SIGMA:
        add(RED if x["noise"] > NOISE_RED else YELLOW, "noise", "Nhiễu",
            "Ảnh có nhiều nhiễu hạt, dễ làm model đọc nhầm ký tự và dấu.",
            "Có thể khử nhiễu trước khi nhận diện.")
    if x["unevenness"] > preprocess.FLATTEN_UNEVEN:
        lv = RED if x["unevenness"] > UNEVEN_RED else YELLOW
        if x["shadow"]:
            add(lv, "shadow", "Có bóng", "Ảnh có vùng bóng đổ, chữ trong vùng tối có thể bị đọc sai.",
                "Có thể cân bằng ánh sáng để làm mờ bóng; tốt nhất là chụp lại tránh che sáng.")
        else:
            add(lv, "uneven", "Nền không đều", "Độ sáng nền không đồng đều (một phía sáng, một phía tối).",
                "Có thể cân bằng ánh sáng trước khi nhận diện.")
    skew = x["skew"]
    if skew is not None and abs(skew) >= SKEW_WARN:
        add(RED if abs(skew) > SKEW_BAD else YELLOW, "skew", "Độ nghiêng",
            f"Dòng chữ bị nghiêng khoảng {abs(skew):.0f}°.",
            "Có thể tự chỉnh thẳng ảnh trước khi nhận diện." if abs(skew) <= SKEW_BAD else "Nên xoay/chụp lại cho thẳng.")
    if check_resolution:
        lv = _grade(min(w, h), 400, 700)
        if lv != GREEN:
            add(lv, "low_res", "Độ phân giải", f"Ảnh nhỏ ({w}×{h}px). Ảnh độ phân giải cao hơn sẽ cho kết quả tốt hơn.",
                "Có thể phóng to ảnh trước khi nhận diện; ảnh gốc độ phân giải cao hơn vẫn cho kết quả tốt hơn.")

    return _finish(issues, {
        "sharpness": round(sharp, 1), "brightness": round(mean, 1), "contrast": round(rng, 1), "width": w, "height": h,
        "noise": round(x["noise"], 1), "unevenness": round(x["unevenness"], 2),
        "skew": None if skew is None else round(skew, 1),
    })
