"""
Tiền xử lý ảnh trước khi nhận diện chữ (không cần model, chạy bằng OpenCV).

Pipeline (mỗi bước chỉ chạy khi đo thấy ảnh thật sự cần, để không làm hỏng ảnh vốn đã tốt):
  1. Chuẩn hóa: xoay theo EXIF, ghép nền trắng cho ảnh PNG trong suốt, xoay thủ công theo yêu cầu.
  2. Tìm tờ giấy trong ảnh chụp, cắt bỏ nền xung quanh và nắn lại phối cảnh (có kiểm tra an toàn).
  3. Đưa kích thước về mức phù hợp (thu nhỏ bằng INTER_AREA, phóng to bằng INTER_CUBIC).
  4. Cân bằng ánh sáng: loại bỏ bóng đổ / sáng không đều.
  5. Khử nhiễu (chỉ khi ước lượng nhiễu cao).
  6. Tăng tương phản cục bộ (CLAHE) khi ảnh nhạt / xám.
  7. Làm nét (unsharp mask) khi ảnh hơi mờ.
  8. Chế độ "strong": nhị phân hóa thích nghi thành bản scan đen trắng.

Ngoài ra có các hàm hình học dùng cho tự xoay đúng chiều và chỉnh nghiêng (xem ocr_engine).
"""

import math

import cv2
import numpy as np
from PIL import Image, ImageOps

import quality

MAX_SIDE = 2400         # ảnh lớn hơn sẽ bị thu nhỏ (OCR nhanh hơn, vẫn đủ nét cho chữ in cỡ nhỏ)
UPSCALE_BELOW = 800      # cạnh ngắn nhỏ hơn mức này -> phóng to
UPSCALE_MAX_SIDE = 2400  # sau khi phóng to không vượt quá mức này
MAX_PIXELS = 60_000_000  # chặn ảnh quá lớn (tránh tốn RAM)

ENHANCE_MODES = ("auto", "off", "strong")

# Ngưỡng quyết định bước nào của chế độ "auto" được chạy. input_advisor.py dùng CÙNG các hằng số này
# để dự báo/giải thích đúng những gì hệ thống sẽ làm.
DENOISE_SIGMA = 6.0       # ước lượng nhiễu > mức này -> khử nhiễu
FLATTEN_UNEVEN = 0.18     # độ chênh sáng nền > mức này -> cân bằng ánh sáng
CLAHE_RANGE = 110         # biên độ sáng-tối < mức này -> tăng tương phản cục bộ
SHARPEN_BELOW = 90        # độ nét < mức này -> làm nét
SHARPEN_MAX_SIGMA = 12    # ảnh quá nhiễu thì không làm nét (sẽ khuếch đại nhiễu)


# ------------------------------------------------------------------ Chuyển đổi cơ bản
def to_rgb(image):
    """Chuyển sang RGB; ảnh có kênh alpha được ghép lên nền TRẮNG (convert thẳng sẽ ra nền đen)."""
    if image.mode in ("RGBA", "LA") or (image.mode == "P" and "transparency" in image.info):
        rgba = image.convert("RGBA")
        bg = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        return Image.alpha_composite(bg, rgba).convert("RGB")
    return image.convert("RGB")


def rotate_cw(image, degrees):
    """Xoay ảnh PIL theo chiều kim đồng hồ (bội số của 90 độ)."""
    degrees %= 360
    if degrees == 0:
        return image
    op = {90: Image.ROTATE_270, 180: Image.ROTATE_180, 270: Image.ROTATE_90}[degrees]
    return image.transpose(op)


def rotate_np_cw(arr, degrees):
    degrees %= 360
    if degrees == 0:
        return arr
    code = {90: cv2.ROTATE_90_CLOCKWISE, 180: cv2.ROTATE_180, 270: cv2.ROTATE_90_COUNTERCLOCKWISE}[degrees]
    return cv2.rotate(arr, code)


def rotate_free(arr, angle):
    """Xoay ảnh numpy một góc bất kỳ (độ, dương = ngược chiều kim đồng hồ), mở rộng khung để không mất chữ."""
    h, w = arr.shape[:2]
    m = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    cos, sin = abs(m[0, 0]), abs(m[0, 1])
    nw, nh = int(h * sin + w * cos), int(h * cos + w * sin)
    m[0, 2] += nw / 2 - w / 2
    m[1, 2] += nh / 2 - h / 2
    return cv2.warpAffine(arr, m, (nw, nh), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


# ------------------------------------------------------------------ Hình học của hộp chữ
def order_points(pts):
    """Sắp 4 điểm theo thứ tự: trên-trái, trên-phải, dưới-phải, dưới-trái."""
    pts = np.asarray(pts, dtype=np.float32).reshape(-1, 2)
    if len(pts) != 4:
        x0, y0 = pts.min(axis=0)
        x1, y1 = pts.max(axis=0)
        return np.array([[x0, y0], [x1, y0], [x1, y1], [x0, y1]], dtype=np.float32)
    s = pts.sum(axis=1)
    d = np.diff(pts, axis=1).ravel()  # y - x
    return np.array([pts[np.argmin(s)], pts[np.argmin(d)], pts[np.argmax(s)], pts[np.argmax(d)]], dtype=np.float32)


def box_size(box):
    """(chiều rộng, chiều cao) của hộp đã sắp thứ tự."""
    w = max(np.linalg.norm(box[0] - box[1]), np.linalg.norm(box[3] - box[2]))
    h = max(np.linalg.norm(box[0] - box[3]), np.linalg.norm(box[1] - box[2]))
    return float(w), float(h)


def estimate_skew(boxes, min_boxes=3):
    """
    Ước lượng độ nghiêng của dòng chữ (độ) từ các hộp chữ nằm ngang.
    Trả về góc cần xoay NGƯỢC chiều kim đồng hồ để dòng chữ thẳng lại; None nếu không đủ dữ liệu.
    Dùng trung vị có trọng số theo chiều dài dòng nên chịu được vài hộp sai.
    """
    angles, weights = [], []
    for b in boxes:
        w, h = box_size(b)
        if w < 3 * h or w < 40:
            continue
        v = b[1] - b[0]
        a = math.degrees(math.atan2(v[1], v[0]))
        if abs(a) < 45:
            angles.append(a)
            weights.append(w)
    if len(angles) < min_boxes:
        return None
    order = np.argsort(angles)
    a = np.array(angles)[order]
    wt = np.array(weights)[order]
    cum = np.cumsum(wt)
    return float(a[np.searchsorted(cum, cum[-1] / 2)])


# ------------------------------------------------------------------ Tìm và nắn tờ giấy
def _quad_ok(quad, w, h):
    area = cv2.contourArea(quad.astype(np.float32))
    ratio = area / float(w * h)
    if not 0.30 <= ratio <= 0.97:
        return False
    q = order_points(quad)
    for i in range(4):  # mỗi góc phải gần vuông (60°–120°)
        a, b = q[i - 1] - q[i], q[(i + 1) % 4] - q[i]
        cosang = np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-6)
        if not -0.5 <= cosang <= 0.5:
            return False
    tw, th = box_size(q)
    return min(tw, th) > 0.2 * min(w, h)


def find_document(arr):
    """
    Tìm tờ giấy (tứ giác lớn, sáng hơn nền) trong ảnh chụp. Trả về 4 điểm (tọa độ ảnh gốc) hoặc None.
    Có 2 lớp kiểm tra an toàn để KHÔNG cắt nhầm vào chữ:
      - tờ giấy phải sáng hơn vùng xung quanh;
      - mật độ nét mực bên ngoài tứ giác phải thấp hơn rõ rệt so với bên trong.
    """
    h, w = arr.shape[:2]
    k = 800.0 / max(h, w) if max(h, w) > 800 else 1.0
    small = cv2.resize(arr, (max(1, int(w * k)), max(1, int(h * k))), interpolation=cv2.INTER_AREA)
    sh, sw = small.shape[:2]
    gray = cv2.GaussianBlur(cv2.cvtColor(small, cv2.COLOR_RGB2GRAY), (5, 5), 0)

    masks = []
    _, otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    masks.append(cv2.morphologyEx(otsu, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25))))
    edges = cv2.Canny(gray, 40, 120)
    masks.append(cv2.morphologyEx(edges, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))))

    best, best_area = None, 0.0
    for m in masks:
        cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for c in sorted(cnts, key=cv2.contourArea, reverse=True)[:3]:
            hull = cv2.convexHull(c)
            peri = cv2.arcLength(hull, True)
            approx = cv2.approxPolyDP(hull, 0.02 * peri, True)
            if len(approx) != 4:
                continue
            quad = approx.reshape(4, 2).astype(np.float32)
            if not _quad_ok(quad, sw, sh):
                continue
            area = cv2.contourArea(quad)
            if area > best_area:
                best, best_area = quad, area
    if best is None:
        return None

    # --- kiểm tra an toàn
    inside = np.zeros((sh, sw), np.uint8)
    cv2.fillConvexPoly(inside, best.astype(np.int32), 255)
    inner = cv2.erode(inside, np.ones((9, 9), np.uint8))
    outer = cv2.bitwise_not(cv2.dilate(inside, np.ones((9, 9), np.uint8)))
    if cv2.countNonZero(inner) == 0 or cv2.countNonZero(outer) < 0.03 * sw * sh:
        return None
    g = cv2.cvtColor(small, cv2.COLOR_RGB2GRAY)
    if g[inner > 0].mean() < g[outer > 0].mean() + 8:  # giấy phải sáng hơn nền xung quanh
        return None
    ink = cv2.adaptiveThreshold(g, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 31, 15)
    dens_in = np.count_nonzero(ink[inner > 0]) / float(cv2.countNonZero(inner))
    dens_out = np.count_nonzero(ink[outer > 0]) / float(cv2.countNonZero(outer))
    if dens_out > max(0.01, 0.6 * dens_in):
        return None  # bên ngoài cũng có nhiều nét -> có thể là chữ, không cắt
    return order_points(best / k)


def warp_document(arr, quad):
    tl, tr, br, bl = quad
    w = int(max(np.linalg.norm(br - bl), np.linalg.norm(tr - tl)))
    h = int(max(np.linalg.norm(tr - br), np.linalg.norm(tl - bl)))
    if w < 50 or h < 50:
        return arr
    dst = np.array([[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]], dtype=np.float32)
    m = cv2.getPerspectiveTransform(quad.astype(np.float32), dst)
    return cv2.warpPerspective(arr, m, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


# ------------------------------------------------------------------ Các bước cải thiện ảnh (làm việc trên kênh L)
def _estimate_background(gray):
    """Ước lượng nền (giấy) bằng phép đóng hình thái trên ảnh thu nhỏ rồi làm mịn."""
    h, w = gray.shape
    k = 600.0 / max(h, w) if max(h, w) > 600 else 1.0
    small = cv2.resize(gray, (max(1, int(w * k)), max(1, int(h * k))), interpolation=cv2.INTER_AREA) if k < 1 else gray
    ks = max(15, (max(small.shape) // 25) | 1)
    bg = cv2.morphologyEx(small, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ks, ks)))
    bg = cv2.GaussianBlur(bg, (ks | 1, ks | 1), 0)
    return cv2.resize(bg, (w, h), interpolation=cv2.INTER_LINEAR) if k < 1 else bg


def illumination_unevenness(gray):
    """Độ chênh sáng của nền (0 = đều). Chỉ tính cho ảnh nền sáng, chữ tối."""
    bg = _estimate_background(gray).astype(np.float32)
    lo, hi = np.percentile(bg, 5), np.percentile(bg, 95)
    return float((hi - lo) / max(1.0, bg.mean()))


def flatten_illumination(lum):
    bg = _estimate_background(lum).astype(np.float32)
    out = lum.astype(np.float32) / np.maximum(bg, 1.0) * 255.0
    return np.clip(out, 0, 255).astype(np.uint8)


def estimate_noise(gray):
    """Ước lượng độ lệch chuẩn nhiễu (phương pháp Immerkaer), chỉ đo ở vùng phẳng để nét chữ không bị tính là nhiễu."""
    g = gray.astype(np.float32)
    mask_k = np.array([[1, -2, 1], [-2, 4, -2], [1, -2, 1]], dtype=np.float32)
    resp = np.abs(cv2.filter2D(g, -1, mask_k))
    grad = cv2.magnitude(cv2.Sobel(g, cv2.CV_32F, 1, 0), cv2.Sobel(g, cv2.CV_32F, 0, 1))
    flat = grad < np.percentile(grad, 60)
    if not flat.any():
        return 0.0
    return float(math.sqrt(math.pi / 2) / 6.0 * resp[flat].mean())


def denoise_lum(lum, sigma):
    h = float(np.clip(sigma * 0.7, 3, 10))
    if lum.size > 2_500_000:  # ảnh lớn: dùng lọc song phương cho nhanh
        return cv2.bilateralFilter(lum, 7, 35, 35)
    return cv2.fastNlMeansDenoising(lum, None, h, 7, 21)


def unsharp(lum, amount):
    blur = cv2.GaussianBlur(lum, (0, 0), 1.2)
    return cv2.addWeighted(lum, 1 + amount, blur, -amount, 0)


def binarize(lum):
    """Nhị phân hóa thích nghi -> bản scan đen trắng, làm mịn nhẹ để nét chữ không bị răng cưa."""
    block = max(31, (min(lum.shape) // 25) | 1)
    bw = cv2.adaptiveThreshold(lum, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, block, 14)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(255 - bw, connectivity=8)
    speck = np.isin(labels, np.where(stats[:, cv2.CC_STAT_AREA] <= 2)[0]) & (labels > 0)  # chỉ xóa chấm 1–2 px, giữ dấu tiếng Việt
    bw[speck] = 255
    return cv2.GaussianBlur(bw, (0, 0), 0.6)


# ------------------------------------------------------------------ Điểm vào
def prepare(image, check_resolution=True, rotation=0, enhance="auto", is_photo=None):
    """
    Chuẩn hóa và tối ưu ảnh. Trả về (ảnh PIL RGB, đánh giá chất lượng, ghi chú).
      rotation: xoay thủ công theo chiều kim đồng hồ (0/90/180/270).
      enhance:  'auto' (chỉ xử lý khi cần) | 'off' (chỉ chuẩn hóa) | 'strong' (thêm nhị phân hóa kiểu scan).
      is_photo: ảnh chụp/ảnh tải lên (True) hay trang PDF đã render sạch (False). Mặc định = check_resolution.
    """
    if is_photo is None:
        is_photo = check_resolution
    if enhance not in ENHANCE_MODES:
        enhance = "auto"
    notes = []

    image = to_rgb(ImageOps.exif_transpose(image))
    rotation = int(rotation or 0) % 360
    if rotation:
        image = rotate_cw(image, rotation)
        notes.append(f"Đã xoay ảnh {rotation}° theo yêu cầu.")
    q = quality.assess(image, check_resolution)

    arr = np.array(image)
    if enhance != "off" and is_photo:
        quad = find_document(arr)
        if quad is not None:
            arr = warp_document(arr, quad)
            notes.append("Đã cắt bỏ nền và nắn thẳng tờ giấy.")

    h, w = arr.shape[:2]
    if check_resolution and min(h, w) < UPSCALE_BELOW:
        scale = min(2.0, UPSCALE_MAX_SIDE / max(h, w))
        if scale >= 1.25:
            arr = cv2.resize(arr, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_CUBIC)
            notes.append("Đã phóng to ảnh nhỏ để nhận diện rõ hơn.")
    elif max(h, w) > MAX_SIDE:
        k = MAX_SIDE / max(h, w)
        arr = cv2.resize(arr, (max(1, int(w * k)), max(1, int(h * k))), interpolation=cv2.INTER_AREA)

    if enhance != "off":
        arr = _enhance(arr, notes, force_all=(enhance == "strong"))
    return Image.fromarray(arr), q, notes


def _enhance(arr, notes, force_all):
    lab = cv2.cvtColor(arr, cv2.COLOR_RGB2LAB)
    lum = lab[:, :, 0]
    m = quality.measure(lum)
    changed = False
    dark_bg = float(np.median(lum)) < 110  # nền tối (chữ sáng): bỏ qua các bước giả định chữ tối trên nền sáng

    # Khử nhiễu TRƯỚC khi cân sáng: phép chia ở vùng bóng tối sẽ khuếch đại nhiễu nếu để sau
    sigma = estimate_noise(lum)
    if sigma > DENOISE_SIGMA or (force_all and sigma > 2.5):
        lum = denoise_lum(lum, max(sigma, DENOISE_SIGMA))
        notes.append("Đã khử nhiễu.")
        changed = True

    if not dark_bg and (force_all or illumination_unevenness(lum) > FLATTEN_UNEVEN):
        lum = flatten_illumination(lum)
        notes.append("Đã cân bằng ánh sáng, loại bỏ bóng đổ.")
        changed = True
        if estimate_noise(lum) > 6.0:  # vùng tối bị khuếch đại nhiễu -> lọc lại nhẹ
            lum = cv2.bilateralFilter(lum, 7, 30, 30)

    lo, hi = np.percentile(lum, (0.3, 99.7))  # biên độ sáng-tối: không bị đánh lừa bởi trang ít chữ
    if force_all or hi - lo < CLAHE_RANGE:
        lum = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(lum)
        notes.append("Đã tăng độ tương phản cục bộ.")
        changed = True

    if m["sharpness"] < SHARPEN_BELOW and sigma <= SHARPEN_MAX_SIGMA:
        lum = unsharp(lum, 0.9 if m["sharpness"] < 35 else 0.6)
        notes.append("Đã làm nét ảnh hơi mờ.")
        changed = True

    if force_all and not dark_bg:
        bw = binarize(lum)
        notes.append("Đã chuyển thành bản scan đen trắng.")
        return cv2.cvtColor(bw, cv2.COLOR_GRAY2RGB)

    if not changed:
        return arr
    lab[:, :, 0] = lum
    return cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)
