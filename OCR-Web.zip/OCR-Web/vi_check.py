"""
Kiểm tra cấu trúc âm tiết tiếng Việt (chạy offline, rất nhanh).

Dùng để phát hiện từ "không thể là tiếng Việt" trong kết quả OCR (sai dấu, nhầm ký tự, dính chữ...).
Đây là kiểm tra quy tắc chính tả/ngữ âm, KHÔNG phải từ điển: từ đúng cấu trúc nhưng sai nghĩa
(ví dụ "chao" thay vì "chào") sẽ không bị phát hiện.
"""

import re
import unicodedata

_TONES = {"\u0300", "\u0301", "\u0303", "\u0309", "\u0323"}  # huyền, sắc, ngã, hỏi, nặng
_ACUTE, _DOT = "\u0301", "\u0323"

_INITIALS = ["ngh", "ng", "nh", "ch", "gh", "gi", "kh", "ph", "qu", "th", "tr",
             "b", "c", "d", "đ", "g", "h", "k", "l", "m", "n", "p", "r", "s", "t", "v", "x"]

# Nguyên âm có thể đứng cuối âm tiết (không có phụ âm cuối)
_OPEN = set("a e ê i o ô ơ u ư y ai ay ao au âu ây eo êu ia iu oi ôi ơi ua ui ưa ưi ưu "
            "iê yê uô ươ oa oe uê uy uơ iêu yêu oai oay oao oeo uai uay uây uôi ươi ươu uya uyu".split())
# Nguyên âm có thể đi với phụ âm cuối
_CLOSED = set("a ă â e ê i o ô ơ u ư y iê yê uô ươ oa oă oe uâ uê uy uyê uơ oo".split())
_NEED_FINAL = {"ă", "â", "oă", "uâ"}
_FINALS = ["ch", "ng", "nh", "c", "m", "n", "p", "t"]

_LETTERS = set("aăâbcdđeêghiklmnoôơpqrstuưvxy")
_ABBREV_OK = {"kg", "km", "cm", "mm", "tp", "ths", "ts", "gs", "pgs", "tt", "tw", "ubnd", "hđnd", "qđ", "nđ", "cp"}
_STRIP = " \t.,;:!?()[]{}\"'“”‘’…–—/\\*•·<>«»|_=+#%&~^`"


def _split_tone(word):
    """Tách dấu thanh. Trả về (chữ không dấu thanh, dấu thanh hoặc None). None nếu có >1 dấu thanh."""
    nfd = unicodedata.normalize("NFD", word)
    tones = [c for c in nfd if c in _TONES]
    if len(tones) > 1:
        return None, None
    base = unicodedata.normalize("NFC", "".join(c for c in nfd if c not in _TONES))
    return base, (tones[0] if tones else None)


def _rime_ok(rime, tone):
    if not rime:
        return False
    for fin in [""] + _FINALS:
        if fin and not rime.endswith(fin):
            continue
        nuc = rime[: len(rime) - len(fin)] if fin else rime
        if not nuc:
            continue
        if not fin:
            if nuc in _OPEN and nuc not in _NEED_FINAL:
                return True
            continue
        if nuc not in _CLOSED:
            continue
        if fin in ("ch", "nh") and nuc[-1] not in "aêiy":
            continue
        if fin in ("c", "ch", "p", "t") and tone not in (_ACUTE, _DOT):
            continue  # âm tiết kết thúc bằng c/ch/p/t chỉ có dấu sắc hoặc nặng
        return True
    return False


def _first_vowel(rime):
    return rime[0] if rime else ""


def valid_syllable(word):
    """True/False nếu là âm tiết tiếng Việt hợp lệ; None nếu không đủ cơ sở để kiểm tra."""
    w = word.lower()
    if len(w) < 2:
        return None
    base, tone = _split_tone(w)
    if base is None:
        return False
    if any(ch not in _LETTERS for ch in base):
        return None  # có f, j, w, z, chữ số, chữ ngoại ngữ... -> bỏ qua
    if base in _ABBREV_OK:
        return None
    if not any(ch in "aăâeêioôơuưy" for ch in base):
        return None if len(base) <= 4 else False

    for ini in [""] + [i for i in _INITIALS if base.startswith(i)]:
        rime = base[len(ini):]
        if not _rime_ok(rime, tone):
            continue
        v = _first_vowel(rime)
        if ini in ("k",) and v not in "ieêy":
            continue
        if ini == "c" and v in "ieêy":
            continue
        if ini in ("gh", "ngh") and v not in "ieê":
            continue
        if ini == "ng" and v in "ieê":
            continue
        if ini == "g" and v in "eê":
            continue
        if ini == "qu" and v in "uo":
            continue
        return True
    return False


def check_line(text):
    """Trả về (danh sách từ nghi sai, số từ đã kiểm tra)."""
    bad, checked = [], 0
    for raw in text.split():
        tok = raw.strip(_STRIP)
        if not tok or any(c.isdigit() for c in tok) or "@" in tok or "." in tok:
            continue
        for part in re.split(r"[-]", tok):
            if len(part) < 2 or not part.isalpha():
                continue
            ok = valid_syllable(part)
            if ok is None or (ok is False and part.isupper()):
                continue  # chữ HOA không hợp lệ thường là từ viết tắt -> không báo
            checked += 1
            if ok is False:
                bad.append(part)
    return bad, checked
