"""
Lớp hỗ trợ ĐẦU VÀO (chạy hoàn toàn cục bộ, KHÔNG gửi ảnh/tài liệu đi đâu):

    Ảnh/PDF -> kiểm tra chất lượng (quality.py) -> đánh giá vấn đề -> đề xuất xử lý -> preprocessing (preprocess.py) -> OCR

Module này KHÔNG xử lý ảnh. Nó chỉ chuyển kết quả đo của quality.assess thành:
  - cảnh báo xanh/vàng/đỏ + câu giải thích dễ hiểu;
  - đề xuất ("có thể tăng tương phản trước khi nhận diện...");
  - dự báo các bước preprocessing mà chế độ "auto" SẼ chạy (dùng đúng các hằng số ngưỡng của preprocess.py,
    nên dự báo luôn khớp việc hệ thống thật sự làm; những gì đã làm xong nằm trong "notes" của kết quả OCR).
Việc phát hiện "chữ quá nhỏ" / "không thấy vùng chữ" cần kết quả dò chữ nên do ocr_engine bổ sung qua quality.add_issue.

Vì ưu tiên an toàn dữ liệu, AI ngoài (Gemini/Claude) KHÔNG được dùng cho ảnh đầu vào; AI chỉ xem văn bản sau OCR (ai_review.py).
"""

import preprocess
import quality

# Cụm từ ngắn mô tả từng vấn đề, ghép thành câu tóm tắt
PHRASE = {
    "blur": "độ nét thấp (ảnh mờ)", "dark": "độ sáng quá thấp", "bright": "độ sáng quá cao",
    "contrast": "độ tương phản thấp", "noise": "nhiều nhiễu", "uneven": "nền không đều", "shadow": "bóng đổ",
    "skew": "dòng chữ bị nghiêng", "low_res": "độ phân giải thấp", "small_text": "chữ rất nhỏ",
}
TITLE = {quality.GREEN: "Chất lượng ảnh tốt", quality.YELLOW: "Chất lượng ảnh trung bình", quality.RED: "Chất lượng ảnh kém"}

# Vấn đề nào preprocessing có thể cải thiện: True = xử lý được, "partial" = chỉ giảm bớt, False = chỉ chụp lại mới khắc phục
AUTO_FIX = {"blur": "partial", "dark": "partial", "bright": False, "contrast": True, "noise": True, "uneven": True,
            "shadow": True, "skew": True, "low_res": "partial", "small_text": False, "no_text": False}


def _plan(q, enhance, auto_orient, check_resolution):
    """Các bước tiền xử lý dự kiến (đúng điều kiện trong preprocess.prepare/_enhance)."""
    m = q["metrics"]
    if enhance == "off":
        return [], "Đang tắt xử lý ảnh: ảnh được giữ nguyên trước khi nhận diện."
    force = enhance == "strong"
    steps = []
    if check_resolution and min(m.get("width", 9999), m.get("height", 9999)) < preprocess.UPSCALE_BELOW:
        steps.append(("upscale", "Phóng to ảnh nhỏ"))
    noise = m.get("noise") or 0
    if noise > preprocess.DENOISE_SIGMA or (force and noise > 2.5):
        steps.append(("denoise", "Khử nhiễu"))
    if force or (m.get("unevenness") or 0) > preprocess.FLATTEN_UNEVEN:
        steps.append(("illumination", "Cân bằng ánh sáng, giảm bóng đổ"))
    if force or m.get("contrast", 255) < preprocess.CLAHE_RANGE:
        steps.append(("clahe", "Tăng độ tương phản cục bộ"))
    if m.get("sharpness", 999) < preprocess.SHARPEN_BELOW and noise <= preprocess.SHARPEN_MAX_SIGMA:
        steps.append(("sharpen", "Làm nét"))
    skew = m.get("skew")
    if auto_orient:
        if skew is not None and quality.SKEW_WARN <= abs(skew) <= quality.SKEW_BAD:
            steps.append(("deskew", f"Chỉnh thẳng ảnh nghiêng (~{abs(skew):.0f}°)"))
    if force:
        steps.append(("binarize", "Chuyển thành bản scan đen trắng"))
    note = "" if steps else "Ảnh đủ tốt: không cần xử lý thêm trước khi nhận diện."
    return [{"code": c, "text": t} for c, t in steps], note


def build(q, enhance="auto", auto_orient=True, check_resolution=True):
    """q: dict từ quality.assess (đã có thể kèm vấn đề do engine bổ sung). Trả về dict cho giao diện; None nếu q là None."""
    if not q:
        return None
    issues = []
    for i in q["issues"]:
        code = i.get("code", "")
        issues.append({
            "level": i["level"], "label": i["label"], "message": i["message"], "code": code,
            "suggestion": i.get("suggestion", ""), "auto_fix": AUTO_FIX.get(code, False),
        })
    level = q["level"]
    plan, plan_note = _plan(q, enhance, auto_orient, check_resolution)

    if level == quality.GREEN:
        summary = "Ảnh có chất lượng tốt, phù hợp để nhận diện."
    elif any(i["code"] == "no_text" for i in issues):
        summary = "Không phát hiện được vùng văn bản trong ảnh."
    else:
        phrases = [PHRASE[i["code"]] for i in issues if i["code"] in PHRASE]
        tail = ("kết quả OCR có thể bị ảnh hưởng." if level == quality.YELLOW
                else "có nguy cơ cao OCR không chính xác.")
        summary = f"Ảnh có {', '.join(phrases)}, {tail}" if phrases else f"Ảnh cần chú ý, {tail}"

    suggestions, seen = [], set()
    for i in sorted(issues, key=lambda x: -quality._RANK[x["level"]]):
        if i["suggestion"] and i["suggestion"] not in seen:
            seen.add(i["suggestion"])
            suggestions.append(i["suggestion"])

    codes = {i["code"] for i in issues}
    return {
        "level": level,
        "score": q["score"],
        "title": TITLE[level],
        "summary": summary,
        "risk": level != quality.GREEN,
        "issues": issues,
        "suggestions": suggestions,
        "plan": plan,
        "plan_note": plan_note,
        # Gợi ý (KHÔNG tự đổi chế độ): chữ nhạt/nền không đều là trường hợp chế độ mạnh hay giúp ích
        "recommend_strong": bool(codes & {"contrast", "uneven", "shadow"}) and enhance == "auto",
        "recapture": any(i["level"] == quality.RED and not i["auto_fix"] for i in issues),
    }


def text_size_issue(q, median_height_px):
    """Bổ sung cảnh báo "văn bản quá nhỏ" khi đã dò chữ (chiều cao dòng chữ trung vị, tính theo pixel ảnh đã xử lý)."""
    if median_height_px is None or median_height_px >= 16:
        return q
    lv = quality.RED if median_height_px < 10 else quality.YELLOW
    return quality.add_issue(
        q, lv, "small_text", "Văn bản nhỏ", f"Chữ rất nhỏ (cao khoảng {median_height_px:.0f}px), dễ bị đọc sai dấu.",
        "Hãy chụp gần hơn hoặc dùng ảnh/PDF độ phân giải cao hơn.")


def no_text_issue(q):
    """Bổ sung cảnh báo khi không dò được vùng chữ nào."""
    return quality.add_issue(
        q, quality.RED, "no_text", "Vùng văn bản", "Không phát hiện được vùng chữ trong ảnh.",
        "Kiểm tra ảnh có chứa chữ in rõ ràng không, thử xoay ảnh hoặc chọn chế độ 'Tăng cường mạnh'.")
