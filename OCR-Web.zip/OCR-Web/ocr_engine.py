"""
OCR engine: PaddleOCR (phát hiện vùng chữ) + VietOCR (đọc chữ).

Chỉ hỗ trợ OCR văn bản in/đánh máy thông thường. Quy trình:
  1. Tiền xử lý ảnh (preprocess.py): cắt tờ giấy, cân sáng, khử nhiễu, tăng tương phản, làm nét...
  2. Phát hiện dòng chữ.
  3. Tự xoay đúng chiều (0/90/180/270) bằng cách cho VietOCR đọc thử các hướng và so điểm tin cậy.
  4. Chỉnh nghiêng nhỏ dựa trên góc của các dòng chữ.
  5. Gom các hộp chữ thành dòng theo thứ tự đọc.
  6. Cắt từng dòng, chuẩn hóa (đảo màu nếu chữ sáng nền tối, kéo giãn tương phản), chia dòng quá dài
     (VietOCR chỉ nhận tối đa ~512px chiều ngang) rồi đọc theo lô; dòng kém chắc chắn được đọc lại.
"""

import base64
import math
import os
import re
import threading
import time
from collections import defaultdict

import cv2
import numpy as np
from PIL import Image
import yaml

import input_advisor
import preprocess
import reflow as reflow_mod
import symbols
import vi_check

# paddleocr / vietocr / torch rất nặng: chỉ nạp khi thật sự cần (trong load_models) để
# ứng dụng khởi động nhanh, báo lỗi thiếu thư viện rõ ràng và các phần còn lại test được độc lập.

_models = None
_models_lock = threading.Lock()


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CFG_DIR = os.path.join(BASE_DIR, "models", "config")


def _load_cfg():
    """Đọc config VietOCR từ file local (models/config) thay vì tải từ vocr.vn."""
    from vietocr.tool.config import Cfg

    def read(name):
        with open(os.path.join(CFG_DIR, name), encoding="utf-8") as f:
            return yaml.safe_load(f)
    cfg = read("base.yml")
    cfg.update(read("vgg-transformer.yml"))
    return Cfg(cfg)


class NoTextFound(Exception):
    """Không phát hiện được vùng chữ nào trong ảnh."""


def _pick_device():
    """OCR_DEVICE=cpu|cuda|cuda:0 để ép thiết bị; mặc định tự dùng GPU NVIDIA nếu có, không thì CPU."""
    forced = os.environ.get("OCR_DEVICE", "").strip().lower()
    if forced:
        return forced
    try:
        import torch
        return "cuda:0" if torch.cuda.is_available() else "cpu"
    except Exception:
        return "cpu"


def models_loaded():
    return _models is not None


# ----- Load model 1 lần duy nhất -----
def load_models():
    global _models
    with _models_lock:
        if _models is None:
            try:
                from paddleocr import TextDetection
                from vietocr.tool.predictor import Predictor
            except ImportError as e:
                raise RuntimeError(f"Thiếu thư viện ({e.name}). Hãy chạy: pip install -r requirements.txt") from e

            det_model = TextDetection(model_name="PP-OCRv5_server_det", engine="onnxruntime")

            config = _load_cfg()
            local_w = os.path.join(BASE_DIR, "models", "vgg_transformer.pth")
            if os.path.isfile(local_w):
                config['weights'] = local_w
            print("Model văn bản in:", config['weights'])
            config['cnn']['pretrained'] = False
            config['device'] = _pick_device()
            print("Thiết bị chạy VietOCR:", config['device'])
            config['predictor']['beamsearch'] = False  # greedy: nhanh hơn và cho điểm tin cậy
            try:
                vietocr_detector = Predictor(config)
            except Exception:
                if config['device'] == 'cpu':
                    raise
                print("Không dùng được GPU, chuyển sang CPU.")
                config['device'] = 'cpu'
                vietocr_detector = Predictor(config)
            _warm_up(det_model, vietocr_detector)

            _models = (det_model, vietocr_detector)
    return _models


# ----------------------------------------------------------------- Phát hiện & cắt vùng chữ
def crop_by_polygon(img_np, box, padding=6):
    box = np.array(box, dtype=np.float32)
    center = box.mean(axis=0)
    directions = box - center
    norms = np.linalg.norm(directions, axis=1, keepdims=True)
    norms[norms == 0] = 1
    box = box + (directions / norms) * padding

    width = max(2, int(max(np.linalg.norm(box[0] - box[1]), np.linalg.norm(box[2] - box[3]))))
    height = max(2, int(max(np.linalg.norm(box[0] - box[3]), np.linalg.norm(box[1] - box[2]))))
    dst_rect = np.array([[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]], dtype=np.float32)
    matrix = cv2.getPerspectiveTransform(box, dst_rect)
    return cv2.warpPerspective(img_np, matrix, (width, height), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


def _detect(img_np, det_model):
    """Trả về danh sách hộp (4 điểm đã sắp trên-trái, trên-phải, dưới-phải, dưới-trái), bỏ hộp quá nhỏ."""
    boxes = []
    for res in det_model.predict(img_np, batch_size=1):
        polys = res.get('dt_polys', [])
        if polys is None:
            continue
        for p in polys:
            b = preprocess.order_points(p)
            w, h = preprocess.box_size(b)
            if min(w, h) >= 4 and max(w, h) >= 8:
                boxes.append(b)
    return boxes


def group_rows(boxes):
    """
    Gom hộp chữ thành các dòng theo thứ tự đọc (trên xuống, trái sang phải).
    Hai hộp thuộc CÙNG MỘT DÒNG khi tâm của chúng lệch nhau theo chiều dọc ít hơn nửa chiều cao thật của hộp
    (đo theo cạnh của khung chữ, không đo theo khung chữ nhật bao ngoài: dòng chữ hơi nghiêng có khung bao rất cao,
    chồng lấn sang dòng kế bên và làm hai dòng dính thành một).
    Các hộp cùng hàng và sát nhau (khoảng cách < 1,2 chiều cao dòng) được ghép thành MỘT dòng;
    hộp cách xa (cột khác, ô bảng khác) vẫn là dòng riêng. Trả về list các nhóm chỉ số hộp.
    """
    info = []
    for i, b in enumerate(boxes):
        (x0, y0), (x1, y1) = b.min(axis=0), b.max(axis=0)
        h = max(1.0, preprocess.box_size(b)[1])                  # chiều cao thật của dòng chữ
        info.append((i, float(x0), float(y0), float(x1), float(y1), (float(y0) + float(y1)) / 2, h))
    info.sort(key=lambda t: t[5])

    rows = []
    for it in info:
        cy, h = it[5], it[6]
        for row in reversed(rows[-3:]):
            if abs(cy - row["cy"]) < 0.5 * min(h, row["h"]):
                row["items"].append(it)
                n = len(row["items"])
                row["cy"] += (cy - row["cy"]) / n
                row["h"] += (h - row["h"]) / n
                break
        else:
            rows.append({"items": [it], "cy": cy, "h": h})
    rows.sort(key=lambda r: r["cy"])

    groups = []
    for row in rows:
        items = sorted(row["items"], key=lambda t: t[1])
        rh = max(1.0, row["h"])
        cur = [items[0]]
        for it in items[1:]:
            if it[1] - cur[-1][3] < 1.2 * rh:
                cur.append(it)
            else:
                groups.append([c[0] for c in cur])
                cur = [it]
        groups.append([c[0] for c in cur])
    return groups


# ----------------------------------------------------------------- Chuẩn bị ảnh từng dòng
MAX_ASPECT = 15.0      # VietOCR đưa dòng về cao 32px, rộng tối đa 512px -> dòng dài hơn ~16:1 bị nén, đọc sai


def _normalize_crop(crop):
    """Chữ sáng trên nền tối -> đảo thành chữ tối nền sáng; ảnh nhạt -> kéo giãn tương phản."""
    gray = cv2.cvtColor(crop, cv2.COLOR_RGB2GRAY)
    h = gray.shape[0]
    lo, hi = np.percentile(gray, (1, 99))
    if hi - lo < 25:  # gần như trống: không có gì để chuẩn hóa
        return crop
    b = max(1, min(3, h // 8))
    ring = np.concatenate([gray[:b].ravel(), gray[-b:].ravel(), gray[:, :b].ravel(), gray[:, -b:].ravel()])
    thr = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[0]
    if np.median(ring) <= thr:  # viền (nền) không sáng hơn ngưỡng -> chữ sáng nền tối ('<=': ảnh phẳng 2 màu có ngưỡng đúng bằng màu nền)
        crop = 255 - crop
        lo, hi = 255 - hi, 255 - lo
    if hi - lo < 150:
        crop = np.clip((crop.astype(np.float32) - lo) * 255.0 / max(1.0, hi - lo), 0, 255).astype(np.uint8)
    return crop


def _segments(crop):
    """Chia dòng quá dài thành các đoạn <= MAX_ASPECT, cắt tại khoảng trắng giữa các từ."""
    h, w = crop.shape[:2]
    maxw = int(MAX_ASPECT * h)
    if w <= maxw:
        return [crop]
    gray = cv2.cvtColor(crop, cv2.COLOR_RGB2GRAY)
    ink = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    col = np.convolve(ink.sum(axis=0) / 255.0, np.ones(3) / 3, mode="same")
    empty = col <= max(0.5, 0.04 * h)

    min_gap, gaps, i = max(3, int(0.22 * h)), [], 0
    while i < w:
        if empty[i]:
            j = i
            while j < w and empty[j]:
                j += 1
            if j - i >= min_gap and i > 0 and j < w:
                gaps.append((i, j))
            i = j
        else:
            i += 1

    cuts, start = [], 0
    while w - start > maxw:
        hi = min(start + maxw, w - int(3 * h))
        lo = start + int(0.4 * maxw)
        if hi <= lo:
            hi = start + maxw
        cand = [(e - s, (s + e) // 2) for s, e in gaps if lo <= (s + e) // 2 <= hi]
        if cand:
            right = [c for c in cand if c[1] >= start + 0.6 * maxw]
            cut = max(right)[1] if right else max(cand, key=lambda c: c[1])[1]
        else:  # không có khoảng trắng: cắt tại cột ít mực nhất
            cut = lo + int(np.argmin(col[lo:hi + 1]))
        cuts.append(cut)
        start = cut
    edges = [0] + cuts + [w]
    return [crop[:, a:b] for a, b in zip(edges[:-1], edges[1:]) if b - a >= 4]


def _binarized_variant(crop):
    """Bản nhị phân hóa (Otsu) làm mịn nhẹ - dùng làm 'ý kiến thứ hai' cho dòng kém chắc chắn."""
    gray = cv2.cvtColor(crop, cv2.COLOR_RGB2GRAY)
    bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    return cv2.cvtColor(cv2.GaussianBlur(bw, (0, 0), 0.8), cv2.COLOR_GRAY2RGB)


# ----------------------------------------------------------------- Đọc chữ nhanh + điểm tin cậy
LOW_CONF = 0.90        # dưới mức này: đọc lại (bản nhị phân + beam search) để chính xác hơn
RED_CONF = 0.75
MAX_REFINE = 40        # tối đa số đoạn đọc lại / ảnh (giới hạn thời gian)
BATCH = 32


def _set_beam(predictor, on):
    cfg = getattr(predictor, "config", None)
    if isinstance(cfg, dict):
        cfg["predictor"]["beamsearch"] = on
        return True
    return False


def _conf(p):
    try:
        p = float(p)
    except (TypeError, ValueError):
        return None
    return min(1.0, max(0.0, p)) if math.isfinite(p) else None


def _predict_greedy(crops, predictor):
    """Đọc theo lô (nhanh hơn từng dòng). Trả về [(text, conf 0-1 hoặc None)]."""
    _set_beam(predictor, False)
    out = []
    for i in range(0, len(crops), BATCH):
        chunk = crops[i:i + BATCH]
        try:
            texts, probs = predictor.predict_batch(chunk, return_prob=True)
        except Exception:  # bản VietOCR cũ không có predict_batch -> đọc từng dòng
            texts, probs = [], []
            for im in chunk:
                t, p = predictor.predict(im, return_prob=True)
                texts.append(t)
                probs.append(p)
        out.extend((t, _conf(p)) for t, p in zip(texts, probs))
    return out


def _merge_conf(parts):
    """Độ tin cậy trung bình theo số ký tự; None nếu không đoạn nào có điểm."""
    num = den = 0.0
    for text, conf in parts:
        if conf is not None:
            n = max(1, len(text))
            num += conf * n
            den += n
    return num / den if den else None


def recognize_scored(img_np, boxes, predictor):
    """Trả về [(text, conf, refined)] theo thứ tự boxes."""
    units = []  # (chỉ số hộp, ảnh đoạn)
    for bi, b in enumerate(boxes):
        crop = _normalize_crop(crop_by_polygon(img_np, b))
        units.extend((bi, Image.fromarray(seg)) for seg in _segments(crop))

    crops = [c for _, c in units]
    res = [[t, c, False] for t, c in _predict_greedy(crops, predictor)]

    def low_list():
        idx = [i for i, (t, c, _) in enumerate(res) if t.strip() and (c is None or c < LOW_CONF)]
        idx.sort(key=lambda i: -1 if res[i][1] is None else res[i][1])
        return idx[:MAX_REFINE]

    # Lượt 1: đọc lại bằng bản nhị phân hóa, lấy kết quả chắc chắn hơn
    low = low_list()
    if low:
        variants = [Image.fromarray(_binarized_variant(np.array(crops[i]))) for i in low]
        for i, v, (t, c) in zip(low, variants, _predict_greedy(variants, predictor)):
            if t.strip() and c is not None and (res[i][1] is None or c > res[i][1] + 0.02):
                res[i][2] = t != res[i][0]
                res[i][0], res[i][1], crops[i] = t, c, v

    # Lượt 2: beam search cho các đoạn vẫn còn kém chắc chắn
    low = low_list()
    if low and _set_beam(predictor, True):
        try:
            for i in low:
                try:
                    t = predictor.predict(crops[i])
                except Exception:
                    continue
                if t and t.strip():
                    res[i][2] = res[i][2] or t != res[i][0]
                    res[i][0] = t
        finally:
            _set_beam(predictor, False)

    by_box = defaultdict(list)
    for (bi, _), (t, c, r) in zip(units, res):
        if t.strip():
            by_box[bi].append((t.strip(), c, r))
    out = []
    for bi in range(len(boxes)):
        segs = by_box.get(bi, [])
        out.append((" ".join(s[0] for s in segs), _merge_conf([(s[0], s[1]) for s in segs]), any(s[2] for s in segs)))
    return out


_ABBREV = {"vd", "tp", "tr", "tt", "st", "ts", "gs", "pgs", "ths", "ks", "bs", "nxb", "stt", "sdt", "đt", "etc", "vs", "ví"}


def fix_sentence_case(text):
    """VietOCR hay đọc chữ cái đầu câu mới thành chữ thường ("tính. viết các"): viết hoa lại chữ đứng sau dấu chấm/!/? trong cùng dòng."""
    def sub(m):
        word = m.group(1).rstrip(".!?\u2026 \t").lower()
        ch = m.group(3)
        if word in _ABBREV or not ch.islower():
            return m.group(0)
        return m.group(1) + m.group(2) + ch.upper()
    return re.sub(r"(\b[^\W\d_]{2,}[.!?])(\s+)([^\W\d_])", sub, text)


def _warm_up(det_model, predictor):
    """Chạy thử 1 lần khi khởi động để yêu cầu OCR đầu tiên không bị chậm."""
    try:
        predictor.predict_batch([Image.new("RGB", (160, 32), "white")], return_prob=True)
    except Exception:
        try:
            predictor.predict(Image.new("RGB", (160, 32), "white"))
        except Exception:
            pass



# ----------------------------------------------------------------- Nhận lại ký hiệu so sánh < > = <= >=
def _read_crop(crop, predictor):
    """Đọc một ảnh dòng (đã chuẩn hóa): chia đoạn, đọc nhanh, đoạn kém chắc chắn thì thử thêm bản nhị phân. Trả về (text, conf 0-1)."""
    segs = [Image.fromarray(s) for s in _segments(crop)]
    res = [list(r) for r in _predict_greedy(segs, predictor)]
    low = [i for i, (t, c) in enumerate(res) if c is None or c < LOW_CONF]
    if low:
        alt = [Image.fromarray(_binarized_variant(np.array(segs[i]))) for i in low]
        for i, (t, c) in zip(low, _predict_greedy(alt, predictor)):
            if t.strip() and c is not None and (res[i][1] is None or c > res[i][1] + 0.02):
                res[i] = [t, c]
    parts = [(t.strip(), c) for t, c in res if t.strip()]
    return " ".join(t for t, _ in parts), _merge_conf(parts)


def _read_by_pieces(crop, blobs, predictor):
    """Đọc riêng từng đoạn chữ nằm giữa các ký hiệu rồi nối lại. Trả về (text, conf) hoặc (None, None) nếu có đoạn đọc không ra."""
    parts, confs = [], []
    for kind, val in symbols.pieces(crop, blobs):
        if kind == "op":
            parts.append(val)
            continue
        t, c = _read_crop(val, predictor)
        if not t.strip():
            return None, None
        parts.append(t.strip())
        confs.append((t.strip(), c))
    return " ".join(parts), _merge_conf(confs)


def recover_symbols(img_np, boxes, scored, predictor):
    """
    VietOCR hay đọc sai ký hiệu so sánh (vd "(0 < n < 100)" thành "(0 Sn 5 100)").
    Với các dòng có cụm giống < > = <= >= (nhận bằng hình dạng, xem symbols.py): xóa ký hiệu khỏi ảnh dòng, đọc lại phần chữ,
    rồi chèn ký hiệu về đúng chỗ. Lỗi ở bước này không bao giờ làm hỏng kết quả OCR gốc.
    Trả về (scored mới, số ký hiệu đã nhận lại).
    """
    out, total = list(scored), 0
    for bi, box in enumerate(boxes):
        try:
            crop = _normalize_crop(crop_by_polygon(img_np, box))
            if crop.shape[0] < 12 or crop.shape[1] < 3 * crop.shape[0]:
                continue
            blobs, ops = symbols.analyze(crop)
            if not ops:
                continue
            text, conf = _read_crop(symbols.erase(crop, blobs), predictor)
            if not text.strip():
                continue
            if len(text.split()) == symbols.word_count(blobs):
                final = symbols.splice(text, blobs)             # số từ khớp: ghép theo thứ tự từ (chính xác)
            else:
                # Model đọc dính/tách từ (vd "p n" -> "p.n") nên không ghép theo thứ tự được: đọc riêng từng đoạn giữa các ký hiệu
                final, conf2 = _read_by_pieces(crop, blobs, predictor)
                if final is None:
                    final = symbols.splice(text, blobs)
                else:
                    conf = conf2 if conf2 is not None else conf
            if symbols.has_leading_dash(blobs) and not final.lstrip()[:1] in ("-", "–", "—", "•", "·", "*", "~"):
                final = "- " + final.lstrip()                   # model chữ làm rơi gạch đầu dòng
            out[bi] = (final, conf, True)
            total += len(ops)
        except Exception:  # giữ nguyên kết quả đọc gốc của dòng này
            continue
    return out, total


# ----------------------------------------------------------------- Tự xoay đúng chiều & chỉnh nghiêng
ORIENT_SAMPLES = 10    # số dòng dài nhất dùng để "đọc thử" các hướng
FLIP_MARGIN = 0.05     # hướng 180° phải hơn hướng gốc ít nhất mức này mới đổi (ưu tiên giữ nguyên)
SKEW_MIN, SKEW_MAX = 1.0, 20.0


def _orientation_score(crops, predictor):
    """Điểm 0-1 cho một hướng: độ tin cậy của VietOCR, trừ điểm nếu nhiều từ không phải âm tiết tiếng Việt."""
    num = den = 0.0
    for text, conf in _predict_greedy([Image.fromarray(c) for c in crops], predictor):
        text = text.strip()
        if not text:
            continue
        bad, checked = vi_check.check_line(text)
        ratio = len(bad) / checked if checked else 0.5
        n = min(len(text), 25)
        num += (0.5 if conf is None else conf) * (1 - 0.6 * ratio) * n
        den += n
    return num / den if den else 0.0


def _auto_orient(img_np, boxes, det_model, predictor):
    """Trả về (ảnh, hộp, góc đã xoay theo chiều kim đồng hồ: 0/90/180/270)."""
    horiz = vert = 0.0
    for b in boxes:
        w, h = preprocess.box_size(b)
        if w >= 1.5 * h:
            horiz += w * h
        elif h >= 1.5 * w:
            vert += w * h
    if horiz + vert == 0:
        return img_np, boxes, 0
    vertical = vert > 1.2 * horiz
    cands = (0, 90, 270) if vertical else (0, 180)

    ranked = sorted(boxes, key=lambda b: -max(preprocess.box_size(b)))
    samples = []
    for b in ranked:
        w, h = preprocess.box_size(b)
        if max(w, h) >= 40 and max(w, h) / max(1.0, min(w, h)) >= 1.5:
            samples.append(crop_by_polygon(img_np, b))
        if len(samples) >= ORIENT_SAMPLES:
            break
    if len(samples) < 2:  # quá ít chữ để kết luận
        return img_np, boxes, 0

    def prep(c, rot):
        return _segments(_normalize_crop(preprocess.rotate_np_cw(c, rot)))[0]

    scores = {rot: _orientation_score([prep(c, rot) for c in samples], predictor) for rot in cands}
    if vertical:
        best = max(scores, key=scores.get)
        if best != 0 and scores[best] < scores[0] + 0.10:
            best = 0
    else:
        best = 180 if scores[180] > scores[0] + FLIP_MARGIN else 0
    if best == 0:
        return img_np, boxes, 0

    rotated = preprocess.rotate_np_cw(img_np, best)
    new_boxes = _detect(rotated, det_model)
    if not new_boxes:
        return img_np, boxes, 0
    return rotated, new_boxes, best


def _deskew(img_np, boxes, det_model):
    """Trả về (ảnh, hộp, góc đã chỉnh). Chỉ nhận kết quả nếu sau khi xoay độ nghiêng thật sự giảm."""
    a = preprocess.estimate_skew(boxes)
    if a is None or not SKEW_MIN <= abs(a) <= SKEW_MAX:
        return img_np, boxes, 0.0
    rotated = preprocess.rotate_free(img_np, a)
    new_boxes = _detect(rotated, det_model)
    if not new_boxes:
        return img_np, boxes, 0.0
    a2 = preprocess.estimate_skew(new_boxes)
    if a2 is not None and abs(a2) >= abs(a):
        return img_np, boxes, 0.0
    return rotated, new_boxes, a


# ----------------------------------------------------------------- Kết quả
def _level(conf, bad_ratio):
    lvl = 1  # 0 xanh, 1 vàng, 2 đỏ (không có điểm tin cậy -> mặc định vàng)
    if conf is not None:
        lvl = 2 if conf < RED_CONF else 1 if conf < LOW_CONF else 0
    if bad_ratio >= 0.34:
        lvl = 2
    elif bad_ratio > 0:
        lvl = max(lvl, 1)
    return ("green", "yellow", "red")[lvl]


def _overall(lines):
    """Độ tin cậy chung = trung bình có trọng số theo số ký tự (%), bỏ qua dòng không có điểm."""
    num = den = 0.0
    for ln in lines:
        if ln["conf"] is not None:
            n = max(1, len(ln["text"]))
            num += ln["conf"] * n
            den += n
    return round(num / den, 1) if den else None


def _preview(img_np, max_side=900):
    h, w = img_np.shape[:2]
    k = min(1.0, max_side / max(h, w))
    if k < 1:
        img_np = cv2.resize(img_np, (max(1, int(w * k)), max(1, int(h * k))), interpolation=cv2.INTER_AREA)
    ok, buf = cv2.imencode(".jpg", cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 82])
    return "data:image/jpeg;base64," + base64.b64encode(buf.tobytes()).decode() if ok else None


# ----- Điểm vào cho Flask -----
def run_ocr(image, mode="paragraph", check_resolution=True, rotation=0, auto_orient=True,
            enhance="auto", want_preview=False, reflow=False):
    """
    image:        PIL.Image
    mode:         giữ lại tham số cho tương thích, hiện chỉ hỗ trợ văn bản in thông thường.
    rotation:     xoay thủ công theo chiều kim đồng hồ (0/90/180/270) trước khi xử lý.
    auto_orient:  tự nhận biết và xoay đúng chiều chữ + chỉnh nghiêng.
    enhance:      'auto' | 'off' | 'strong' (xem preprocess.prepare).
    want_preview: kèm ảnh sau xử lý (data URL) để người dùng xem máy đã "nhìn" thấy gì.
    reflow:       True = nối các dòng cùng một đoạn thành đoạn văn (reflow.py); False (mặc định) = mỗi dòng trong ảnh đúng một hàng.
    Trả về dict: text, lines [{text, conf %, level, bad, refined}], confidence %, level,
                 quality (Quality Score của ảnh), input_advice (cảnh báo/đề xuất đầu vào), notes, rotation, deskew, elapsed_ms.
    Ném NoTextFound (kèm .quality) nếu không có vùng chữ nào.
    """
    t0 = time.perf_counter()
    image, q, notes = preprocess.prepare(image, check_resolution=check_resolution, rotation=rotation,
                                         enhance=enhance, is_photo=check_resolution)

    def no_text():
        err = NoTextFound()
        err.quality = input_advisor.no_text_issue(q)   # kèm cảnh báo "không thấy vùng chữ" để giao diện giải thích
        return err

    det_model, vietocr_detector = load_models()
    img_np = np.ascontiguousarray(np.array(image))
    boxes = _detect(img_np, det_model)
    if not boxes:
        raise no_text()

    auto_rot, skew = 0, 0.0
    if auto_orient:
        img_np, boxes, auto_rot = _auto_orient(img_np, boxes, det_model, vietocr_detector)
        img_np, boxes, skew = _deskew(img_np, boxes, det_model)
        if auto_rot:
            notes.append(f"Đã tự xoay ảnh {auto_rot}° cho đúng chiều chữ.")
        if skew:
            notes.append(f"Đã chỉnh ảnh nghiêng {abs(skew):.1f}°.")

    # Chữ quá nhỏ (đo theo chiều cao dòng chữ trong ảnh ĐÃ xử lý) -> bổ sung cảnh báo chất lượng đầu vào
    heights = [min(preprocess.box_size(b)) for b in boxes]
    q = input_advisor.text_size_issue(q, float(np.median(heights)) if heights else None)

    groups = group_rows(boxes)
    ordered = [boxes[i] for g in groups for i in g]
    scored = recognize_scored(img_np, ordered, vietocr_detector)
    scored, n_symbols = recover_symbols(img_np, ordered, scored, vietocr_detector)
    if n_symbols:
        notes.append(f"Đã nhận lại {n_symbols} ký hiệu so sánh (<, >, =, <=, >=) bằng nhận dạng hình dạng vì model chữ hay đọc sai các ký hiệu này.")

    lines, bad_total, pos = [], 0, 0
    for g in groups:
        parts = [s for s in scored[pos:pos + len(g)] if s[0].strip()]
        pts = np.concatenate(ordered[pos:pos + len(g)])   # khung bao của cả dòng (dùng để nhận ra đoạn văn)
        pos += len(g)
        if not parts:
            continue
        text = fix_sentence_case(" ".join(p[0].strip() for p in parts))
        conf = _merge_conf([(p[0], p[1]) for p in parts])
        bad, checked = vi_check.check_line(text)
        bad_total += len(bad)
        lines.append({
            "text": text,
            "conf": None if conf is None else round(conf * 100, 1),
            "level": _level(conf, len(bad) / checked if checked else 0),
            "bad": bad,
            "refined": any(p[2] for p in parts),
            "box": [round(float(pts[:, 0].min()), 1), round(float(pts[:, 1].min()), 1),
                    round(float(pts[:, 0].max()), 1), round(float(pts[:, 1].max()), 1)],
        })

    if not lines:
        raise no_text()

    overall = _overall(lines)
    if reflow:
        paragraphs = reflow_mod.paragraphs_from_geometry(lines)
    else:
        paragraphs = [{"text": ln["text"], "conf": ln["conf"], "lines": [k]} for k, ln in enumerate(lines)]
    return {
        "text": reflow_mod.join_paragraphs(paragraphs),
        "paragraphs": [{"text": p["text"], "conf": p["conf"]} for p in paragraphs],
        "lines": lines,
        "confidence": overall,
        "level": None if overall is None else "green" if overall >= LOW_CONF * 100 else "yellow" if overall >= RED_CONF * 100 else "red",
        "bad_words": bad_total,
        "quality": q,
        "input_advice": input_advisor.build(q, enhance, auto_orient, check_resolution),
        "notes": notes,
        "rotation": auto_rot,
        "deskew": round(skew, 1),
        "processed_preview": _preview(img_np) if want_preview else None,
        "elapsed_ms": int((time.perf_counter() - t0) * 1000),
    }
