"""
Nhận lại các KÝ HIỆU SO SÁNH  <  >  =  <=  >=  trong ảnh dòng chữ.

Vấn đề: VietOCR được huấn luyện chủ yếu trên chữ tiếng Việt nên rất hay đọc sai các ký hiệu toán học,
ví dụ "(0 < n < 100)" thành "(0 Sn 5 100)" và "(0 <= p <= n)" thành "(0 ? p 4 n)".

Cách làm (không cần huấn luyện lại model):
  1. Tách ảnh dòng thành các "cụm" chữ theo khoảng trắng, tìm cụm nhỏ, nằm giữa dòng, có hình dạng giống ký hiệu.
  2. So khớp hình dạng với mẫu vẽ sẵn từ các font (Times/Liberation Serif, DejaVu...) bằng tương quan chuẩn hóa.
     Ngưỡng chặt: thà bỏ sót còn hơn thay nhầm chữ/số bình thường.
  3. Xóa các ký hiệu đã nhận ra khỏi ảnh dòng rồi cho VietOCR đọc phần chữ còn lại (đọc tốt hơn vì không bị nhiễu),
     sau đó chèn ký hiệu về đúng vị trí giữa các từ (ghép theo thứ tự cụm; nếu số từ không khớp thì ước lượng theo tỉ lệ).

Module này chỉ dùng OpenCV/NumPy/Pillow, không phụ thuộc model nên test được độc lập.
"""

import os

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OPS = ("<", ">", "=", "<=", ">=")
SIZE = 24                       # cạnh ảnh chuẩn hóa để so khớp
MIN_SCORE = {"<": 0.70, ">": 0.70, "<=": 0.70, ">=": 0.70, "=": 0.58}   # độ giống tối thiểu với mẫu ("=" mỏng nên dễ bị mờ hơn)
MIN_MARGIN = 0.06               # hơn ký hiệu giống thứ nhì ít nhất mức này
ASPECT = {"<": (0.55, 2.0), ">": (0.55, 2.0), "=": (1.0, 3.4), "<=": (1.3, 3.8), ">=": (1.3, 3.8)}
_templates = None


def _font_paths():
    win = os.environ.get("WINDIR", r"C:\Windows")
    cands = [
        os.path.join(win, "Fonts", "times.ttf"), os.path.join(win, "Fonts", "arial.ttf"),
        "/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
        os.path.join(BASE_DIR, "fonts", "DejaVuSans.ttf"),
    ]
    return [p for p in cands if os.path.isfile(p)]


def _norm(mask):
    """Cắt khung sát mực rồi đưa về SIZE x SIZE, làm mờ nhẹ. mask: bool/uint8. Trả về (ảnh float, tỉ lệ rộng/cao) hoặc None."""
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        return None
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    patch = mask[y0:y1, x0:x1].astype(np.float32)
    small = cv2.resize(patch, (SIZE, SIZE), interpolation=cv2.INTER_AREA)
    small = cv2.GaussianBlur(small, (0, 0), 1.0)
    return small, (x1 - x0) / float(y1 - y0)


def _build_templates():
    out = {op: [] for op in OPS}
    for path in _font_paths():
        try:
            font = ImageFont.truetype(path, 96)
        except OSError:
            continue
        for op in OPS:
            im = Image.new("L", (400, 200), 0)
            ImageDraw.Draw(im).text((20, 20), op, font=font, fill=255)
            r = _norm(np.array(im) > 128)
            if r:
                out[op].append(r[0])
    return out


def templates():
    global _templates
    if _templates is None:
        _templates = _build_templates()
    return _templates


def _ncc(a, b):
    a, b = a - a.mean(), b - b.mean()
    d = float(np.sqrt((a * a).sum() * (b * b).sum()))
    return float((a * b).sum() / d) if d > 1e-6 else 0.0


def classify(mask):
    """Phân loại một cụm mực (mask) thành ký hiệu so sánh. Trả về (op, điểm) hoặc (None, điểm tốt nhất)."""
    r = _norm(mask)
    if r is None:
        return None, 0.0
    img, aspect = r
    scores = {}
    for op, tpls in templates().items():
        lo, hi = ASPECT[op]
        if tpls and lo <= aspect <= hi:
            scores[op] = max(_ncc(img, t) for t in tpls)
    if not scores:
        return None, 0.0
    ranked = sorted(scores.items(), key=lambda kv: -kv[1])
    best, s1 = ranked[0]
    s2 = ranked[1][1] if len(ranked) > 1 else -1.0
    if s1 >= MIN_SCORE[best] and s1 - s2 >= MIN_MARGIN:
        return best, s1
    return None, s1


# ----------------------------------------------------------------- Tách cụm chữ trong ảnh dòng
def _ink(crop):
    """Mặt nạ mực (True = nét chữ) của ảnh dòng (chữ tối trên nền sáng)."""
    gray = cv2.cvtColor(crop, cv2.COLOR_RGB2GRAY) if crop.ndim == 3 else crop
    gray = cv2.GaussianBlur(gray, (0, 0), 0.6)
    thr = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[0]
    return gray < thr


def _word_gap(cols, xh):
    """
    Ngưỡng khe trống (pixel) phân biệt khoảng trắng giữa từ với khe giữa các chữ trong một từ.
    Khe giữa chữ nhỏ, khoảng trắng lớn: chia hai nhóm bằng 2-means rồi giới hạn trong [0.2, 0.4] x chiều cao chữ.
    """
    xs = np.nonzero(cols)[0]
    gaps = np.diff(xs) - 1
    gaps = gaps[gaps > 0].astype(np.float64)
    lo_b, hi_b = 0.20 * xh, 0.40 * xh
    thr = 0.30 * xh
    if len(gaps) >= 6:
        for _ in range(8):
            a, b = gaps[gaps <= thr], gaps[gaps > thr]
            if len(a) == 0 or len(b) == 0:
                break
            thr = (a.mean() + b.mean()) / 2.0
    return int(round(min(max(thr, lo_b), hi_b)))


def analyze(crop):
    """
    Trả về (cụm, ký hiệu): cụm = [{x0, x1, y0, y1, op}] theo thứ tự trái -> phải (op=None nếu là chữ thường),
    ký hiệu = các cụm có op. Danh sách rỗng nếu không thấy ký hiệu nào.
    """
    h, w = crop.shape[:2]
    ink = _ink(crop)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(ink.astype(np.uint8), connectivity=8)
    comps = [(i, *stats[i][:4]) for i in range(1, n) if stats[i][4] >= max(3, 0.0015 * h * h)]  # bỏ hạt nhiễu
    # chiều cao chữ "điển hình": trung vị chiều cao các nét lớn
    big = [c[4] for c in comps if c[4] >= 0.25 * h]
    if len(comps) < 3 or not big:
        return [], []
    xh = float(np.median(big))
    keep = np.zeros(n, bool)
    for i, *_ in comps:
        keep[i] = True
    mask = keep[lab]
    cols = mask.any(axis=0)
    # gom cột có mực thành cụm; khe hở lớn hơn ngưỡng (khoảng trắng giữa từ) thì tách thành các cụm khác nhau
    gap = _word_gap(cols, xh)
    blobs, i = [], 0
    while i < w:
        if cols[i]:
            j, last = i, i
            while j < w and (cols[j] or j - last <= gap):
                if cols[j]:
                    last = j
                j += 1
            blobs.append([i, last + 1])
            i = last + 1
        else:
            i += 1
    out = []
    centers = [c[2] + c[4] / 2.0 for c in comps if c[4] >= 0.3 * xh]
    mid = float(np.median(centers)) if centers else h / 2.0
    for x0, x1 in blobs:
        sub = mask[:, x0:x1]
        ys = np.nonzero(sub.any(axis=1))[0]
        y0, y1 = int(ys.min()), int(ys.max()) + 1
        bh, bw = y1 - y0, x1 - x0
        op = None
        # ký hiệu: thấp (cỡ chữ thường), nằm giữa dòng, không quá nhỏ/quá dài
        if 0.30 * xh <= bh <= 1.15 * xh and 0.35 * xh <= bw <= 3.4 * xh and abs((y0 + y1) / 2.0 - mid) <= 0.45 * xh:
            op, _ = classify(sub[y0:y1])
            if op == "=" and bh > 0.85 * xh:        # "=" chỉ cao khoảng một nửa chữ thường
                op = None
            elif op in ("<", ">") and bh < 0.45 * xh:
                op = None
        out.append({"x0": x0, "x1": x1, "y0": y0, "y1": y1, "op": op, "dash": False})
    if out and out[0]["op"] is None:      # gạch đầu dòng "-": cụm đầu tiên, mỏng, dẹt, nằm quanh giữa dòng
        b = out[0]
        bh, bw = b["y1"] - b["y0"], b["x1"] - b["x0"]
        if bh <= 0.22 * xh and 0.25 * xh <= bw <= 1.4 * xh and abs((b["y0"] + b["y1"]) / 2.0 - mid) <= 0.45 * xh:
            b["dash"] = True
    out = _merge_pairs(out)
    return out, [b for b in out if b["op"]]


def _merge_pairs(blobs):
    """'<' + '=' (hoặc '>' + '=') đứng sát nhau -> '<=' / '>=' (một số font viết hai ký tự cách nhau một khe nhỏ)."""
    out = []
    for b in blobs:
        p = out[-1] if out else None
        if p and p["op"] in ("<", ">") and b["op"] == "=" and b["x0"] - p["x1"] <= 0.8 * max(p["y1"] - p["y0"], 1):
            out[-1] = {"x0": p["x0"], "x1": b["x1"], "y0": min(p["y0"], b["y0"]), "y1": max(p["y1"], b["y1"]), "op": p["op"] + "="}
        else:
            out.append(b)
    return out


def erase(crop, blobs):
    """Xóa các cụm ký hiệu khỏi ảnh dòng (tô màu nền), trả về ảnh mới."""
    out = crop.copy()
    h = crop.shape[0]
    ink = _ink(crop)
    bg = np.median(crop[~ink], axis=0) if (~ink).any() else np.array([255] * (crop.shape[2] if crop.ndim == 3 else 1))
    for b in blobs:
        if b["op"]:
            out[:, max(0, b["x0"] - 2):b["x1"] + 2] = bg
    return out


# ----------------------------------------------------------------- Chèn ký hiệu vào văn bản đã đọc
def splice(text, blobs):
    """
    text: văn bản VietOCR đọc từ ảnh đã xóa ký hiệu. blobs: kết quả analyze() (đủ các cụm, có op).
    Trả về văn bản có ký hiệu được chèn đúng chỗ giữa các từ.
    """
    tokens = text.split()
    ops_at = {}          # chỉ số cụm chữ (không tính ký hiệu) -> các ký hiệu đứng ngay trước nó
    words = 0
    pending = []
    for b in blobs:
        if b["op"]:
            pending.append(b["op"])
        else:
            if pending:
                ops_at[words] = pending
                pending = []
            words += 1
    trailing = pending
    if not any(b["op"] for b in blobs):
        return text
    if words == len(tokens):                      # số từ khớp: chèn chính xác theo thứ tự
        pos = {k: k for k in range(words)}
    else:                                         # lệch: ước lượng theo tỉ lệ chiều rộng mực của phần chữ
        widths = [b["x1"] - b["x0"] for b in blobs if not b["op"]]
        total_w = float(sum(widths)) or 1.0
        total_c = float(sum(len(t) for t in tokens)) or 1.0
        pos, acc_w = {}, 0.0
        cum = [0]
        for t in tokens:
            cum.append(cum[-1] + len(t))
        for k in range(words + 1):
            frac = acc_w / total_w
            best = min(range(len(tokens) + 1), key=lambda m: abs(cum[m] / total_c - frac))
            pos[k] = best
            if k < words:
                acc_w += widths[k]
    out = list(tokens)
    inserts = []
    for k, ops in ops_at.items():
        inserts.append((pos[k], " ".join(ops)))
    if trailing:
        inserts.append((len(tokens), " ".join(trailing)))
    for p, s in sorted(inserts, key=lambda t: -t[0]):
        out.insert(min(p, len(out)), s)
    return " ".join(out)


# ----------------------------------------------------------------- Đọc riêng từng đoạn chữ giữa các ký hiệu
def word_count(blobs):
    """Số cụm chữ (không tính ký hiệu) trong ảnh dòng."""
    return sum(1 for b in blobs if not b["op"])


def has_leading_dash(blobs):
    return bool(blobs) and not blobs[0]["op"] and bool(blobs[0].get("dash"))


def _bg_color(crop):
    ink = _ink(crop)
    if (~ink).any():
        return np.median(crop[~ink], axis=0)
    return np.array([255] * (crop.shape[2] if crop.ndim == 3 else 1))


def pieces(crop, blobs):
    """
    Cắt ảnh dòng thành các phần theo thứ tự trái -> phải: ("op", "<=") hoặc ("text", ảnh đoạn chữ).
    Mỗi đoạn chữ nằm giữa hai ký hiệu (hoặc đầu/cuối dòng) và được đệm thêm nền hai bên để model chữ đọc ổn định.
    Dùng khi số từ model đọc được KHÔNG khớp số cụm chữ (vd model đọc dính "p n" thành "p.n"): lúc đó không thể ghép ký hiệu
    theo thứ tự từ nữa, nên đọc từng đoạn riêng -> vị trí ký hiệu luôn đúng vì do hình học quyết định.
    """
    h = crop.shape[0]
    bg = _bg_color(crop)
    out, run = [], []

    def flush():
        if not run:
            return
        x0, x1 = run[0]["x0"], run[-1]["x1"]
        seg = crop[:, max(0, x0 - 2):min(crop.shape[1], x1 + 2)]
        pad = max(int(0.6 * h), (2 * h - seg.shape[1]) // 2 + 1)
        seg = cv2.copyMakeBorder(seg, 0, 0, pad, pad, cv2.BORDER_CONSTANT, value=[float(v) for v in np.atleast_1d(bg)])
        out.append(("text", seg))
        run.clear()

    for b in blobs:
        if b["op"]:
            flush()
            out.append(("op", b["op"]))
        else:
            run.append(b)
    flush()
    return out
