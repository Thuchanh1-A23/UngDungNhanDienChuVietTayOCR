import io
import unittest
from unittest import mock

import numpy as np
from PIL import Image

import helpers
from helpers import png_bytes, fake_result

import accuracy
import app as appmod
import ocr_engine
import reflow

H, L, R = 30, 100, 1000


def line(text, y, x0=L, x1=R, conf=95.0):
    return {"text": text, "conf": conf, "box": [x0, y, x1, y + H]}


def groups(items):
    return [p["lines"] for p in reflow.paragraphs_from_geometry(items)]


class ReflowTests(unittest.TestCase):
    def test_wrapped_paragraph_is_joined_and_last_short_line_ends_it(self):
        items = [line("Thế giới ngầm là sự gặp gỡ giữa một bên là ý chí cương cường", 100),
                 line("và nền tảng gia tộc chặt chẽ theo truyền thống Mafia xứ Sicily", 142),
                 line("đen trắng, mảnh đất màu mỡ cho những cơ hội làm ăn.", 184, x1=700),
                 line("Trong thế giới ấy, hình tượng Bố già được tác giả dày công khắc họa", 226),
                 line("hủ trong lòng người đọc", 268, x1=420)]
        self.assertEqual(groups(items), [[0, 1, 2], [3, 4]])
        ps = reflow.paragraphs_from_geometry(items)
        self.assertIn("ý chí cương cường và nền tảng", ps[0]["text"])      # nối bằng dấu cách, câu không còn đứt
        self.assertEqual(reflow.join_paragraphs(ps).count("\n\n"), 1)
        self.assertNotIn("\n", ps[0]["text"])

    def test_forms_lists_headings_stay_line_by_line(self):
        form = [line("Họ và tên: Nguyễn Văn A", 100, x1=400), line("Ngày sinh: 01/02/2000", 142, x1=380),
                line("Địa chỉ: Hà Nội", 184, x1=330), line("dòng dài làm lề phải của trang văn bản", 226)]
        self.assertEqual(groups(form), [[0], [1], [2], [3]])
        self.assertNotIn("\n\n", reflow.join_paragraphs(reflow.paragraphs_from_geometry(form)))   # không nối gì -> giữ nguyên 1 dòng/hàng
        lst = [line("Các bước thực hiện đầy đủ trong quy trình như sau và phải tuân thủ", 100),
               line("1. Chuẩn bị hồ sơ đầy đủ theo hướng dẫn của cơ quan có thẩm quyền ở trên", 142),
               line("2. Nộp hồ sơ tại bộ phận một cửa của đơn vị trong giờ hành chính hằng ngày", 184),
               line("- ghi chú thêm một ý nhỏ nữa cho đầy đủ nội dung văn bản này nhé các bạn", 226)]
        self.assertEqual(groups(lst), [[0], [1], [2], [3]])
        head = [line("CHƯƠNG 1", 100, x0=450, x1=650), line("Nội dung đoạn văn đầu tiên chạy hết bề ngang của cột chữ trong trang", 142),
                line("và tiếp tục sang dòng thứ hai của cùng một đoạn văn như thế này đây", 184)]
        self.assertEqual(groups(head), [[0], [1, 2]])

    def test_indent_gap_and_columns(self):
        ind = [line("Dòng một dài đầy đủ của đoạn thứ nhất chạy hết cột chữ", 100), line("dòng hai dài đầy đủ của đoạn thứ nhất chạy hết cột chữ", 142),
               line("Đoạn hai bắt đầu thụt vào đầu dòng ở đây chạy hết cột chữ", 184, x0=L + 60), line("dòng hai của đoạn hai chạy đầy đủ hết cột chữ trong trang", 226)]
        self.assertEqual(groups(ind), [[0, 1], [2, 3]])
        first_indented = [line("Dòng đầu thụt vào của đoạn văn dài đầy đủ chữ chạy hết cột", 100, x0=L + 60),
                          line("dòng hai nằm ở lề trái chạy hết cột chữ trong trang văn bản", 142),
                          line("dòng ba cũng vậy chạy hết cột chữ trong trang văn bản đây nhé", 184)]
        self.assertEqual(groups(first_indented), [[0, 1, 2]])
        gap = [line("Đoạn một chạy hết bề ngang của cột chữ trong trang văn bản này", 100), line("Đoạn hai cách xa đoạn một bằng một khoảng trắng lớn giữa hai đoạn", 190)]
        self.assertEqual(groups(gap), [[0], [1]])
        cols = [line("Cột trái dòng một của văn bản dài ở đây", 100, x1=520), line("Cột phải dòng một của văn bản dài", 100, x0=560),
                line("Cột trái dòng hai của văn bản dài ở đây", 142, x1=520), line("Cột phải dòng hai của văn bản dài", 142, x0=560)]
        self.assertEqual(groups(cols), [[0], [1], [2], [3]])

    def test_edge_cases(self):
        self.assertEqual(reflow.paragraphs_from_geometry([]), [])
        self.assertEqual(groups([line("một dòng", 10)]), [[0]])
        self.assertEqual(reflow.join_paragraphs([]), "")

    def test_paragraph_confidence_is_char_weighted(self):
        items = [line("a" * 90, 100, conf=100.0), line("b" * 10, 142, conf=0.0)]
        items = [line("a" * 90, 100, conf=100.0), line("b" * 10, 142, x1=R, conf=0.0)]
        p = reflow.paragraphs_from_geometry(items)
        self.assertEqual(p[0]["lines"], [0, 1])
        self.assertEqual(p[0]["conf"], 90.0)

    def test_reflow_never_changes_accuracy(self):
        lines = ["Thế giới ngầm là sự gặp gỡ", "và nền tảng gia tộc chặt chẽ", "theo truyền thống."]
        self.assertEqual(accuracy.evaluate(" ".join(lines), "\n".join(lines))["cer"], 0.0)
        self.assertEqual(accuracy.evaluate("\n\n".join(lines), "\n".join(lines))["wer"], 0.0)


class EngineIntegrationTests(unittest.TestCase):
    """Chạy run_ocr thật (tiền xử lý, gom dòng, ghép đoạn) với detection/recognition giả."""

    def run_engine(self, reflow_on):
        img = Image.new("RGB", (1200, 700), "white")
        rows = [("Thế giới ngầm là sự gặp gỡ giữa một bên là ý chí cương cường", 1000), ("và nền tảng gia tộc chặt chẽ theo truyền thống Mafia xứ Sicily", 1000),
                ("đen trắng, mảnh đất màu mỡ làm ăn bất chính.", 600), ("Trong thế giới ấy hình tượng Bố già được khắc họa", 1000), ("hủ trong lòng người đọc", 450)]
        boxes = [np.array([[100, 60 + i * 50], [x1, 60 + i * 50], [x1, 90 + i * 50], [100, 90 + i * 50]], np.float32) for i, (_, x1) in enumerate(rows)]
        scored = [(t, 0.95, False) for t, _ in rows]
        with mock.patch.object(ocr_engine, "load_models", return_value=(None, None)), mock.patch.object(ocr_engine, "_detect", return_value=boxes), \
                mock.patch.object(ocr_engine, "recognize_scored", return_value=scored):
            return ocr_engine.run_ocr(img, auto_orient=False, enhance="off", reflow=reflow_on)

    def test_reflow_on_joins_paragraphs_but_keeps_per_line_confidence(self):
        r = self.run_engine(True)
        self.assertEqual(len(r["lines"]), 5)
        self.assertEqual(len(r["paragraphs"]), 2)
        paras = r["text"].split("\n\n")
        self.assertEqual(len(paras), 2)
        self.assertIn("cương cường và nền tảng", paras[0])
        self.assertTrue(all("\n" not in p for p in paras))
        self.assertTrue(all(ln["text"] in r["text"] for ln in r["lines"]))   # bấm dòng trong danh sách vẫn tìm thấy trong ô kết quả

    def test_reflow_off_is_one_row_per_line_like_before(self):
        r = self.run_engine(False)
        self.assertEqual(r["text"].count("\n"), 4)
        self.assertNotIn("\n\n", r["text"])


class AppReflowTests(unittest.TestCase):
    def setUp(self):
        appmod.app.config["TESTING"] = True
        self.c = appmod.app.test_client()
        appmod._cache.clear()
        self.run = mock.patch.object(ocr_engine, "run_ocr", return_value=fake_result()).start()
        self.addCleanup(mock.patch.stopall)

    def post(self, **form):
        return self.c.post("/api/ocr", data={**form, "file": (io.BytesIO(png_bytes()), "a.png")}, content_type="multipart/form-data")

    def test_option_is_forwarded_default_off_and_part_of_cache_key(self):
        self.post()
        self.assertFalse(self.run.call_args.kwargs["reflow"])      # mặc định: đúng từng dòng như ảnh
        self.post(reflow="1")
        self.assertTrue(self.run.call_args.kwargs["reflow"])
        self.assertEqual(self.run.call_count, 2)          # bật/tắt nối dòng không được dùng nhầm kết quả đệm của nhau


class LegalTextTests(unittest.TestCase):
    """Văn bản dạng Điều/khoản như ảnh mẫu: tiêu đề và từng khoản 1. 2. 3. phải tách riêng."""

    def test_headings_and_numbered_items(self):
        for t in ("Điều 32. Công tác", "Chương VI", "Mục 2", "2. Đơn vị", "2.Đơn vị", "3) abc"):
            self.assertTrue(reflow.starts_item(t), t)
        for t in ("1.5 triệu đồng", "10.000 đồng", "quyền tổ chức", "điều 5 của luật"):
            self.assertFalse(reflow.starts_item(t), t)

    def test_items_are_never_glued_together(self):
        rows = [("Điều 32. Công tác thanh tra", 145, 560), ("1. Hiệu trưởng hoặc các đơn vị quản lý sinh viên được", 145, 632),
                ("quyền tổ chức thanh tra, kiểm tra việc thực hiện công tác sinh viên.", 112, 560),
                ("2.Đơn vị, cá nhân có thành tích trong công tác sinh viên được xét khen thưởng theo", 145, 632), ("quy định.", 112, 200),
                ("3. Đơn vị, cá nhân vi phạm Quy định về công tác sinh viên tùy theo mức độ sẽ bị xử lý", 145, 632), ("theo quy định.", 112, 260)]
        items = [{"text": t, "conf": 90.0, "box": [a, 30 + i * 21, b, 48 + i * 21]} for i, (t, a, b) in enumerate(rows)]
        out = reflow.join_paragraphs(reflow.paragraphs_from_geometry(items)).split("\n\n")
        self.assertEqual(len(out), 4)
        self.assertTrue(out[2].startswith("2.") and out[3].startswith("3."))


class GroupRowsTests(unittest.TestCase):
    def test_tight_tilted_lines_stay_separate(self):
        def box(x0, x1, y, h=18, tilt=0.026):
            dy = (x1 - x0) * tilt
            return np.array([[x0, y], [x1, y + dy], [x1, y + dy + h], [x0, y + h]], dtype=np.float32)
        xs = [(145, 420), (112, 560), (112, 630), (145, 600), (112, 455), (145, 630), (112, 300), (145, 630)]
        for pitch in (21, 19, 18):      # dòng sát nhau + ảnh hơi nghiêng: khung bao chồng lấn nhưng vẫn là 8 dòng riêng
            groups = ocr_engine.group_rows([box(a, b, 30 + i * pitch) for i, (a, b) in enumerate(xs)])
            self.assertEqual(len(groups), 8, pitch)


class GroundTruthFromPdfTests(unittest.TestCase):
    """PDF không còn là đầu vào OCR, nhưng vẫn dùng được để nạp Ground Truth (PDF số)."""

    def setUp(self):
        appmod.app.config["TESTING"] = True
        self.c = appmod.app.test_client()

    def up(self, data, name="a.pdf"):
        return self.c.post("/api/ground-truth-from-pdf", data={"file": (io.BytesIO(data), name)}, content_type="multipart/form-data")

    def test_digital_pdf_gives_exact_text_line_by_line(self):
        j = self.up(helpers.pdf_bytes(2)).get_json()
        self.assertTrue(j["success"])
        self.assertEqual(j["pages"], 2)
        self.assertIn("Cộng hòa xã hội chủ nghĩa Việt Nam 2", j["text"])
        self.assertIn("=== Trang 2 ===", j["text"])
        one = self.up(helpers.pdf_bytes(1)).get_json()["text"]
        self.assertEqual(one.split("\n")[1], "Độc lập - Tự do - Hạnh phúc")      # mỗi dòng PDF một hàng, không nối đoạn
        ocr = "\n".join(helpers.VN_LINES).replace("Cộng hòa xã hội chủ nghĩa Việt Nam", "Cộng hòa xã hội chủ nghĩa Việt Nam 1")
        self.assertEqual(accuracy.evaluate(ocr, one)["cer"], 0.0)

    def test_scanned_pdf_and_images_are_refused(self):
        r = self.up(helpers.pdf_bytes(2, scanned=True))
        self.assertEqual(r.status_code, 422)
        self.assertEqual(r.get_json()["code"], "gt_not_digital")
        self.assertEqual(r.get_json()["pages"], [1, 2])
        self.assertNotIn("text", r.get_json())
        self.assertEqual(self.up(png_bytes(), "a.png").status_code, 400)
        self.assertEqual(self.up(b"not a pdf").status_code, 400)

    def test_mixed_pdf_is_refused_naming_the_bad_pages(self):
        from reportlab.pdfgen import canvas
        from reportlab.lib.pagesizes import A4
        helpers._font()
        buf = io.BytesIO()
        c = canvas.Canvas(buf, pagesize=A4)
        c.setFont("DJ", 12)
        for i, t in enumerate(helpers.VN_LINES):
            c.drawString(60, 780 - 20 * i, t)
        c.showPage()
        c.drawInlineImage(Image.new("RGB", (1240, 1754), "white"), 0, 0, width=595, height=842)   # trang 2 là ảnh scan
        c.showPage()
        c.save()
        r = self.up(buf.getvalue())
        self.assertEqual(r.status_code, 422)
        self.assertEqual(r.get_json()["pages"], [2])

    def test_pdf_text_trust_heuristics(self):
        import pdf_text
        self.assertTrue(pdf_text.looks_trustworthy(["Cộng hòa xã hội chủ nghĩa Việt Nam", "Độc lập - Tự do - Hạnh phúc"]))
        self.assertFalse(pdf_text.looks_trustworthy(["Céng hßa x· héi chñ nghÜa ViÖt Nam", "§éc lËp - Tù do"]))   # font TCVN3
        self.assertFalse(pdf_text.looks_trustworthy(["Hi"]))


if __name__ == "__main__":
    unittest.main()
