import os
import random
import tempfile
import unicodedata
import unittest
from unittest import mock

import helpers  # noqa: F401  (thêm thư mục gốc vào sys.path)
import accuracy
import evaluate


def dp_distance(a, b):
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


class MetricTests(unittest.TestCase):
    def test_edit_distance_matches_reference_dp(self):
        rnd, alpha = random.Random(3), "aàáăâeêoôơưđ ,."
        for _ in range(600):
            a = "".join(rnd.choice(alpha) for _ in range(rnd.randint(0, 30)))
            b = "".join(rnd.choice(alpha) for _ in range(rnd.randint(0, 30)))
            self.assertEqual(accuracy.edit_distance(a, b), dp_distance(a, b), (a, b))
        w1, w2 = "a b c d".split(), "a x c".split()
        self.assertEqual(accuracy.edit_distance(w1, w2), dp_distance(w1, w2))

    def test_perfect_and_known_errors(self):
        r = accuracy.evaluate("Việt Nam", "Việt Nam")
        self.assertEqual((r["cer"], r["wer"], r["char_accuracy"]), (0.0, 0.0, 100.0))
        r = accuracy.evaluate("Viet Nam", "Việt Nam")           # thiếu dấu: 1 ký tự sai / 8, 1 từ sai / 2
        self.assertEqual((r["cer"], r["wer"], r["char_accuracy"]), (12.5, 50.0, 87.5))
        self.assertEqual(r["char_distance"], 1)

    def test_spec_example_trường_đại_học(self):
        r = accuracy.evaluate("Trương đai hoc Công Nghê Thông Tin", "Trường Đại học Công Nghệ Thông Tin")
        self.assertEqual(r["char_distance"], 5)                 # ơ→ờ, đ→Đ, a→ạ, o→ọ, ê→ệ
        self.assertEqual(r["word_distance"], 4)

    def test_cer_can_exceed_100_but_accuracy_clamps_to_zero(self):
        r = accuracy.evaluate("x" * 10, "ab")
        self.assertEqual(r["cer"], 500.0)
        self.assertEqual(r["char_accuracy"], 0.0)

    def test_no_ground_truth_is_never_scored(self):
        for gt in (None, "", "  \n "):
            r = accuracy.evaluate("bất kỳ", gt)
            self.assertFalse(r["evaluated"])
            self.assertNotIn("cer", r)
            self.assertIn("Chưa đánh giá", r["message"])

    def test_empty_ocr_against_real_gt_is_total_error(self):
        r = accuracy.evaluate("", "abc")
        self.assertEqual((r["cer"], r["char_accuracy"]), (100.0, 0.0))

    def test_normalisation(self):
        nfd = unicodedata.normalize("NFD", "Việt Nam")
        self.assertEqual(accuracy.evaluate(nfd, "Việt Nam")["cer"], 0.0)                       # NFC/NFD không phải lỗi
        self.assertEqual(accuracy.evaluate("Hà   Nội\n\nngày", "Hà Nội ngày")["cer"], 0.0)      # khoảng trắng
        self.assertEqual(accuracy.evaluate("=== Trang 1 ===\nXin chào", "Xin chào")["cer"], 0.0)  # dấu trang của ứng dụng
        self.assertGreater(accuracy.evaluate("xin chào", "Xin chào")["cer"], 0)                 # mặc định phân biệt HOA/thường
        self.assertEqual(accuracy.evaluate("xin chào", "Xin chào", ignore_case=True)["cer"], 0.0)
        self.assertGreater(accuracy.evaluate("Hà Nội,", "Hà Nội")["cer"], 0)
        self.assertEqual(accuracy.evaluate("Hà Nội,", "Hà Nội", ignore_punct=True)["cer"], 0.0)
        self.assertGreater(accuracy.evaluate("Viet", "Việt")["cer"], 0)                         # sai dấu thanh/mũ là lỗi thật

    def test_aggregate_micro_weights_by_length(self):
        a = accuracy.evaluate("abcdefghij", "abcdefghix")   # 1/10
        b = accuracy.evaluate("zz", "ab")                   # 2/2
        g = accuracy.aggregate([a, b, {"evaluated": False}])
        self.assertEqual(g["samples"], 2)
        self.assertAlmostEqual(g["cer_micro"], round(3 / 12 * 100, 2))
        self.assertAlmostEqual(g["cer_macro"], round((10 + 100) / 2, 2))
        self.assertFalse(accuracy.aggregate([{"evaluated": False}])["evaluated"])


class DatasetTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = self.tmp.name

    def put(self, rel, content=b"x"):
        p = os.path.join(self.root, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        mode = "wb" if isinstance(content, bytes) else "w"
        with open(p, mode, **({} if mode == "wb" else {"encoding": "utf-8"})) as f:
            f.write(content)

    def make_png(self, rel):
        from PIL import Image
        p = os.path.join(self.root, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        Image.new("RGB", (60, 40), "white").save(p)

    def fake_ocr(self, mapping):
        def run(path):
            name = os.path.basename(path)
            return {"text": mapping.get(name, ""), "confidence": 91.0, "quality": {"score": 85, "level": "yellow"}}
        return run

    def test_pairing_categories_and_missing_gt(self):
        self.make_png("images/mo_nhe/a.png")
        self.put("ground_truth/mo_nhe/a.txt", "Xin chào Việt Nam")
        self.make_png("images/anh_ro_net/b.png")
        self.put("ground_truth/b.txt", "Hà Nội")                       # GT phẳng cũng được
        self.make_png("images/c.png")                                  # chưa có GT
        self.make_png("images/d.png")
        self.put("ground_truth_draft/d.txt", "bản nháp CHƯA xác nhận")   # bản nháp KHÔNG được dùng làm GT
        samples = {s["rel"]: s for s in evaluate.find_samples(self.root)}
        self.assertEqual(samples["mo_nhe/a.png"]["category"], "mo_nhe")
        self.assertTrue(samples["anh_ro_net/b.png"]["gt_path"])
        self.assertIsNone(samples["c.png"]["gt_path"])
        self.assertIsNone(samples["d.png"]["gt_path"])
        self.assertEqual(samples["c.png"]["category"], evaluate.UNCATEGORIZED)

        rows, summary = evaluate.evaluate_dataset(self.root, self.fake_ocr({"a.png": "Xin chao Viet Nam", "b.png": "Hà Nội", "c.png": "gì đó", "d.png": "gì đó"}), log=lambda *_: None)
        by = {r["file"]: r for r in rows}
        self.assertEqual(by["anh_ro_net/b.png"]["char_accuracy"], 100.0)
        self.assertGreater(by["mo_nhe/a.png"]["cer"], 0)
        for f in ("c.png", "d.png"):                                   # không GT: không có con số Accuracy nào
            self.assertFalse(by[f]["has_ground_truth"])
            self.assertIsNone(by[f]["cer"])
            self.assertIsNone(by[f]["char_accuracy"])
            self.assertIn("Chưa đánh giá Accuracy", by[f]["status"])
        self.assertEqual((summary["total_images"], summary["evaluated"], summary["not_evaluated"]), (4, 2, 2))
        self.assertIn("mo_nhe", summary["by_category"])

    def test_reports_written_and_utf8(self):
        self.make_png("images/x.png")
        self.put("ground_truth/x.txt", "Cộng hòa")
        rows, summary = evaluate.evaluate_dataset(self.root, self.fake_ocr({"x.png": "Cộng hoà"}), log=lambda *_: None)
        out = os.path.join(self.root, "out")
        md = evaluate.write_reports(rows, summary, out, {"ignore_case": False, "ignore_punct": False})
        for f in ("results.csv", "results.json", "summary.md", os.path.join("ocr_output", "x.txt")):
            self.assertTrue(os.path.isfile(os.path.join(out, f)), f)
        self.assertIn("Character Accuracy", md)
        self.assertIn("không phải", md)           # nhắc Quality/Confidence không phải Accuracy
        with open(os.path.join(out, "results.csv"), encoding="utf-8-sig") as f:
            self.assertIn("Cộng hòa", f.read())

    def test_no_gt_anywhere_reports_not_evaluated(self):
        self.make_png("images/x.png")
        rows, summary = evaluate.evaluate_dataset(self.root, self.fake_ocr({"x.png": "abc"}), log=lambda *_: None)
        md = evaluate.summary_markdown(summary, rows, {"ignore_case": False, "ignore_punct": False})
        self.assertIn("Chưa đánh giá Accuracy", md)
        self.assertFalse(summary["accuracy"]["evaluated"])

    def test_ocr_outputs_mode_does_not_need_models(self):
        self.make_png("images/x.png")
        self.put("ground_truth/x.txt", "Xin chào")
        self.put("saved/x.txt", "Xin chao")
        rows, _ = evaluate.evaluate_dataset(self.root, ocr_outputs_dir=os.path.join(self.root, "saved"), log=lambda *_: None)
        self.assertEqual(rows[0]["cer"], 12.5)
        self.assertIsNotNone(rows[0]["quality_score"])               # Quality Score vẫn được tính từ ảnh
        self.assertIsNone(rows[0]["ocr_confidence"])                 # không có model thì không có confidence, không bịa

    def test_draft_gt_never_overwrites(self):
        self.make_png("images/x.png")
        rows, _ = evaluate.evaluate_dataset(self.root, self.fake_ocr({"x.png": "nháp"}), log=lambda *_: None)
        self.assertEqual(evaluate.write_draft_gt(rows, self.root), 1)
        self.put("ground_truth_draft/x.txt", "đã sửa tay")
        self.assertEqual(evaluate.write_draft_gt(rows, self.root), 0)
        with open(os.path.join(self.root, "ground_truth_draft", "x.txt"), encoding="utf-8") as f:
            self.assertEqual(f.read(), "đã sửa tay")

    def test_one_failing_image_does_not_stop_the_run(self):
        self.make_png("images/a.png")
        self.make_png("images/b.png")
        def run(path):
            if path.endswith("a.png"):
                raise RuntimeError("hỏng")
            return {"text": "ok", "confidence": 90, "quality": None}
        rows, summary = evaluate.evaluate_dataset(self.root, run, log=lambda *_: None)
        self.assertEqual(len(rows), 2)
        self.assertIn("Lỗi", rows[0]["status"])

    def test_degrade_tool_makes_variants_with_same_gt(self):
        import sys
        sys.path.insert(0, os.path.join(helpers.ROOT, "tools"))
        import degrade
        self.make_png("clean.png")
        self.put("clean.txt", "Văn bản đúng")
        data = os.path.join(self.root, "ds")
        degrade.main([os.path.join(self.root, "clean.png"), "--gt", os.path.join(self.root, "clean.txt"), "--data", data,
                      "--variants", "mo_nhe,nghieng", "--include-original"])
        samples = evaluate.find_samples(data)
        self.assertEqual(sorted(s["category"] for s in samples), ["anh_ro_net", "mo_nhe", "nghieng"])
        self.assertTrue(all(s["gt_path"] for s in samples))
        self.assertIn("tổng hợp", next(s for s in samples if s["category"] == "mo_nhe")["note"])


if __name__ == "__main__":
    unittest.main()
