import io
import unittest
from unittest import mock

import helpers
from helpers import png_bytes, fake_result

import app as appmod
import ocr_engine


class AppTests(unittest.TestCase):
    def setUp(self):
        appmod.app.config["TESTING"] = True
        self.c = appmod.app.test_client()
        appmod._cache.clear()
        self.run_ocr = mock.patch.object(ocr_engine, "run_ocr", return_value=fake_result()).start()
        self.addCleanup(mock.patch.stopall)

    def post(self, url, data, filename=None, content=None, field="file"):
        data = dict(data)
        if content is not None:
            data[field] = (io.BytesIO(content), filename)
        return self.c.post(url, data=data, content_type="multipart/form-data")

    # ---- cơ bản / bảo mật
    def test_index_and_headers(self):
        r = self.c.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn("default-src 'self'", r.headers["Content-Security-Policy"])
        self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")

    def test_api_not_cached_and_json_404(self):
        r = self.c.get("/api/health")
        self.assertEqual(r.headers["Cache-Control"], "no-store")
        r = self.c.get("/api/khong-ton-tai")
        self.assertEqual(r.status_code, 404)
        self.assertFalse(r.get_json()["success"])

    # ---- ảnh
    def test_ocr_image_ok_and_cached(self):
        png = png_bytes()
        r = self.post("/api/ocr", {}, "a.png", png)
        self.assertTrue(r.get_json()["success"])
        r2 = self.post("/api/ocr", {}, "a.png", png)
        self.assertTrue(r2.get_json()["cached"])
        self.assertEqual(self.run_ocr.call_count, 1)

    def test_rejects_bad_files(self):
        self.assertEqual(self.post("/api/ocr", {}, "a.exe", b"MZ").status_code, 400)
        self.assertEqual(self.post("/api/ocr", {}, "a.png", b"not an image").status_code, 400)
        self.assertEqual(self.post("/api/ocr", {}, "a.pdf", b"not a pdf").status_code, 400)
        self.assertEqual(self.post("/api/ocr", {}, "a.png", b"").status_code, 400)
        self.assertEqual(self.post("/api/ocr", {"rotation": "45"}, "a.png", png_bytes()).status_code, 400)

    def test_no_text_found(self):
        err = ocr_engine.NoTextFound()
        err.quality = None
        with mock.patch.object(ocr_engine, "run_ocr", side_effect=err):
            r = self.post("/api/ocr", {}, "a.png", png_bytes())
        self.assertEqual(r.status_code, 422)

    def test_engine_error_hides_details(self):
        with mock.patch.object(ocr_engine, "run_ocr", side_effect=RuntimeError("bí mật nội bộ")):
            r = self.post("/api/ocr", {}, "a.png", png_bytes())
        self.assertEqual(r.status_code, 500)
        self.assertNotIn("bí mật", r.get_data(as_text=True))

    def test_quality_endpoint(self):
        r = self.post("/api/quality", {}, "a.png", png_bytes())
        self.assertIn("level", r.get_json()["quality"])

    # ---- PDF không còn là đầu vào
    def test_pdf_input_is_rejected(self):
        for url in ("/api/ocr", "/api/quality"):
            r = self.post(url, {}, "a.pdf", b"%PDF-1.4 fake")
            self.assertEqual(r.status_code, 400, url)
            self.assertIn("ảnh", r.get_json()["message"])
        self.assertEqual(self.c.post("/api/pdf-info").status_code, 404)
        self.assertEqual(self.c.get("/api/pdf-preview").status_code, 404)
        self.run_ocr.assert_not_called()

    def test_ocr_defaults_to_one_row_per_image_line(self):
        self.post("/api/ocr", {}, "a.png", png_bytes())
        self.assertFalse(self.run_ocr.call_args.kwargs["reflow"])
        self.post("/api/ocr", {"reflow": "1"}, "b.png", png_bytes(text="khac"))
        self.assertTrue(self.run_ocr.call_args.kwargs["reflow"])

    # ---- xuất PDF
    def test_export_pdf(self):
        r = self.c.post("/api/export-pdf", json={"text": "=== Trang 1 ===\nXin chào Việt Nam\n\n=== Trang 2 ===\nỒ ạ & <b>"})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.data.startswith(b"%PDF"))
        self.assertIn("attachment", r.headers["Content-Disposition"])
        try:
            import pypdfium2 as pdfium
        except ImportError:
            pdfium = None
        if pdfium:
            pdf = pdfium.PdfDocument(r.data)
            self.assertEqual(len(pdf), 2)
            self.assertIn("Xin chào Việt Nam", pdf[0].get_textpage().get_text_range())
        self.assertEqual(self.c.post("/api/export-pdf", json={"text": "  "}).status_code, 400)
        with mock.patch.object(appmod, "MAX_EXPORT_CHARS", 5):
            self.assertEqual(self.c.post("/api/export-pdf", json={"text": "x" * 6}).status_code, 413)

    def test_export_pdf_falls_back_when_reportlab_fails(self):
        import pdf_export
        with mock.patch.object(pdf_export, "_build_reportlab", side_effect=ImportError("không có reportlab")):
            r = self.c.post("/api/export-pdf", json={"text": "Điều 32. Công tác thanh tra\n\n1. Hiệu trưởng"})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.data.startswith(b"%PDF"))

    # ---- AI
    def test_ai_disabled(self):
        with mock.patch.dict("os.environ", {}, clear=True):
            r = self.c.post("/api/ai-review", json={"lines": [{"i": 0, "text": "abc"}]})
        self.assertEqual(r.status_code, 503)


if __name__ == "__main__":
    unittest.main()
