"""Kiểm thử giao diện bằng Chromium (Playwright). Chạy: python tests/e2e_browser.py  (cần: pip install playwright)"""
import os
import subprocess
import sys
import tempfile
import time
import urllib.request

from playwright.sync_api import sync_playwright

import helpers

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = 5077
FIX = tempfile.mkdtemp(prefix="ocr_e2e_")  # dữ liệu mẫu tự tạo, không phụ thuộc file ngoài
for name, data in (("anh.png", helpers.png_bytes()), ("anh2.png", helpers.png_bytes(text="Anh khac")), ("tai-lieu.pdf", b"%PDF-1.4 fake"), ("so.pdf", helpers.pdf_bytes(2)), ("scan.pdf", helpers.pdf_bytes(2, scanned=True))):
    with open(os.path.join(FIX, name), "wb") as f:
        f.write(data)
URL = f"http://127.0.0.1:{PORT}"
results = []


def check(name, cond, extra=""):
    results.append(bool(cond))
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra and not cond else ""))


def start_server(port, ai=False):
    env = dict(os.environ, E2E_AI="on" if ai else "off")
    srv = subprocess.Popen([sys.executable, os.path.join(HERE, "e2e_server.py"), str(port)], env=env,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(50):
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=1)
            break
        except Exception:
            time.sleep(0.2)
    return srv


def feature_checks(p, ai):
    """Quality Score / Confidence / Accuracy tách bạch, AI chỉ đề xuất, OCR gốc không bị ghi đè."""
    port = PORT + (2 if ai else 1)
    srv = start_server(port, ai)
    try:
        b = p.chromium.launch()
        page = b.new_context(viewport={"width": 1200, "height": 900}).new_page()
        problems = []
        page.on("console", lambda m: problems.append(m.text) if m.type in ("error", "warning") else None)
        page.on("pageerror", lambda e: problems.append(str(e)))
        page.on("dialog", lambda d: d.accept())
        tag = "AI bật: " if ai else "AI tắt: "
        page.goto(f"http://127.0.0.1:{port}")
        page.set_input_files("#fileInput", f"{FIX}/anh.png")
        page.wait_for_selector("#imgQuality:not([hidden])")
        qt = page.inner_text("#imgQuality")
        check(tag + "hộp chất lượng đầu vào ghi rõ Quality Score + đề xuất", "Quality Score" in qt and "Đề xuất" in qt and "không phải độ chính xác" in qt, qt[:200])
        page.select_option("#enhanceMode", "off")
        check(tag + "đổi chế độ xử lý -> kế hoạch xử lý đổi theo", "giữ nguyên" in page.inner_text("#imgQuality"))
        page.select_option("#enhanceMode", "auto")
        page.click("#ocrBtn")
        page.wait_for_selector("#results:not([hidden])")
        tiles = page.inner_text("#summary")
        check(tag + "ba chỉ số tách bạch", all(k in tiles for k in ("Quality Score", "OCR Confidence", "Accuracy")), tiles[:300])
        check(tag + "chưa có Ground Truth -> Accuracy: Chưa đánh giá, không có số", "Chưa đánh giá" in page.inner_text(".tile:nth-child(3)") and "%" not in page.inner_text(".tile:nth-child(3) .tval"))
        check(tag + "không gọi confidence là Accuracy", "Accuracy" not in page.inner_text(".tile:nth-child(2) .tname"))
        check(tag + "ảnh gốc + ảnh sau xử lý + việc đã làm", page.is_visible("#resultImg") and page.is_visible("#processedImg") and "tương phản" in page.inner_text("#processedNotes"))
        original = page.input_value("#resultText")

        # Accuracy với Ground Truth
        page.click("#accuracyCard summary")
        page.fill("#gtText", "")
        page.click("#gtBtn")
        check(tag + "GT rỗng: vẫn 'Chưa đánh giá'", "Chưa đánh giá" in page.inner_text("#accStatus"))
        page.fill("#gtText", original)
        page.click("#gtBtn")
        page.wait_for_selector("#accStatus:has-text('CER')")
        check(tag + "GT giống hệt: Accuracy 100%, CER 0%", "Accuracy: 100% · CER: 0% · WER: 0%" in page.inner_text("#accStatus"), page.inner_text("#accStatus"))
        page.fill("#gtText", original.replace("Dòng cuối", "Dong cuoi"))
        page.click("#gtBtn")
        page.wait_for_selector("#accStatus:not(:has-text('CER: 0%'))")
        check(tag + "GT khác: CER > 0", "CER: 0%" not in page.inner_text("#accStatus"), page.inner_text("#accStatus"))
        page.click("#gtClear")
        check(tag + "xóa GT -> quay về Chưa đánh giá", "Chưa đánh giá" in page.inner_text("#accStatus"))

        # AI review
        page.click("#aiBtn")
        page.wait_for_selector("#aiPanel:not([hidden])")
        panel = page.inner_text("#aiPanel")
        if not ai:
            check(tag + "báo AI không khả dụng, OCR giữ nguyên", "AI kiểm tra hiện không khả dụng. Kết quả OCR vẫn được giữ nguyên." in panel, panel[:200])
            check(tag + "vẫn liệt kê dòng cần kiểm tra cục bộ", "Cần kiểm tra" in panel)
            check(tag + "nội dung không đổi", page.input_value("#resultText") == original)
        else:
            check(tag + "hiện số vị trí nghi sai + nút Áp dụng/Giữ nguyên", "Phát hiện 2 vị trí" in panel and "Áp dụng chỉnh sửa" in panel and "Giữ nguyên" in panel, panel[:300])
            check(tag + "CHƯA có gì bị thay đổi khi AI chỉ đề xuất", page.input_value("#resultText") == original)
            check(tag + "cảnh báo bằng chứng yếu", "Bằng chứng yếu" in panel)
            check(tag + "xem được dữ liệu gửi AI + đề xuất bị loại", page.locator("#aiPanel details.io").count() == 1)
            btn_all = page.locator("#aiPanel .acts button", has_text="Áp dụng tất cả")
            check(tag + "'Áp dụng tất cả' bỏ qua đề xuất bằng chứng yếu (chỉ 1/2)", "(1)" in btn_all.inner_text(), btn_all.inner_text())
            page.locator("#aiPanel .chg", has_text="Dòng cuối").locator("button", has_text="Áp dụng chỉnh sửa").click()
            after = page.input_value("#resultText")
            check(tag + "bấm Áp dụng -> chỉ đúng dòng đó đổi", "Dòng cuối cùng" in after and "Dòng chắc chắn.\n" not in after and "Dòng chắc chắn\n" in after, after)
            check(tag + "có huy hiệu 'Đã chỉnh sửa'", page.is_visible("#editedBadge"))
            page.locator("#aiPanel .chg", has_text="Dòng chắc chắn").locator("button", has_text="Giữ nguyên").click()
            check(tag + "Giữ nguyên -> văn bản không đổi thêm", page.input_value("#resultText") == after)
            page.click("#restoreBtn")
            check(tag + "Khôi phục kết quả OCR gốc vẫn hoạt động", page.input_value("#resultText") == original)
        real = [m for m in problems if "favicon" not in m.lower() and "503" not in m and "502" not in m]
        check(tag + "không lỗi console", not real, "; ".join(real)[:300])
        b.close()
    finally:
        srv.terminate()


def main():
    srv = subprocess.Popen([sys.executable, os.path.join(HERE, "e2e_server.py"), str(PORT)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(50):
            try:
                urllib.request.urlopen(URL + "/api/health", timeout=1); break
            except Exception:
                time.sleep(0.2)
        with sync_playwright() as p:
            b = p.chromium.launch()
            ctx = b.new_context(viewport={"width": 1200, "height": 900})
            page = ctx.new_page()
            problems = []
            page.on("console", lambda m: problems.append(m.text) if m.type in ("error", "warning") else None)
            page.on("pageerror", lambda e: problems.append(str(e)))
            page.goto(URL)

            # 1) ảnh
            page.set_input_files("#fileInput", f"{FIX}/anh.png")
            page.wait_for_selector("#imgQuality:not([hidden])")
            check("ảnh: hiện đánh giá chất lượng", True)
            check("không còn tuỳ chọn/ô liên quan PDF đầu vào (vẫn giữ nút lấy Ground Truth từ PDF)", page.locator("#textLayerRow, #pager").count() == 0 and page.locator("#gtPdf").count() == 1)
            check("ô chọn file chỉ nhận ảnh", "pdf" not in (page.get_attribute("#fileInput", "accept") or ""))
            check("ảnh: tuỳ chọn nối dòng có nhưng TẮT mặc định (đúng từng dòng như ảnh)", page.is_visible("#reflowText") and not page.is_checked("#reflowText"))
            page.click("#ocrBtn")
            check("ảnh: nút Dừng hiện khi đang chạy", page.is_visible("#cancelBtn"))
            check("ảnh: tuỳ chọn nối dòng bị khoá khi đang chạy", page.is_disabled("#reflowText"))
            page.wait_for_selector("#results:not([hidden])")
            check("ảnh: có kết quả", "Dòng chắc chắn" in page.input_value("#resultText"))
            check("ảnh: nút Dừng ẩn sau khi xong", page.is_hidden("#cancelBtn"))

            # 2) bấm dòng trùng nội dung -> chọn đúng lần xuất hiện thứ 2
            rows = page.locator(".lrow")
            rows.nth(2).click()  # "Dòng trùng" lần 2
            sel = page.evaluate("(() => { const t = document.getElementById('resultText'); return [t.selectionStart, t.selectionEnd]; })()")
            full = page.input_value("#resultText")
            check("dòng trùng: chọn đúng lần thứ 2", sel[0] == full.rfind("Dòng trùng"), str(sel))

            # 3) Xuất PDF: phải tải được file PDF thật
            with page.expect_download(timeout=15000) as dl:
                page.click("#pdfBtn")
            path = dl.value.path()
            head = open(path, "rb").read(5)
            check("xuất PDF: tải được file .pdf hợp lệ", dl.value.suggested_filename.endswith(".pdf") and head == b"%PDF-", f"{dl.value.suggested_filename} {head!r}")
            check("xuất PDF: nút trở lại bình thường", page.is_enabled("#pdfBtn") and "Xuất PDF" in page.inner_text("#pdfBtn"))

            # 3b) Ground Truth từ PDF: PDF số được nhận, PDF scan bị từ chối
            page.click("#accuracyCard summary")
            page.set_input_files("#gtPdf", f"{FIX}/so.pdf")
            page.wait_for_selector("#alert.success")
            gt = page.input_value("#gtText")
            check("GT từ PDF số: điền vào ô Ground Truth", "Cộng hòa xã hội chủ nghĩa Việt Nam 2" in gt and "=== Trang 2 ===" in gt, gt[:80])
            page.set_input_files("#gtPdf", f"{FIX}/scan.pdf")
            page.wait_for_selector("#alert.error")
            check("GT từ PDF scan: bị từ chối, ô GT không đổi", "không có lớp chữ đáng tin" in page.inner_text("#alert") and page.input_value("#gtText") == gt)

            # 4) PDF không còn là đầu vào: bị từ chối ngay trên giao diện
            page.click("#removeBtn")
            page.set_input_files("#fileInput", f"{FIX}/tai-lieu.pdf")
            check("PDF đầu vào: bị từ chối, báo lỗi", page.is_visible("#alert") and "không nhận PDF" in page.inner_text("#alert"), page.inner_text("#alert"))
            check("PDF đầu vào: không hiện khung xem trước", page.is_hidden("#preview"))

            # 4b) Dừng giữa chừng khi đang nhận diện ảnh
            page.set_input_files("#fileInput", f"{FIX}/anh2.png")   # ảnh khác để không trúng bộ nhớ đệm (kết quả tức thì)
            page.wait_for_selector("#imgQuality:not([hidden])")
            page.click("#ocrBtn")
            page.click("#cancelBtn")
            page.wait_for_selector("#status:has-text('Đã dừng')", timeout=15000)
            check("dừng: báo đã dừng, nút OCR dùng lại được", page.is_enabled("#ocrBtn"))

            # 5) dán ảnh từ clipboard
            page.click("#removeBtn")
            page.evaluate("""async () => {
              const c = document.createElement('canvas'); c.width = 300; c.height = 200;
              c.getContext('2d').fillRect(10, 10, 100, 50);
              const blob = await new Promise(r => c.toBlob(r, 'image/png'));
              const dt = new DataTransfer(); dt.items.add(new File([blob], 'image.png', {type: 'image/png'}));
              window.dispatchEvent(new ClipboardEvent('paste', {clipboardData: dt, bubbles: true, cancelable: true}));
            }""")
            page.wait_for_selector("#previewImg:not([hidden])", timeout=5000)
            check("dán ảnh: hiện xem trước", "anh-dan-" in page.inner_text("#fileName"))

            # 6) file sai loại
            page.click("#removeBtn")
            open(f"{FIX}/bad.txt", "w").write("x")
            page.set_input_files("#fileInput", f"{FIX}/bad.txt")
            check("file sai loại: báo lỗi", page.is_visible("#alert"))

            real = [m for m in problems if "favicon" not in m.lower() and "422" not in m]   # 422 = PDF scan bị từ chối làm Ground Truth (đúng thiết kế)
            check("không có lỗi/cảnh báo console (kể cả CSP)", not real, "; ".join(real)[:300])
            b.close()
            feature_checks(p, ai=False)
            feature_checks(p, ai=True)
    finally:
        srv.terminate()
    print(f"\n{sum(results)}/{len(results)} đạt")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
