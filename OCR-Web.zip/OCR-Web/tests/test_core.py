import unittest
from unittest import mock

import cv2
import numpy as np

import helpers  # noqa: F401  (thêm thư mục gốc vào sys.path)
import ai_review
import ocr_engine
import preprocess
import vi_check


class ViCheckTests(unittest.TestCase):
    def test_valid_vietnamese(self):
        text = "Cộng hòa xã hội chủ nghĩa Việt Nam, Độc lập - Tự do - Hạnh phúc, nghiêng ngả, quyền, nguyễn, thuở, khuya"
        bad, checked = vi_check.check_line(text)
        self.assertEqual(bad, [])
        self.assertGreater(checked, 10)

    def test_detects_impossible_syllables(self):
        bad, _ = vi_check.check_line("Việt Namm hôm nay trơi đẹpp xzqt")
        for w in ("Namm", "đẹpp"):
            self.assertIn(w, bad)

    def test_ignores_numbers_abbreviations_and_caps(self):
        bad, _ = vi_check.check_line("TP. HCM 12/03/2026 UBND kg 0912345678 a@b.vn")
        self.assertEqual(bad, [])

    def test_tone_rules_for_stop_finals(self):
        self.assertTrue(vi_check.valid_syllable("việc"))
        self.assertFalse(vi_check.valid_syllable("viêc"))  # -c chỉ nhận sắc/nặng


class GeometryTests(unittest.TestCase):
    def test_order_points_and_size(self):
        b = preprocess.order_points([[100, 50], [0, 50], [0, 0], [100, 0]])
        self.assertEqual(b.tolist(), [[0, 0], [100, 0], [100, 50], [0, 50]])
        self.assertEqual(preprocess.box_size(b), (100.0, 50.0))

    def test_skew_estimation_sign_and_robustness(self):
        def box(angle, x=0, y=0, w=300, h=30):
            a = np.radians(angle)
            dx, dy = np.cos(a) * w, np.sin(a) * w
            return np.array([[x, y], [x + dx, y + dy], [x + dx, y + dy + h], [x, y + h]], np.float32)
        boxes = [box(3.0, y=i * 40) for i in range(6)] + [box(-30, y=500)]  # 1 hộp sai không làm lệch kết quả
        self.assertAlmostEqual(preprocess.estimate_skew(boxes), 3.0, delta=0.2)
        self.assertIsNone(preprocess.estimate_skew(boxes[:2]))

    def test_rotate_free_keeps_content(self):
        arr = np.full((100, 300, 3), 255, np.uint8)
        out = preprocess.rotate_free(arr, 10)
        self.assertGreater(out.shape[0], 100)

    def test_find_document_on_photo_of_paper(self):
        rng = np.random.default_rng(0)
        bg = np.full((900, 1200, 3), 60, np.uint8)
        bg += rng.integers(0, 8, bg.shape, dtype=np.uint8)
        paper = np.array([[220, 120], [980, 160], [940, 800], [180, 760]], np.int32)
        cv2.fillConvexPoly(bg, paper, (235, 235, 230))
        for i in range(14):  # vài dòng "chữ" trên giấy
            y = 220 + i * 36
            cv2.line(bg, (260, y), (880, y + 4), (30, 30, 30), 5)
        quad = preprocess.find_document(bg)
        self.assertIsNotNone(quad)
        self.assertEqual(preprocess.warp_document(bg, quad).ndim, 3)

    def test_find_document_does_not_crop_full_page_text(self):
        page = np.full((1000, 800, 3), 245, np.uint8)
        for i in range(30):
            cv2.line(page, (60, 60 + i * 30), (740, 60 + i * 30), (20, 20, 20), 4)
        self.assertIsNone(preprocess.find_document(page))


class EngineLogicTests(unittest.TestCase):
    @staticmethod
    def rect(x0, y0, x1, y1):
        return np.array([[x0, y0], [x1, y0], [x1, y1], [x0, y1]], np.float32)

    def test_group_rows_reading_order_and_merging(self):
        boxes = [self.rect(300, 100, 380, 130),   # 0: cùng hàng, sát hộp 1 -> gộp
                 self.rect(100, 102, 290, 132),   # 1
                 self.rect(100, 200, 400, 230),   # 2: hàng dưới
                 self.rect(900, 101, 1000, 131)]  # 3: cùng hàng nhưng rất xa (cột khác) -> dòng riêng
        groups = ocr_engine.group_rows(boxes)
        self.assertEqual(groups, [[1, 0], [3], [2]])

    def test_segments_split_long_line_at_gaps(self):
        h, w = 32, 2000  # tỉ lệ ~62:1, vượt MAX_ASPECT
        crop = np.full((h, w, 3), 255, np.uint8)
        for x in range(0, w - 60, 90):  # "từ" rộng 60px cách nhau 30px
            crop[6:26, x:x + 60] = 0
        segs = ocr_engine._segments(crop)
        self.assertGreater(len(segs), 1)
        for s in segs:
            self.assertLessEqual(s.shape[1], ocr_engine.MAX_ASPECT * h + 1)
        # không làm mất cột mực nào: tổng chiều rộng khớp ảnh gốc
        self.assertEqual(sum(s.shape[1] for s in segs), w)

    def test_normalize_inverts_light_on_dark(self):
        crop = np.full((40, 200, 3), 20, np.uint8)
        crop[10:30, 20:180] = 240
        out = ocr_engine._normalize_crop(crop)
        self.assertGreater(out[2, 2].mean(), 200)  # nền đã thành sáng

    def test_conf_and_level(self):
        self.assertIsNone(ocr_engine._conf(float("nan")))
        self.assertEqual(ocr_engine._conf(1.7), 1.0)
        self.assertEqual(ocr_engine._level(0.95, 0), "green")
        self.assertEqual(ocr_engine._level(0.80, 0), "yellow")
        self.assertEqual(ocr_engine._level(0.60, 0), "red")
        self.assertEqual(ocr_engine._level(0.99, 0.5), "red")

    def test_module_imports_without_heavy_deps(self):
        with mock.patch.dict("sys.modules", {"paddleocr": None, "vietocr": None}):
            with ocr_engine._models_lock:
                saved, ocr_engine._models = ocr_engine._models, None
            try:
                with self.assertRaises(RuntimeError) as cm:
                    ocr_engine.load_models()
                self.assertIn("requirements.txt", str(cm.exception))
            finally:
                ocr_engine._models = saved


class AiReviewTests(unittest.TestCase):
    def test_parse_truncated_json_is_rescued(self):
        cut = '{"changes":[{"i":1,"text":"Hà Nội","reason":"dấu"},{"i":2,"text":"Việt N'
        out = ai_review._parse(cut)
        self.assertEqual([c["i"] for c in out["changes"]], [1])
        self.assertIsNone(ai_review._parse("không phải json"))
        self.assertEqual(ai_review._parse('```json\n{"changes":[],"warnings":[]}\n```'), {"changes": [], "warnings": []})

    def test_review_filters_unsafe_changes(self):
        lines = [{"i": 0, "text": "Ha Noi, ngay 12 thang 3", "conf": 70},
                 {"i": 1, "text": "Tong tien: 1.500.000 dong", "conf": 80},
                 {"i": 2, "text": "Xin chao", "conf": 90}]
        reply = ('{"changes":[{"i":0,"text":"Hà Nội, ngày 12 tháng 3","reason":"dấu"},'
                 '{"i":1,"text":"Tổng tiền: 1.600.000 đồng","reason":"x"},'
                 '{"i":2,"text":"Một câu hoàn toàn khác và dài hơn nhiều so với bản gốc ban đầu","reason":"viết lại"},'
                 '{"i":99,"text":"ngoài phạm vi","reason":"x"}],"warnings":[{"i":1,"msg":"nghi số"}]}')
        with mock.patch.dict("os.environ", {"GEMINI_API_KEY": "k"}), \
                mock.patch.object(ai_review, "_call", return_value=(reply, "STOP", "m")):
            out = ai_review.review(lines)
        by = {c["i"]: c for c in out["changes"]}
        self.assertEqual(sorted(by), [0, 1])         # dòng 2 (viết lại) và 99 (ngoài phạm vi) bị loại
        self.assertFalse(by[0]["risky"])
        self.assertTrue(by[1]["risky"])              # đổi số liệu -> đánh dấu rủi ro
        self.assertEqual(out["warnings"][0]["i"], 1)

    def test_retry_gives_up_on_daily_quota(self):
        calls = []

        def fn():
            calls.append(1)
            raise ai_review._ApiError(429, "quota per day exceeded", body="per day")
        with self.assertRaises(ai_review._ApiError):
            ai_review._with_retries(fn, deadline=1e12)
        self.assertEqual(len(calls), 1)


if __name__ == "__main__":
    unittest.main()


class QualityTests(unittest.TestCase):
    @staticmethod
    def page(n_lines, blur=0.0, bg=255, ink=15, size=(1000, 1400)):
        from PIL import Image, ImageDraw, ImageFont, ImageFilter
        im = Image.new("L", size, bg)
        d = ImageDraw.Draw(im)
        f = ImageFont.truetype(helpers.os.path.join(helpers.ROOT, "fonts", "DejaVuSans.ttf"), 26)
        for i in range(n_lines):
            d.text((80, 80 + i * 40), "Cộng hòa xã hội chủ nghĩa Việt Nam, độc lập tự do", font=f, fill=ink)
        if blur:
            im = im.filter(ImageFilter.GaussianBlur(blur))
        return im.convert("RGB")

    def test_sparse_clean_page_is_not_penalised(self):
        import quality
        self.assertEqual(quality.assess(self.page(3), check_resolution=False)["level"], "green")

    def test_dense_clean_page_is_green(self):
        import quality
        self.assertEqual(quality.assess(self.page(30), check_resolution=False)["level"], "green")

    def test_blurry_page_is_flagged(self):
        import quality
        q = quality.assess(self.page(30, blur=2.5), check_resolution=False)
        self.assertIn("Độ nét", [i["label"] for i in q["issues"]])

    def test_blank_and_dark_and_faint_are_flagged(self):
        import quality
        labels = lambda im: {i["label"] for i in quality.assess(im, check_resolution=False)["issues"]}
        self.assertIn("Độ sáng", labels(self.page(0)))                      # trang trắng trống
        self.assertIn("Độ sáng", labels(self.page(20, bg=40, ink=90)))      # ảnh tối
        self.assertIn("Độ tương phản", labels(self.page(20, bg=255, ink=225)))  # chữ rất nhạt
