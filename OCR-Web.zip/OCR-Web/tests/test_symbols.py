"""Nhận lại ký hiệu so sánh < > = <= >= (symbols.py) và gắn vào ocr_engine.recover_symbols. Không cần model thật."""
import os
import unittest

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

import helpers
from helpers import ROOT

import ocr_engine
import symbols

FONT = os.path.join(ROOT, "fonts", "DejaVuSans.ttf")   # font kèm dự án -> test chạy giống nhau trên mọi máy


def render(text, px=30, blur=0.8, noise=3.0, rot=0.0):
    big = 4
    font = ImageFont.truetype(FONT, px * big)
    w = int(font.getlength(text)) + 40 * big
    im = Image.new("L", (w, int(px * big * 1.9)), 235)
    ImageDraw.Draw(im).text((20 * big, int(px * big * 0.35)), text, font=font, fill=40)
    a = np.array(im.resize((w // big, im.height // big), Image.LANCZOS)).astype(np.float32)
    if rot:
        M = cv2.getRotationMatrix2D((a.shape[1] / 2, a.shape[0] / 2), rot, 1)
        a = cv2.warpAffine(a, M, (a.shape[1], a.shape[0]), borderValue=235)
    a = cv2.GaussianBlur(a, (0, 0), blur) + np.random.RandomState(1).normal(0, noise, a.shape)
    return cv2.cvtColor(np.clip(a, 0, 255).astype(np.uint8), cv2.COLOR_GRAY2RGB)


class FakePredictor:
    """Giả lập VietOCR: chia đều các từ cho các đoạn ảnh được đưa vào."""
    def __init__(self, text):
        self.words = text.split()
        self.config = {"predictor": {"beamsearch": False}}

    def predict_batch(self, imgs, return_prob=False):
        k, n = len(imgs), len(self.words)
        cuts = [round(i * n / k) for i in range(k + 1)]
        texts = [" ".join(self.words[cuts[i]:cuts[i + 1]]) for i in range(k)]
        return (texts, [0.97] * k) if return_prob else texts


def ops_of(img):
    return [b["op"] for b in symbols.analyze(img)[1]]


class DetectTests(unittest.TestCase):
    def test_finds_each_operator(self):
        self.assertEqual(ops_of(render("- Nhập một dãy n (0 < n < 100) số nguyên")), ["<", "<"])
        self.assertEqual(ops_of(render("vị trí p (0 <= p <= n) của danh sách")), ["<=", "<="])
        self.assertEqual(ops_of(render("Cho a > b và c >= d thì x = 5 với mọi k")), [">", ">=", "="])

    def test_robust_to_tilt_and_blur(self):
        for rot in (-1.5, 0, 1.2):
            self.assertEqual(ops_of(render("(0 <= p <= n) và m > 0", px=28, blur=0.9, rot=rot)), ["<=", "<=", ">"], rot)

    def test_ordinary_text_has_no_false_operators(self):
        for line in ("Sử dụng kiểu dữ liệu mảng để cài đặt danh sách tuyến tính. Viết các",
                     "z s e a c x v u o r ~ - _ . , : ; ! ? * + / | ( ) [ ] 2 3 5 6 8 9 4 S 1 l i",
                     "Câu I (6,0 điểm) i-1, x/y, a+b, 2*3, [1..n] — ĐÁP SỐ 45"):
            self.assertEqual(ops_of(render(line)), [], line)

    def test_erase_removes_only_the_operators(self):
        img = render("(0 < n < 100) số")
        blobs, ops = symbols.analyze(img)
        er = symbols.erase(img, blobs)
        self.assertEqual(ops_of(er), [])
        for b in ops:                                   # vùng ký hiệu đã trống
            self.assertGreater(er[:, b["x0"]:b["x1"]].min(), 200)
        words = [b for b in blobs if not b["op"]]
        w = words[0]                                    # chữ khác vẫn còn nguyên
        self.assertTrue((er[:, w["x0"]:w["x1"]] == img[:, w["x0"]:w["x1"]]).all())


class SpliceTests(unittest.TestCase):
    def blobs(self, kinds):
        out, x = [], 0
        for k in kinds:
            out.append({"x0": x, "x1": x + 20, "y0": 0, "y1": 10, "op": k if k in symbols.OPS else None})
            x += 30
        return out

    def test_exact_when_word_counts_match(self):
        b = self.blobs(["w", "w", "<", "w", "<=", "w"])
        self.assertEqual(symbols.splice("a b c d", b), "a b < c <= d")
        self.assertEqual(symbols.splice("dãy (0 n 100) so", self.blobs(["w", "w", "<", "w", "<=", "w", "w"])), "dãy (0 < n <= 100) so")

    def test_trailing_and_leading_operator(self):
        self.assertEqual(symbols.splice("a b", self.blobs(["w", "w", ">="])), "a b >=")
        self.assertEqual(symbols.splice("a b", self.blobs(["=", "w", "w"])), "= a b")

    def test_estimates_by_proportion_when_counts_differ(self):
        # OCR dính hai từ "(0n" -> chỉ còn 3 từ cho 4 cụm; ký hiệu vẫn phải nằm giữa các từ, không chen vào giữa chữ
        out = symbols.splice("dãy (0n 100) so", self.blobs(["w", "w", "w", "<", "w", "w"]))
        self.assertIn("<", out.split())
        self.assertEqual(out.replace(" < ", " ").split(), ["dãy", "(0n", "100)", "so"])

    def test_no_operator_means_text_untouched(self):
        self.assertEqual(symbols.splice("a  b", self.blobs(["w", "w"])), "a  b")


class RecoverTests(unittest.TestCase):
    def run_line(self, text, wrong, read):
        img = render(text, px=30)
        h, w = img.shape[:2]
        box = np.array([[6, 6], [w - 6, 6], [w - 6, h - 6], [6, h - 6]], dtype=np.float32)   # crop_by_polygon tự nới thêm 6px
        return ocr_engine.recover_symbols(img, [box], [(wrong, 0.8, False)], FakePredictor(read))

    def test_fixes_misread_operators(self):
        new, n = self.run_line("- Nhập một dãy n (0 < n < 100) số nguyên", "- Nhập một dãy n (0 Sn 5 100) số nguyên", "- Nhập một dãy n (0 n 100) số nguyên")
        self.assertEqual(n, 2)
        self.assertEqual(new[0][0], "- Nhập một dãy n (0 < n < 100) số nguyên")
        self.assertTrue(new[0][2])                       # đánh dấu là đã đọc lại

    def test_fixes_le_ge(self):
        new, n = self.run_line("vị trí p (0 <= p <= n) của danh sách", "vị trí p (0 ? p 4 n) của danh sách", "vị trí p (0 p n) của danh sách")
        self.assertEqual((n, new[0][0]), (2, "vị trí p (0 <= p <= n) của danh sách"))

    def test_lines_without_operators_are_untouched(self):
        new, n = self.run_line("Sử dụng kiểu dữ liệu mảng để cài đặt danh sách", "Sử dụng kiểu dữ liệu", "KHÁC")
        self.assertEqual((n, new[0][0]), (0, "Sử dụng kiểu dữ liệu"))

    def test_failure_keeps_original_reading(self):
        class Boom(FakePredictor):
            def predict_batch(self, *a, **k):
                raise RuntimeError("lỗi model")
        img = render("(0 < n < 100) số nguyên từ bàn phím")
        h, w = img.shape[:2]
        box = np.array([[6, 6], [w - 6, 6], [w - 6, h - 6], [6, h - 6]], dtype=np.float32)
        new, n = ocr_engine.recover_symbols(img, [box], [("gốc", 0.8, False)], Boom("x"))
        self.assertEqual((n, new[0][0]), (0, "gốc"))


class MismatchTests(unittest.TestCase):
    """Model đọc dính/tách từ nên số từ không khớp số cụm chữ -> phải đọc riêng từng đoạn, ký hiệu không được dồn về một chỗ."""

    def test_pieces_split_around_operators(self):
        img = render("(0 < n < 100) số")
        blobs, ops = symbols.analyze(img)
        kinds = [k for k, _ in symbols.pieces(img, blobs)]
        self.assertEqual([k for k in kinds if k == "op"], ["op", "op"])
        self.assertEqual(kinds[0], "text")
        self.assertEqual(kinds[1], "op")

    def test_word_count_mismatch_uses_pieces(self):
        class PerPiece(FakePredictor):
            def predict_batch(self, imgs, return_prob=False):
                texts = ["(0", "n", "100) số"][:len(imgs)] if len(imgs) == 3 else ["?"] * len(imgs)
                return (texts, [0.97] * len(imgs)) if return_prob else texts
        img = render("(0 < n < 100) số")
        h, w = img.shape[:2]
        box = np.array([[6, 6], [w - 6, 6], [w - 6, h - 6], [6, h - 6]], dtype=np.float32)
        calls = {"n": 0}
        pred = PerPiece("x")
        orig = pred.predict_batch
        def spy(imgs, return_prob=False):
            calls["n"] += 1
            if calls["n"] == 1:      # lần đọc cả dòng: trả về 1 từ dính -> lệch số từ
                return (["(0n100)số"], [0.97]) if return_prob else ["(0n100)số"]
            return (["(0"] , [0.97]) if return_prob else ["(0"]
        pred.predict_batch = spy
        new, n = ocr_engine.recover_symbols(img, [box], [("gốc", 0.8, False)], pred)
        self.assertEqual(n, 2)
        self.assertEqual(new[0][0].split().count("<"), 2)
        self.assertNotIn("< <", new[0][0])           # hai ký hiệu không được dính liền nhau


class SentenceCaseTests(unittest.TestCase):
    def test_capitalizes_after_period(self):
        self.assertEqual(ocr_engine.fix_sentence_case("danh sách tuyến tính. viết các hàm"), "danh sách tuyến tính. Viết các hàm")

    def test_leaves_numbers_abbreviations_and_decimals(self):
        for s in ("p.n) của", "1. nhập n", "vd. abc", "giá trị 3.5 và x", "v.v. và"):
            self.assertEqual(ocr_engine.fix_sentence_case(s), s)


if __name__ == "__main__":
    unittest.main()
