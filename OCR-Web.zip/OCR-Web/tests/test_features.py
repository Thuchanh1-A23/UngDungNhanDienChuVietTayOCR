import io
import unittest
from unittest import mock

import numpy as np
import cv2
from PIL import Image

import helpers
from helpers import png_bytes, fake_result

import ai_review
import app as appmod
import input_advisor
import ocr_engine
import quality
from test_core import QualityTests

page = QualityTests.page


def codes(img, res=False):
    return {i["code"] for i in quality.assess(img, check_resolution=res)["issues"]}


class QualityIssueTests(unittest.TestCase):
    def test_clean_pages_not_flagged(self):
        self.assertEqual(codes(page(30)), set())
        self.assertEqual(codes(page(3)), set())

    def test_noise_uneven_shadow_skew(self):
        base = page(30)
        a = np.array(base).astype(np.float32)
        rng = np.random.default_rng(0)
        self.assertIn("noise", codes(Image.fromarray(np.clip(a + rng.normal(0, 22, a.shape), 0, 255).astype(np.uint8))))
        h, w = a.shape[:2]
        grad = np.linspace(0.45, 1.0, w, dtype=np.float32)[None, :, None]
        self.assertTrue(codes(Image.fromarray((a * grad).astype(np.uint8))) & {"uneven", "shadow"})
        m = np.ones((h, w), np.float32)
        m[:, :w // 3] = 0.5
        m = cv2.GaussianBlur(m, (0, 0), 12)
        self.assertIn("shadow", codes(Image.fromarray((a * m[..., None]).astype(np.uint8))))
        rot = cv2.warpAffine(np.array(base), cv2.getRotationMatrix2D((w / 2, h / 2), 8, 1.0), (w, h), borderValue=(255, 255, 255))
        q = quality.assess(Image.fromarray(rot), check_resolution=False)
        self.assertIn("skew", {i["code"] for i in q["issues"]})
        self.assertAlmostEqual(abs(q["metrics"]["skew"]), 8, delta=1.0)

    def test_every_issue_has_code_and_suggestion(self):
        q = quality.assess(page(20, bg=40, ink=90), check_resolution=False)
        for i in q["issues"]:
            self.assertTrue(i["code"] and i["suggestion"] and i["label"] and i["message"])

    def test_add_issue_recomputes_score_and_level(self):
        q = quality.assess(page(30), check_resolution=False)
        q2 = quality.add_issue(q, quality.RED, "no_text", "Vùng văn bản", "x", "y")
        self.assertEqual((q["level"], q2["level"]), ("green", "red"))
        self.assertEqual(q2["score"], 65)
        self.assertEqual(len(q["issues"]), 0)   # không sửa đối tượng cũ


class AdvisorTests(unittest.TestCase):
    def test_green_has_no_risk_and_no_plan(self):
        a = input_advisor.build(quality.assess(page(30), check_resolution=False), check_resolution=False)
        self.assertEqual((a["level"], a["risk"], a["plan"]), ("green", False, []))
        self.assertIn("tốt", a["summary"])

    def test_low_contrast_yellow_message_and_suggestion(self):
        q = quality.assess(page(20, bg=255, ink=225), check_resolution=False)
        a = input_advisor.build(q, check_resolution=False)
        self.assertTrue(a["risk"])
        self.assertIn("tương phản", a["summary"])
        self.assertTrue(any("tăng tương phản" in s for s in a["suggestions"]))
        self.assertIn("clahe", [p["code"] for p in a["plan"]])

    def test_plan_respects_enhance_mode(self):
        q = quality.assess(page(20, bg=255, ink=225), check_resolution=False)
        off = input_advisor.build(q, enhance="off", check_resolution=False)
        self.assertEqual(off["plan"], [])
        strong = input_advisor.build(q, enhance="strong", check_resolution=False)
        self.assertIn("binarize", [p["code"] for p in strong["plan"]])

    def test_engine_added_issues(self):
        q = quality.assess(page(30), check_resolution=False)
        small = input_advisor.text_size_issue(q, 8)
        self.assertEqual(small["level"], "red")
        self.assertIs(input_advisor.text_size_issue(q, 30), q)
        nt = input_advisor.build(input_advisor.no_text_issue(q), check_resolution=False)
        self.assertIn("vùng văn bản", nt["summary"])
        self.assertTrue(nt["recapture"])
        self.assertIsNone(input_advisor.build(None))


class AiGuardTests(unittest.TestCase):
    def test_risk_reasons(self):
        self.assertEqual(ai_review.risk_reasons("Ha Noi ngay 12", "Hà Nội ngày 12"), [])          # chỉ sửa dấu
        self.assertTrue(ai_review.risk_reasons("Ma SV 21520123", "Mã SV 21520124"))               # đổi số
        self.assertTrue(ai_review.risk_reasons("a@uit.edu.vn", "a@uit.edu.com"))                  # email
        self.assertTrue(ai_review.risk_reasons("Khoa UBND", "Khoa UBNB"))                         # viết tắt
        self.assertTrue(ai_review.risk_reasons("Sinh vien Nguyen Van Hang", "Sinh viên Nguyễn Văn Hung"))  # đổi chữ cái trong tên

    def test_evidence_confidence_is_only_a_hint(self):
        self.assertTrue(ai_review.evidence("Trương đai hoc", 71))
        self.assertEqual(ai_review.evidence("Tổng cộng thanh toán", 97), [])   # tin cậy cao, không từ vô lý -> bằng chứng yếu
        self.assertTrue(ai_review.evidence("Tổng cộng", None))

    def test_word_edits(self):
        e = ai_review.word_edits("Trương đai hoc Công", "Trường Đại học Công")
        self.assertEqual([(x["from"], x["to"]) for x in e], [("Trương", "Trường"), ("đai", "Đại"), ("hoc", "học")])

    def test_review_output_fields_and_rejections(self):
        lines = [{"i": 0, "text": "Trương đai hoc Công Nghê Thông Tin", "conf": 71},
                 {"i": 1, "text": "Ma SV: 21520123", "conf": 80},
                 {"i": 2, "text": "Tổng cộng thanh toán", "conf": 97},
                 {"i": 3, "text": "Xin chao", "conf": 90}]
        reply = ('{"changes":[{"i":0,"text":"Trường Đại học Công nghệ Thông tin","reason":"dấu"},'
                 '{"i":1,"text":"Mã SV: 21520124","reason":"x"},'
                 '{"i":2,"text":"Tổng cộng thanh toán.","reason":"x"},'
                 '{"i":3,"text":"Một câu hoàn toàn khác và dài hơn nhiều so với bản gốc ban đầu","reason":"viết lại"}],"warnings":[]}')
        with mock.patch.dict("os.environ", {"GEMINI_API_KEY": "k"}), mock.patch.object(ai_review, "_call", return_value=(reply, "STOP", "m")):
            out = ai_review.review(lines)
        by = {c["i"]: c for c in out["changes"]}
        self.assertFalse(by[0]["risky"] or by[0]["weak"])
        self.assertTrue(by[1]["risky"])          # đổi mã sinh viên
        self.assertTrue(by[2]["weak"])           # dòng tin cậy cao, không bằng chứng
        self.assertNotIn(3, by)                  # viết lại -> bị loại...
        self.assertEqual([r["i"] for r in out["rejected"]], [3])   # ...và ghi lại để người dùng thấy
        self.assertEqual(out["sent"], 4)
        self.assertEqual(lines[0]["text"], "Trương đai hoc Công Nghê Thông Tin")  # đầu vào không bị sửa

    def test_debug_log_off_by_default(self):
        with mock.patch.dict("os.environ", {}, clear=True), mock.patch("builtins.open") as op:
            ai_review._debug("x", {"a": 1})
        op.assert_not_called()


class AppFeatureTests(unittest.TestCase):
    def setUp(self):
        appmod.app.config["TESTING"] = True
        self.c = appmod.app.test_client()
        appmod._cache.clear()
        self.addCleanup(mock.patch.stopall)

    def test_quality_endpoint_returns_advice_and_scores(self):
        r = self.c.post("/api/quality", data={"file": (io.BytesIO(png_bytes()), "a.png")}, content_type="multipart/form-data").get_json()
        self.assertIn("score", r["quality"])
        self.assertIn("summary", r["advice"])
        self.assertIn("plan", r["advice"])

    def test_accuracy_endpoint(self):
        ok = self.c.post("/api/accuracy", json={"hypothesis": "Viet Nam", "reference": "Việt Nam"}).get_json()
        self.assertEqual((ok["evaluated"], ok["cer"], ok["char_accuracy"]), (True, 12.5, 87.5))
        none = self.c.post("/api/accuracy", json={"hypothesis": "Viet Nam"}).get_json()
        self.assertFalse(none["evaluated"])
        self.assertNotIn("char_accuracy", none)
        self.assertFalse(self.c.post("/api/accuracy", json={"hypothesis": "x", "reference": ""}).get_json()["evaluated"])
        self.assertEqual(self.c.post("/api/accuracy", json={"reference": "x"}).status_code, 400)
        with mock.patch.object(appmod, "MAX_ACCURACY_CHARS", 3):
            self.assertEqual(self.c.post("/api/accuracy", json={"hypothesis": "xxxx", "reference": "x"}).status_code, 413)

    def test_ai_down_never_blocks_ocr_and_message_is_standard(self):
        with mock.patch.object(ocr_engine, "run_ocr", return_value=fake_result()):
            r = self.c.post("/api/ocr", data={"file": (io.BytesIO(png_bytes()), "a.png")}, content_type="multipart/form-data")
        self.assertTrue(r.get_json()["success"])
        with mock.patch.dict("os.environ", {}, clear=True):
            j = self.c.post("/api/ai-review", json={"lines": [{"i": 0, "text": "abc"}]}).get_json()
        self.assertEqual(j["message"], "AI kiểm tra hiện không khả dụng. Kết quả OCR vẫn được giữ nguyên.")
        with mock.patch.dict("os.environ", {"GEMINI_API_KEY": "k"}), mock.patch.object(ai_review, "review", side_effect=ai_review.AIError("hết hạn mức")):
            r = self.c.post("/api/ai-review", json={"lines": [{"i": 0, "text": "abc"}]})
        self.assertEqual(r.status_code, 502)
        self.assertEqual(r.get_json()["message"], "AI kiểm tra hiện không khả dụng. Kết quả OCR vẫn được giữ nguyên.")
        self.assertEqual(r.get_json()["detail"], "hết hạn mức")

    def test_no_key_in_source(self):
        import re, os
        for f in ("ai_review.py", "app.py", "run.bat"):
            with open(os.path.join(helpers.ROOT, f), encoding="utf-8", errors="ignore") as fh:
                self.assertIsNone(re.search(r"AIza[0-9A-Za-z_\-]{30,}|sk-ant-[0-9A-Za-z_\-]{20,}", fh.read()), f)


if __name__ == "__main__":
    unittest.main()
