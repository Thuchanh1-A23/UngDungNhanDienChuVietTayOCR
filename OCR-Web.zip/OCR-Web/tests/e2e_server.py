"""Máy chủ thử nghiệm: giao diện + API thật, nhưng engine OCR được thay bằng bản giả (không cần model)."""
import sys
import time
from unittest import mock

import helpers
from helpers import fake_result

import ai_review
import app as appmod
import input_advisor
import ocr_engine

PROCESSED = helpers.png_bytes()
import base64
PROCESSED = "data:image/png;base64," + base64.b64encode(PROCESSED).decode()
AI_MODE = {"down": False}


def fake_ai_review(lines):
    by = {l["i"]: l for l in lines}
    ch = []
    for i, l in by.items():
        if l["text"] == "Dòng chắc chắn":
            ch.append({"i": i, "before": l["text"], "after": "Dòng chắc chắn.", "reason": "dấu câu", "edits": ai_review.word_edits(l["text"], "Dòng chắc chắn."),
                       "risky": False, "risk_reasons": [], "weak": True, "evidence": [], "conf": l.get("conf")})
        if l["text"] == "Dòng cuối":
            ch.append({"i": i, "before": l["text"], "after": "Dòng cuối cùng", "reason": "thiếu chữ", "edits": ai_review.word_edits(l["text"], "Dòng cuối cùng"),
                       "risky": False, "risk_reasons": [], "weak": False, "evidence": ["độ tin cậy dòng 60%"], "conf": 60})
    return {"changes": ch, "warnings": [], "rejected": [{"i": 0, "before": "x", "after": "yyyyyyyy", "why": "đổi quá nhiều"}], "sent": len(lines), "model": "giả", "failed": 0}

CALLS = []


def fake_run_ocr(image, **kw):
    CALLS.append(kw)
    time.sleep(0.7)  # đủ lâu để thử nút "Dừng"
    lines = [("Dòng chắc chắn", 98.0, "green", []), ("Dòng trùng", 80.0, "yellow", []),
             ("Dòng trùng", 60.0, "red", ["tr0ng"]), ("Dòng cuối", 95.0, "green", [])]
    q = {"level": "yellow", "score": 85, "issues": [{"level": "yellow", "label": "Độ tương phản", "message": "Chữ nhạt.", "code": "contrast",
                                                       "suggestion": "Có thể tăng tương phản trước khi nhận diện."}], "metrics": {"width": 900, "height": 700}}
    r = fake_result("\n".join(t for t, *_ in lines), processed_preview=PROCESSED, quality=q,
                    input_advice=input_advisor.build(q, kw.get("enhance", "auto"), True, True), notes=["Đã tăng độ tương phản cục bộ."])
    r["lines"] = [{"text": t, "conf": c, "level": lv, "bad": b, "refined": False} for t, c, lv, b in lines]
    return r


if __name__ == "__main__":
    mock.patch.object(ocr_engine, "run_ocr", fake_run_ocr).start()
    import os
    if os.environ.get("E2E_AI") == "on":
        os.environ["GEMINI_API_KEY"] = "fake"
        mock.patch.object(ai_review, "review", fake_ai_review).start()
    else:
        os.environ.pop("GEMINI_API_KEY", None)
    appmod.app.run(host="127.0.0.1", port=int(sys.argv[1]), threaded=True)
