"""Tiện ích dùng chung cho test: tạo ảnh/PDF mẫu, engine OCR giả."""
import io
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from PIL import Image, ImageDraw  # noqa: E402
from reportlab.pdfbase import pdfmetrics  # noqa: E402
from reportlab.pdfbase.ttfonts import TTFont  # noqa: E402
from reportlab.pdfgen import canvas  # noqa: E402
from reportlab.lib.pagesizes import A4  # noqa: E402

VN_LINES = ["Cộng hòa xã hội chủ nghĩa Việt Nam", "Độc lập - Tự do - Hạnh phúc", "Hà Nội, ngày 04 tháng 10 năm 2026"]


def png_bytes(size=(900, 700), color="white", text="Xin chao"):
    im = Image.new("RGB", size, color)
    ImageDraw.Draw(im).text((40, 40), text, fill="black")
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return buf.getvalue()


def _font():
    try:
        pdfmetrics.getFont("DJ")
    except KeyError:
        pdfmetrics.registerFont(TTFont("DJ", os.path.join(ROOT, "fonts", "DejaVuSans.ttf")))


def pdf_bytes(pages=1, lines=VN_LINES, scanned=False):
    """PDF nhiều trang. scanned=True: mỗi trang là một ảnh phủ kín (giống bản scan)."""
    _font()
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    for p in range(pages):
        if scanned:
            c.drawInlineImage(Image.new("RGB", (1240, 1754), "white"), 0, 0, width=595, height=842)
        else:
            c.setFont("DJ", 12)
            for i, t in enumerate(lines):
                c.drawString(60, 780 - 20 * i, f"{t} {p + 1}" if i == 0 else t)
        c.showPage()
    c.save()
    return buf.getvalue()


def fake_result(text="Dòng thử nghiệm", **extra):
    r = {"text": text, "lines": [{"text": text, "conf": 97.0, "level": "green", "bad": [], "refined": False}],
         "confidence": 97.0, "level": "green", "bad_words": 0, "quality": None, "notes": [], "rotation": 0,
         "deskew": 0.0, "processed_preview": None, "elapsed_ms": 10}
    r.update(extra)
    return r
