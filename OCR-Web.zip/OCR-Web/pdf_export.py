"""
Xuất văn bản kết quả OCR ra file PDF (đủ dấu tiếng Việt).

Cách 1 (ưu tiên): reportlab -> PDF chữ thật, bôi đen/sao chép/tìm kiếm được.
Cách 2 (dự phòng): Pillow vẽ chữ lên từng trang A4 rồi lưu thành PDF. Dùng khi reportlab chưa cài hoặc gặp lỗi,
để nút "Xuất PDF" luôn tải được file (chữ ở cách này là hình ảnh, không bôi đen được).

Mỗi mục '=== Trang N ===' trong văn bản bắt đầu trên một trang PDF mới.
"""

import io
import os
import re
import xml.sax.saxutils as saxutils

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PAGE_MARK = re.compile(r"^[ \t]*=== Trang \d+ ===[ \t]*$", re.M)
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f\u2028\u2029]")
_font_name = None


def font_path():
    """Đường dẫn font Unicode hỗ trợ đầy đủ tiếng Việt. Ưu tiên font kèm theo dự án."""
    win = os.environ.get("WINDIR", r"C:\Windows")
    candidates = [
        os.path.join(BASE_DIR, "fonts", "DejaVuSans.ttf"),
        os.path.join(win, "Fonts", "arial.ttf"),
        os.path.join(win, "Fonts", "times.ttf"),
        os.path.join(win, "Fonts", "segoeui.ttf"),
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    raise RuntimeError("Không tìm thấy font Unicode để xuất PDF")


def _clean(text):
    return _CTRL.sub("", text.replace("\r\n", "\n").replace("\r", "\n"))


def _sections(text):
    sections = [s.strip("\n") for s in PAGE_MARK.split(_clean(text))]
    if len(sections) > 1 and not sections[0].strip():
        sections = sections[1:]  # phần trước dấu '=== Trang 1 ===' rỗng thì bỏ
    return sections


# ------------------------------------------------------------------ Cách 1: reportlab
def _build_reportlab(text):
    global _font_name
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

    if not _font_name:
        pdfmetrics.registerFont(TTFont("OCRFont", font_path()))
        _font_name = "OCRFont"
    font = _font_name
    style = ParagraphStyle("body", fontName=font, fontSize=11, leading=16)

    story = []
    for i, section in enumerate(_sections(text)):
        if i:
            story.append(PageBreak())
        for line in section.split("\n"):
            if not line.strip():
                story.append(Spacer(1, 8))
                continue
            indent = len(line) - len(line.lstrip(" \t"))
            lead = "&nbsp;" * (line[:indent].count(" ") + 4 * line[:indent].count("\t"))
            story.append(Paragraph(lead + saxutils.escape(line.strip()), style))

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFont(font, 9)
        canvas.setFillGray(0.5)
        canvas.drawCentredString(A4[0] / 2, 10 * mm, str(doc.page))
        canvas.restoreState()

    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm,
                      topMargin=20 * mm, bottomMargin=20 * mm, title="Kết quả OCR").build(
        story or [Paragraph("&nbsp;", style)], onFirstPage=footer, onLaterPages=footer)
    return buf.getvalue()


# ------------------------------------------------------------------ Cách 2: Pillow
def _build_pillow(text):
    from PIL import Image, ImageDraw, ImageFont

    W, H, M = 1240, 1754, 150                  # A4 ở 150 DPI, lề ~25 mm
    font = ImageFont.truetype(font_path(), 28)
    foot = ImageFont.truetype(font_path(), 22)
    lh = 40
    maxw = W - 2 * M

    def wrap(line):
        """Bẻ một dòng dài theo bề rộng trang (giữ thụt đầu dòng)."""
        indent = len(line) - len(line.lstrip(" \t"))
        pad = " " * (line[:indent].count(" ") + 4 * line[:indent].count("\t"))
        words, out, cur = line.strip().split(), [], ""
        for w in words:
            test = f"{pad}{w}" if not cur else f"{cur} {w}"
            if font.getlength(test) <= maxw or not cur:
                cur = test
                while font.getlength(cur) > maxw and len(cur) > 1:   # từ dài hơn cả dòng: cắt cứng
                    k = len(cur)
                    while k > 1 and font.getlength(cur[:k]) > maxw:
                        k -= 1
                    out.append(cur[:k])
                    cur = cur[k:]
            else:
                out.append(cur)
                cur = w
        out.append(cur)
        return out

    pages = []

    def new_page():
        im = Image.new("RGB", (W, H), "white")
        pages.append(im)
        return im, ImageDraw.Draw(im), M

    for si, section in enumerate(_sections(text) or [""]):
        im, d, y = new_page()
        for line in section.split("\n"):
            rows = wrap(line) if line.strip() else [""]
            for r in rows:
                if y + lh > H - M:
                    im, d, y = new_page()
                if r:
                    d.text((M, y), r, font=font, fill="black")
                y += lh if (r or len(rows) > 1) else lh // 2
    for n, im in enumerate(pages, 1):
        d = ImageDraw.Draw(im)
        label = str(n)
        d.text(((W - foot.getlength(label)) / 2, H - 90), label, font=foot, fill=(128, 128, 128))

    buf = io.BytesIO()
    pages[0].save(buf, "PDF", resolution=150.0, save_all=True, append_images=pages[1:])
    return buf.getvalue()


def build_pdf(text):
    """Trả về BytesIO chứa file PDF. Thử reportlab trước, lỗi thì dùng Pillow."""
    import logging
    log = logging.getLogger("ocr")
    try:
        data = _build_reportlab(text)
    except Exception as e:  # thiếu thư viện / lỗi dàn trang: dùng phương án dự phòng
        log.warning("Xuất PDF bằng reportlab thất bại (%s: %s) - chuyển sang Pillow", type(e).__name__, e)
        data = _build_pillow(text)
    buf = io.BytesIO(data)
    buf.seek(0)
    return buf
