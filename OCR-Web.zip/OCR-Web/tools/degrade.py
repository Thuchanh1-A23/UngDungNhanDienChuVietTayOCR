"""
Tạo các biến thể "xấu" từ MỘT ảnh sạch thật của bạn để phủ đủ các loại ảnh trong bộ kiểm thử
(mờ, thiếu sáng, quá sáng, nhiễu, nền không đều, bóng, nghiêng, độ phân giải thấp).

    python tools/degrade.py anh_sach.png --gt anh_sach.txt
    python tools/degrade.py anh_sach.png --gt anh_sach.txt --variants mo_nhe,nghieng --include-original

- --gt: file .txt chứa văn bản ĐÚNG của ảnh. Mọi biến thể dùng lại đúng Ground Truth này (làm xấu ảnh không đổi nội dung chữ).
- Ảnh được lưu vào eval_data/images/<loại>/ và GT vào eval_data/ground_truth/<loại>/; manifest.csv ghi chú rõ đây là ảnh làm xấu
  nhân tạo (để khi đọc báo cáo bạn biết đâu là ảnh chụp thật, đâu là ảnh mô phỏng). Ảnh chụp thật ngoài đời vẫn nên có thêm.
"""
import argparse
import csv
import os
import shutil
import sys

import cv2
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def _load(path):
    with Image.open(path) as im:
        im.load()
        return np.array(im.convert("RGB"))


def _f(a):
    return a.astype(np.float32)


def _u8(a):
    return np.clip(a, 0, 255).astype(np.uint8)


def mo_nhe(a, rng):      return cv2.GaussianBlur(a, (0, 0), 1.6)
def mo_nang(a, rng):     return cv2.GaussianBlur(a, (0, 0), 3.8)
def thieu_sang(a, rng):  return _u8(_f(a) * 0.30 + 8)
def qua_sang(a, rng):    return _u8(_f(a) * 0.40 + 150)
def nhieu(a, rng):       return _u8(_f(a) + rng.normal(0, 28, a.shape))


def nen_khong_deu(a, rng):
    w = a.shape[1]
    return _u8(_f(a) * np.linspace(0.40, 1.0, w, dtype=np.float32)[None, :, None])


def co_bong(a, rng):
    h, w = a.shape[:2]
    m = np.ones((h, w), np.float32)
    m[int(h * 0.15):int(h * 0.75), :int(w * 0.40)] = 0.45
    m = cv2.GaussianBlur(m, (0, 0), max(h, w) / 60)
    return _u8(_f(a) * m[..., None])


def nghieng(a, rng):
    h, w = a.shape[:2]
    m = cv2.getRotationMatrix2D((w / 2, h / 2), 7.0, 1.0)
    return cv2.warpAffine(a, m, (w, h), flags=cv2.INTER_LINEAR, borderValue=(255, 255, 255))


def do_phan_giai_thap(a, rng):
    h, w = a.shape[:2]
    k = 480.0 / min(h, w) if min(h, w) > 480 else 0.5
    return cv2.resize(a, (max(1, int(w * k)), max(1, int(h * k))), interpolation=cv2.INTER_AREA)


VARIANTS = {f.__name__: f for f in (mo_nhe, mo_nang, thieu_sang, qua_sang, nhieu, nen_khong_deu, co_bong, nghieng, do_phan_giai_thap)}


def _append_manifest(data_dir, rows):
    path = os.path.join(data_dir, "manifest.csv")
    new = not os.path.isfile(path)
    with open(path, "a", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["file", "category", "note"])
        w.writerows(rows)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("image", help="ảnh sạch, rõ nét")
    ap.add_argument("--gt", required=True, help="file .txt chứa văn bản đúng của ảnh")
    ap.add_argument("--data", default=os.path.join(ROOT, "eval_data"))
    ap.add_argument("--variants", default=",".join(VARIANTS), help=f"danh sách, cách nhau dấu phẩy. Có: {', '.join(VARIANTS)}")
    ap.add_argument("--include-original", action="store_true", help="đồng thời đưa chính ảnh gốc vào nhóm anh_ro_net")
    args = ap.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    names = [v.strip() for v in args.variants.split(",") if v.strip()]
    unknown = [v for v in names if v not in VARIANTS]
    if unknown:
        raise SystemExit(f"Biến thể không có: {', '.join(unknown)}")
    if not os.path.isfile(args.gt):
        raise SystemExit(f"Không thấy file Ground Truth: {args.gt}")
    stem = os.path.splitext(os.path.basename(args.image))[0]
    base = _load(args.image)
    rng = np.random.default_rng(12345)   # cố định -> lần nào chạy cũng ra đúng cùng ảnh
    manifest = []

    def save(img, category, name, note):
        d_img = os.path.join(args.data, "images", category)
        d_gt = os.path.join(args.data, "ground_truth", category)
        os.makedirs(d_img, exist_ok=True)
        os.makedirs(d_gt, exist_ok=True)
        Image.fromarray(img).save(os.path.join(d_img, name + ".png"))
        shutil.copyfile(args.gt, os.path.join(d_gt, name + ".txt"))
        manifest.append([f"{category}/{name}.png", category, note])
        print(f"  + {category}/{name}.png")

    if args.include_original:
        save(base, "anh_ro_net", stem, f"ảnh gốc: {os.path.basename(args.image)}")
    for v in names:
        save(VARIANTS[v](base, rng), v, f"{stem}__{v}", f"tổng hợp (làm xấu nhân tạo) từ {os.path.basename(args.image)}")
    _append_manifest(args.data, manifest)
    print(f"Xong. Chạy: python evaluate.py")


if __name__ == "__main__":
    main()
