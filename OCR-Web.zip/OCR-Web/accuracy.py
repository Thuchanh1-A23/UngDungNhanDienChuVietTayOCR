"""
Đo ACCURACY THẬT của OCR bằng cách so sánh  OCR Output  <->  Ground Truth (văn bản đúng do con người xác nhận).

Phân biệt ba khái niệm (đừng nhầm lẫn):
  - Quality Score  : ảnh đầu vào dễ hay khó đọc (quality.py).
  - OCR Confidence : mức "tự tin" của model, KHÔNG phải độ chính xác thực tế (ocr_engine.py).
  - Accuracy       : chỉ tính được khi CÓ Ground Truth, bằng module này. Không có Ground Truth -> "Chưa đánh giá".

Chỉ số:
  CER = (thay thế + chèn + xóa ký tự) / số ký tự của Ground Truth        (có thể > 100% nếu OCR thừa nhiều)
  WER = (thay thế + chèn + xóa từ)    / số từ của Ground Truth
  Character Accuracy = max(0, 1 - CER) x 100%      (CER > 1 thì giới hạn về 0%)
  Word Accuracy      = max(0, 1 - WER) x 100%

Quy ước so sánh (mặc định NGHIÊM NGẶT, phù hợp tiếng Việt vì sai dấu thanh/dấu mũ là sai thật):
  - Chuẩn hóa Unicode NFC (cùng một chữ có dấu luôn được viết một cách duy nhất).
  - Mọi khoảng trắng/xuống dòng liên tiếp được gộp thành một dấu cách, bỏ khoảng trắng đầu/cuối.
  - Phân biệt HOA/thường, tính cả dấu câu, tính cả dấu thanh. Tùy chọn ignore_case / ignore_punct để nới lỏng.
  - Các dòng đánh dấu trang "=== Trang N ===" do ứng dụng thêm vào được bỏ đi trước khi so sánh.
"""

import re
import unicodedata

PAGE_MARK = re.compile(r"^[ \t]*=== Trang \d+ ===[ \t]*$", re.M)
_WS = re.compile(r"\s+")

NO_GT_MESSAGE = "Chưa đánh giá Accuracy (chưa có Ground Truth)."


def strip_page_marks(text):
    return PAGE_MARK.sub("", text or "")


def normalize(text, ignore_case=False, ignore_punct=False):
    text = unicodedata.normalize("NFC", strip_page_marks(text or ""))
    if ignore_case:
        text = text.casefold()
    if ignore_punct:
        text = "".join(" " if unicodedata.category(c).startswith("P") else c for c in text)
    return _WS.sub(" ", text).strip()


def edit_distance(a, b):
    """
    Khoảng cách chỉnh sửa Levenshtein (thay thế/chèn/xóa mỗi thao tác = 1) giữa hai chuỗi hoặc hai danh sách.
    Dùng thuật toán song song theo bit (Hyyrö) trên số nguyên Python: nhanh cả với văn bản hàng chục nghìn ký tự.
    """
    a, b = list(a), list(b)
    while a and b and a[0] == b[0]:        # bỏ phần đầu/cuối giống nhau cho nhanh
        a, b = a[1:], b[1:]
    while a and b and a[-1] == b[-1]:
        a, b = a[:-1], b[:-1]
    if not a or not b:
        return len(a) + len(b)
    if len(a) < len(b):
        a, b = b, a
    m = len(b)
    peq = {}
    for i, c in enumerate(b):
        peq[c] = peq.get(c, 0) | (1 << i)
    mask = (1 << m) - 1
    last = 1 << (m - 1)
    pv, mv, score = mask, 0, m
    for c in a:
        eq = peq.get(c, 0)
        xv = eq | mv
        xh = (((eq & pv) + pv) ^ pv) | eq
        ph = (mv | ~(xh | pv)) & mask
        mh = pv & xh
        if ph & last:
            score += 1
        elif mh & last:
            score -= 1
        ph = ((ph << 1) | 1) & mask
        mh = (mh << 1) & mask
        pv = (mh | ~(xv | ph)) & mask
        mv = ph & xv
    return score


def _pct(x):
    return round(x * 100, 2)


def evaluate(hypothesis, reference, ignore_case=False, ignore_punct=False):
    """
    hypothesis: văn bản OCR; reference: Ground Truth.
    Nếu reference trống/None: KHÔNG tính, trả về {"evaluated": False, "message": ...} (tuyệt đối không bịa con số).
    Ngược lại trả về dict với cer, wer, char_accuracy, word_accuracy (đơn vị %) cùng các số đếm dùng để tính.
    """
    if reference is None or not normalize(reference, ignore_case, ignore_punct):
        return {"evaluated": False, "message": NO_GT_MESSAGE}
    hyp = normalize(hypothesis, ignore_case, ignore_punct)
    ref = normalize(reference, ignore_case, ignore_punct)
    c_dist = edit_distance(hyp, ref)
    h_words, r_words = hyp.split(" ") if hyp else [], ref.split(" ")
    w_dist = edit_distance(h_words, r_words)
    cer, wer = c_dist / len(ref), w_dist / len(r_words)
    return {
        "evaluated": True,
        "cer": _pct(cer),
        "wer": _pct(wer),
        "char_accuracy": _pct(max(0.0, 1.0 - cer)),
        "word_accuracy": _pct(max(0.0, 1.0 - wer)),
        "char_distance": c_dist, "ref_chars": len(ref), "hyp_chars": len(hyp),
        "word_distance": w_dist, "ref_words": len(r_words), "hyp_words": len(h_words),
        "options": {"ignore_case": bool(ignore_case), "ignore_punct": bool(ignore_punct)},
    }


def aggregate(results):
    """
    Gộp nhiều kết quả evaluate(): trả về CER/WER theo "micro" (tổng lỗi / tổng ký tự-từ tham chiếu, mẫu dài có trọng số lớn hơn)
    và trung bình cộng từng mẫu ("macro"). Chỉ tính các mẫu có evaluated=True.
    """
    ok = [r for r in results if r and r.get("evaluated")]
    if not ok:
        return {"evaluated": False, "samples": 0, "message": NO_GT_MESSAGE}
    cd, rc = sum(r["char_distance"] for r in ok), sum(r["ref_chars"] for r in ok)
    wd, rw = sum(r["word_distance"] for r in ok), sum(r["ref_words"] for r in ok)
    n = len(ok)
    return {
        "evaluated": True, "samples": n,
        "cer_micro": _pct(cd / rc), "wer_micro": _pct(wd / rw),
        "char_accuracy_micro": _pct(max(0.0, 1 - cd / rc)),
        "cer_macro": round(sum(r["cer"] for r in ok) / n, 2),
        "wer_macro": round(sum(r["wer"] for r in ok) / n, 2),
        "char_accuracy_macro": round(sum(r["char_accuracy"] for r in ok) / n, 2),
    }
