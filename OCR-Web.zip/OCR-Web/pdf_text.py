"""
Lấy văn bản có sẵn trong PDF "số" (vd: xuất từ Word) để làm Ground Truth - chữ đúng 100%, không qua OCR.
PDF KHÔNG phải đầu vào OCR của ứng dụng; module này chỉ phục vụ nút "Lấy từ PDF có sẵn chữ" ở mục Accuracy.

Chỉ nhận khi đủ tin cậy, nếu không trả về None:
  - Trang scan (có ảnh phủ phần lớn trang) -> bỏ qua: lớp chữ ẩn của bản scan thường kém chất lượng.
  - Trang gần như không có chữ -> bỏ qua.
  - Chữ rác do font cũ / mã hóa sai (TCVN3, VNI, ký tự vùng riêng U+E000...) -> bỏ qua.
  - Nhiều âm tiết không thể là tiếng Việt (kiểm tra bằng vi_check) -> bỏ qua.
"""

import re
import unicodedata

import vi_check

MIN_CHARS = 15            # ít hơn ngần này ký tự (không tính khoảng trắng) -> coi như không có chữ
MAX_IMAGE_COVER = 0.5     # ảnh phủ quá tỉ lệ này diện tích trang -> coi là trang scan
MAX_ODD_RATIO = 0.03      # tỉ lệ ký tự "lạ" (rác/font cũ) tối đa
MAX_BAD_WORD_RATIO = 0.10  # tỉ lệ từ không phải âm tiết tiếng Việt tối đa

_NL = re.compile(r"\r\n|\r|\n")
# Không cho phép µ § ¶ † ‡: đây là ký tự hay gặp khi PDF dùng font cũ (TCVN3) nên là dấu hiệu chữ rác
_PUNCT_OK = set("–—‘’“”…•·€°²³×÷±½¼¾º©®™′″→←↑↓≥≤≠≈√∑∞‰«»")


def _is_odd(ch):
    """Ký tự khó xuất hiện trong văn bản tiếng Việt/Anh bình thường (dấu hiệu của mã hóa sai)."""
    o = ord(ch)
    if o < 0x80:
        return o < 0x20 and ch not in "\t\n\r"
    if ch in _PUNCT_OK or ch in "\u00a0\u200b\u200c\u200d\ufeff\u00ad":
        return False
    if 0xE000 <= o <= 0xF8FF or o == 0xFFFD:
        return True
    base = unicodedata.normalize("NFD", ch)[0]
    if base.isascii() and base.isalpha():  # chữ Latin có dấu (gồm cả ă â ê ô ơ ư đ)
        return False
    if ch in "đĐ":
        return False
    return not unicodedata.category(ch).startswith(("L", "M"))  # chữ cái nước khác vẫn được chấp nhận


def _image_cover(page):
    """Tỉ lệ diện tích trang bị ảnh chiếm (0-1). Không đọc được thì trả về 0."""
    try:
        import pypdfium2.raw as pdfium_c
        w, h = page.get_size()
        total = float(w * h) or 1.0
        covered = 0.0
        for obj in page.get_objects(filter=[pdfium_c.FPDF_PAGEOBJ_IMAGE], max_depth=2):
            # pypdfium2 >= 5 dùng get_bounds(), bản 4.x dùng get_pos()
            left, bottom, right, top = (obj.get_bounds() if hasattr(obj, "get_bounds") else obj.get_pos())
            covered += max(0.0, right - left) * max(0.0, top - bottom)
        return min(1.0, covered / total)
    except Exception:
        return 0.0


def looks_trustworthy(lines):
    """True nếu các dòng chữ trích từ PDF trông như tiếng Việt/Anh thật sự."""
    text = "\n".join(lines)
    compact = re.sub(r"\s+", "", text)
    if len(compact) < MIN_CHARS:
        return False
    if sum(_is_odd(c) for c in compact) / len(compact) > MAX_ODD_RATIO:
        return False
    # Chỉ kiểm tra "tính Việt" trên các từ có dấu: từ chỉ gồm chữ ASCII có thể là tiếng Anh/viết tắt hợp lệ
    bad_n = checked_n = 0
    for ln in lines:
        bad, _ = vi_check.check_line(ln)
        bad_n += sum(1 for w in bad if not w.isascii())
        checked_n += sum(1 for t in re.findall(r"\w+", ln) if len(t) >= 2 and t.isalpha() and not t.isascii())
    return checked_n == 0 or bad_n / checked_n <= MAX_BAD_WORD_RATIO


def extract_page_lines(pdf, index):
    """Trả về danh sách dòng chữ của trang (bắt đầu từ 0), hoặc None nếu nên dùng OCR."""
    page = pdf[index]
    textpage = None
    try:
        if _image_cover(page) > MAX_IMAGE_COVER:
            return None
        textpage = page.get_textpage()
        raw = textpage.get_text_range() or ""
    except Exception:
        return None
    finally:
        if textpage is not None:
            textpage.close()
        page.close()

    lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in _NL.split(raw)]
    lines = [ln for ln in lines if ln]
    return lines if lines and looks_trustworthy(lines) else None
